"""
WhatsApp notifications via Twilio's WhatsApp API.

Setup (required before this does anything):
  1. Create a free Twilio account: https://www.twilio.com/try-twilio
  2. In the Twilio Console, activate the WhatsApp Sandbox
     (Messaging > Try it out > Send a WhatsApp message). You'll get a
     sandbox number (e.g. +14155238886) and a join code -- send that code
     from YOUR WhatsApp to that number once to link your phone.
  3. Copy your Account SID and Auth Token from the Twilio Console dashboard.
  4. Set environment variables (never hardcode these):
       export QUANTIS_TWILIO_SID="ACxxxxxxxx"
       export QUANTIS_TWILIO_TOKEN="your_auth_token"
       export QUANTIS_WHATSAPP_FROM="whatsapp:+14155238886"
       export QUANTIS_WHATSAPP_TO="whatsapp:+2349XXXXXXXXX"   # your real number, E.164 format
  5. Set config.WHATSAPP_ENABLED = True

Sandbox numbers are free but require you to re-send the join code roughly
every 72 hours and only message the one phone number you linked. For a
permanent, always-on setup, Twilio's WhatsApp Business API (paid, requires
Meta approval) removes both limits -- see Twilio's docs when you get there.
"""
import os
import config

try:
    from twilio.rest import Client
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False


def send_whatsapp(message: str) -> bool:
    if not config.WHATSAPP_ENABLED:
        return False
    if not TWILIO_AVAILABLE:
        print("[Quantis] WhatsApp enabled but 'twilio' package not installed (pip install twilio)")
        return False

    sid = os.getenv("QUANTIS_TWILIO_SID", config.TWILIO_ACCOUNT_SID)
    token = os.getenv("QUANTIS_TWILIO_TOKEN", config.TWILIO_AUTH_TOKEN)
    from_number = os.getenv("QUANTIS_WHATSAPP_FROM", config.TWILIO_WHATSAPP_FROM)
    to_number = os.getenv("QUANTIS_WHATSAPP_TO", config.WHATSAPP_TO_NUMBER)

    if not all([sid, token, from_number, to_number]):
        print("[Quantis] WhatsApp enabled but credentials are incomplete — check env vars.")
        return False

    try:
        client = Client(sid, token)
        client.messages.create(body=message, from_=from_number, to=to_number)
        return True
    except Exception as e:
        print(f"[Quantis] WhatsApp send failed: {e}")
        return False
