"""
Quantis Bot — Flask Web Dashboard

Serves a Binance-styled dashboard backed by the REAL trading engine:
signals.py, risk.py, capital.py, backtester.py, demo_engine.py.

Runs a background DemoEngine thread by default so the dashboard has live,
moving data without needing outbound exchange access. To run against real
Binance Testnet data on your own machine, see DEPLOYMENT.md — the same
engine code (signals/risk/capital) powers both modes; only the data source
changes (see paper_trader.py for the live-exchange version of this loop).

Auth: HTTP Basic Auth, required whenever this is exposed beyond localhost.
Set QUANTIS_DASHBOARD_USER / QUANTIS_DASHBOARD_PASSWORD env vars before
deploying anywhere reachable from the internet. Defaults are for local-only
use and will refuse to start bound to a public interface without them set
(see run() below).
"""
import os
import sys
from functools import wraps
from datetime import date, datetime

from flask import Flask, jsonify, request, render_template, Response, send_from_directory

from flask_cors import CORS

import config
from demo_engine import DemoEngine
from backtester import Backtester
from synthetic_data import generate_test_universe
from capital import CapitalManager
from analytics import compute_summary, compute_equity_series, compute_r_multiple_distribution, compute_rolling_win_rate
import live_gate
from notifier import notify
from trading_mode import get_trading_mode, TradingModeError

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": os.getenv("QUANTIS_CORS_ORIGIN", "*")}})

DASHBOARD_USER = os.getenv("QUANTIS_DASHBOARD_USER", "admin")
DASHBOARD_PASSWORD = os.getenv("QUANTIS_DASHBOARD_PASSWORD", "")

try:
    get_trading_mode()   # reject unsupported/ambiguous TRADING_MODE before anything starts
except TradingModeError as _e:
    print(f"[Quantis] REFUSING TO START: {_e}", file=sys.stderr)
    sys.exit(1)

engine = DemoEngine(symbols=config.SYMBOLS)

# Production safety gate: when this module is imported by a WSGI server
# (gunicorn, uWSGI, etc. -- the deployment path in Dockerfile/DEPLOYMENT.md),
# `if __name__ == "__main__"` never runs, so the host-binding check inside
# run() below is skipped entirely. Enforce the same rule here at import time,
# gated on QUANTIS_PRODUCTION=1 (set by the Dockerfile), so a container
# deployed with no password set fails fast instead of serving an open
# dashboard to the internet.
if os.getenv("QUANTIS_PRODUCTION", "0") == "1" and not DASHBOARD_PASSWORD:
    print(
        "[Quantis] REFUSING TO START: QUANTIS_PRODUCTION=1 but no "
        "QUANTIS_DASHBOARD_PASSWORD is set. Set QUANTIS_DASHBOARD_USER and "
        "QUANTIS_DASHBOARD_PASSWORD before deploying this anywhere reachable "
        "from the internet.",
        file=sys.stderr,
    )
    sys.exit(1)

# Start the engine at import time so it runs under gunicorn too, not just
# when this file is executed directly with `python server.py`.
engine.start()


def check_auth(username, password):
    if not DASHBOARD_PASSWORD:
        # No password configured -- only acceptable for local-only (127.0.0.1) use.
        return request.remote_addr in ("127.0.0.1", "::1")
    return username == DASHBOARD_USER and password == DASHBOARD_PASSWORD


def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not DASHBOARD_PASSWORD:
            # No password configured: only allow local requests, no header needed.
            if request.remote_addr in ("127.0.0.1", "::1"):
                return f(*args, **kwargs)
            return Response(
                "No dashboard password configured. Set QUANTIS_DASHBOARD_PASSWORD "
                "before accessing this from a non-local address.", 401,
            )
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return Response(
                "Authentication required.", 401,
                {"WWW-Authenticate": 'Basic realm="Quantis Dashboard"'},
            )
        return f(*args, **kwargs)
    return decorated


@app.route("/")
@requires_auth
def index():
    return render_template("index.html", mode="DEMO" if config.USE_TESTNET else "LIVE",
                            testnet=config.USE_TESTNET)


@app.route("/api/state")
@requires_auth
def api_state():
    return jsonify(engine.snapshot_state())


@app.route("/api/config")
@requires_auth
def api_config():
    return jsonify({
        "symbols": config.SYMBOLS,
        "timeframe": config.TIMEFRAME,
        "risk_per_trade_pct": config.RISK_PER_TRADE_PCT,
        "max_concurrent_positions": config.MAX_CONCURRENT_POSITIONS,
        "daily_loss_circuit_breaker_pct": config.DAILY_LOSS_CIRCUIT_BREAKER_PCT,
        "max_allocation_per_asset_pct": config.MAX_ALLOCATION_PER_ASSET_PCT,
        "reward_risk_ratio": config.REWARD_RISK_RATIO,
        "min_score_to_trade": config.MIN_SCORE_TO_TRADE,
        "trail_activation_r": config.TRAIL_ACTIVATION_R,
        "trail_distance_r": config.TRAIL_DISTANCE_R,
        "use_regime_filter": config.USE_REGIME_FILTER,
        "market_breadth_min": config.MARKET_BREADTH_MIN,
        "use_testnet": config.USE_TESTNET,
        "starting_capital": config.STARTING_CAPITAL,
        "ml_min_samples_to_train": config.ML_MIN_SAMPLES_TO_TRAIN,
        "ml_min_samples_to_act": config.ML_MIN_SAMPLES_TO_ACT,
        "ml_blend_weight": config.ML_BLEND_WEIGHT,
        "live_min_paper_days": config.LIVE_MIN_PAPER_DAYS,
        "live_min_paper_trades": config.LIVE_MIN_PAPER_TRADES,
        "live_min_win_rate_pct": config.LIVE_MIN_WIN_RATE_PCT,
        "live_max_drawdown_pct_allowed": config.LIVE_MAX_DRAWDOWN_PCT_ALLOWED,
        "telegram_enabled": config.TELEGRAM_ENABLED,
        "whatsapp_enabled": config.WHATSAPP_ENABLED,
        "trading_mode": get_trading_mode(),
        "use_edge_gate": config.USE_EDGE_GATE,
        "edge_min_observations": config.EDGE_MIN_OBSERVATIONS,
        "edge_min_ev_r": config.EDGE_MIN_EV_R,
        "edge_max_cost_r": config.EDGE_MAX_COST_R,
    })


@app.route("/api/analytics")
@requires_auth
def api_analytics():
    db_path = engine.capital.db_path
    summary = compute_summary(db_path)
    equity = compute_equity_series(db_path)
    r_dist = compute_r_multiple_distribution(db_path)
    rolling_win_rate = compute_rolling_win_rate(db_path, window=20)
    learner_status = engine.learner.status()
    benchmark = engine.benchmark_snapshot()
    return jsonify({
        "summary": summary,
        "equity_series": equity,
        "r_multiple_distribution": r_dist,
        "rolling_win_rate": rolling_win_rate,
        "learner": learner_status,
        "benchmark": benchmark,
    })


@app.route("/api/decisions")
@requires_auth
def api_decisions():
    """Latest structured decisions (BUY / NO TRADE) with expected net return, uncertainty and rationale."""
    return jsonify([d.to_dict() for d in list(engine.decider.recent)[:100]])


@app.route("/api/live_gate/status")
@requires_auth
def api_live_gate_status():
    return jsonify(live_gate.check_readiness(engine.capital.db_path))


@app.route("/api/live_gate/enable", methods=["POST"])
@requires_auth
def api_live_gate_enable():
    payload = request.get_json(force=True, silent=True) or {}
    phrase = payload.get("confirmation_phrase", "")
    result = live_gate.attempt_enable_live(engine.capital.db_path, phrase)
    return jsonify(result), (200 if result.get("success") else 400)


@app.route("/api/live_gate/disable", methods=["POST"])
@requires_auth
def api_live_gate_disable():
    return jsonify(live_gate.disable_live())


@app.route("/api/notify_test", methods=["POST"])
@requires_auth
def api_notify_test():
    results = notify("🔔 Quantis test notification — if you see this, alerts are wired up correctly.")
    return jsonify(results)


@app.route("/api/backtest", methods=["POST"])
@requires_auth
def api_backtest():
    payload = request.get_json(force=True, silent=True) or {}
    symbols = payload.get("symbols") or config.SYMBOLS
    n_bars = int(payload.get("n_bars") or 3000)
    seed = int(payload.get("seed") or 42)
    starting_capital = float(payload.get("starting_capital") or config.STARTING_CAPITAL)

    data = generate_test_universe(symbols, n_bars=n_bars, seed=seed)
    bt = Backtester(data, starting_capital=starting_capital, db_path=":memory:")
    results = bt.run()

    trades = []
    if "trades_df" in results:
        trades = results["trades_df"].to_dict("records")
        for t in trades:
            for k, v in list(t.items()):
                if hasattr(v, "isoformat"):
                    t[k] = v.isoformat()

    equity_points = []
    if "equity_df" in results and not results["equity_df"].empty:
        edf = results["equity_df"]
        step = max(1, len(edf) // 300)
        equity_points = [
            {"t": row["ts"].isoformat(), "equity": round(row["equity"], 2)}
            for _, row in edf.iloc[::step].iterrows()
        ]

    return jsonify({
        "starting_capital": results.get("starting_capital"),
        "final_equity": results.get("final_equity"),
        "total_return_pct": results.get("total_return_pct"),
        "total_trades": results.get("total_trades", 0),
        "wins": results.get("wins", 0),
        "losses": results.get("losses", 0),
        "win_rate_pct": results.get("win_rate_pct"),
        "avg_win_usdt": results.get("avg_win_usdt"),
        "avg_loss_usdt": results.get("avg_loss_usdt"),
        "max_drawdown_pct": results.get("max_drawdown_pct"),
        "sharpe_ratio": results.get("sharpe_ratio"),
        "sortino_ratio": results.get("sortino_ratio"),
        "profit_factor": results.get("profit_factor"),
        "ev_per_trade_r": results.get("expected_value_per_trade_r"),
        "total_costs_usdt": results.get("total_costs_usdt"),
        "turnover_x_capital": results.get("turnover_x_capital"),
        "avg_exposure_pct": results.get("avg_exposure_pct"),
        "benchmark_buy_hold_pct": results.get("benchmark_buy_hold_pct"),
        "rejections": results.get("rejections"),
        "label": results.get("label", "HISTORICAL BACKTEST (simulation) - not live performance"),
        "trades": trades[:100],
        "equity_curve": equity_points,
        "note": "Synthetic data — sanity check of mechanics only. Run backtest --real on your own machine for a real strategy validation against actual market history.",
    })


@app.route("/api/reports")
@requires_auth
def api_reports_list():
    d = config.REPORTS_DIR
    if not os.path.isdir(d):
        return jsonify([])
    files = sorted([f for f in os.listdir(d) if f.endswith(".md")], reverse=True)
    return jsonify(files)


@app.route("/api/reports/<path:filename>")
@requires_auth
def api_report_get(filename):
    return send_from_directory(config.REPORTS_DIR, filename, mimetype="text/markdown")


@app.route("/api/engine/start", methods=["POST"])
@requires_auth
def api_engine_start():
    engine.start()
    return jsonify({"running": True})


@app.route("/api/engine/stop", methods=["POST"])
@requires_auth
def api_engine_stop():
    engine.stop()
    return jsonify({"running": False})


@app.route("/healthz")
def healthz():
    return jsonify({"status": "ok", "time": datetime.now().isoformat()})


def run():
    host = os.getenv("QUANTIS_HOST", "127.0.0.1")
    port = int(os.getenv("QUANTIS_PORT", "5000"))

    if host not in ("127.0.0.1", "localhost", "::1") and not DASHBOARD_PASSWORD:
        print(
            "[Quantis] REFUSING TO START: binding to a non-local host "
            f"({host}) without QUANTIS_DASHBOARD_PASSWORD set. "
            "Set QUANTIS_DASHBOARD_USER and QUANTIS_DASHBOARD_PASSWORD env vars "
            "before deploying this anywhere reachable from the internet.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"[Quantis] Dashboard starting on http://{host}:{port}  (mode: {'TESTNET/DEMO' if config.USE_TESTNET else 'LIVE'})")
    app.run(host=host, port=port, debug=False, threaded=True)


if __name__ == "__main__":
    run()
