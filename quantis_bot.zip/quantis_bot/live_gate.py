"""
Live Trading Readiness Gate.

This exists so "switch from demo to live" is never a single unchecked
config flip. It checks the bot's OWN recorded paper-trading history
against minimum thresholds (config.py) and only allows enabling live mode
when they're met, plus an explicit typed confirmation from the user.

This does not guarantee profitability -- nothing can. It guarantees that
you can't accidentally (or impulsively) go live with zero track record.
"""
import os
import json
import time
from datetime import datetime

import config
from analytics import compute_summary


STATE_FILE = "live_gate_state.json"
REQUIRED_CONFIRMATION_PHRASE = "I UNDERSTAND THE RISK"


def _load_gate_state() -> dict:
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"paper_trading_started_at": None, "live_enabled": False, "live_enabled_at": None}


def _save_gate_state(state: dict):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def mark_paper_trading_start_if_needed():
    """Call this once when the bot first starts in paper/demo mode. Idempotent."""
    state = _load_gate_state()
    if state["paper_trading_started_at"] is None:
        state["paper_trading_started_at"] = datetime.now().isoformat()
        _save_gate_state(state)
    return state


def check_readiness(db_path: str) -> dict:
    """
    Returns a dict describing whether live trading may be enabled, and why
    not, if applicable. Every threshold is pulled from config.py so the
    user can see (and deliberately choose to adjust, at their own judgment)
    exactly what's being checked.
    """
    state = mark_paper_trading_start_if_needed()
    started_at = datetime.fromisoformat(state["paper_trading_started_at"])
    days_running = (datetime.now() - started_at).days

    summary = compute_summary(db_path)
    trades = summary.get("trades", 0)
    win_rate = summary.get("win_rate_pct", 0)
    max_dd = abs(summary.get("max_drawdown_pct", 0) or 0)

    checks = {
        "days_running": {
            "value": days_running, "required": config.LIVE_MIN_PAPER_DAYS,
            "passed": days_running >= config.LIVE_MIN_PAPER_DAYS,
        },
        "trade_count": {
            "value": trades, "required": config.LIVE_MIN_PAPER_TRADES,
            "passed": trades >= config.LIVE_MIN_PAPER_TRADES,
        },
        "win_rate_pct": {
            "value": win_rate, "required": config.LIVE_MIN_WIN_RATE_PCT,
            "passed": win_rate >= config.LIVE_MIN_WIN_RATE_PCT,
        },
        "max_drawdown_pct": {
            "value": max_dd, "required": config.LIVE_MAX_DRAWDOWN_PCT_ALLOWED,
            "passed": max_dd <= config.LIVE_MAX_DRAWDOWN_PCT_ALLOWED,
        },
    }
    all_passed = all(c["passed"] for c in checks.values())

    return {
        "ready": all_passed,
        "checks": checks,
        "paper_trading_started_at": state["paper_trading_started_at"],
        "live_currently_enabled": state.get("live_enabled", False),
        "note": (
            "Meeting these thresholds means you have SOME track record, not a "
            "guarantee of future profit. Past paper-trading results, even good "
            "ones, do not assure live results — markets change and paper fills "
            "are never perfectly realistic. This is a floor, not a green light "
            "to stop paying attention."
        ),
    }


def attempt_enable_live(db_path: str, confirmation_phrase: str) -> dict:
    readiness = check_readiness(db_path)
    if not readiness["ready"]:
        return {"success": False, "reason": "readiness_checks_not_met", "readiness": readiness}
    if confirmation_phrase.strip() != REQUIRED_CONFIRMATION_PHRASE:
        return {
            "success": False, "reason": "confirmation_phrase_mismatch",
            "required_phrase": REQUIRED_CONFIRMATION_PHRASE,
        }

    state = _load_gate_state()
    state["live_enabled"] = True
    state["live_enabled_at"] = datetime.now().isoformat()
    _save_gate_state(state)
    return {"success": True, "message": "Live mode gate passed and confirmed. You must still set USE_TESTNET=False and real API keys in config.py / environment yourself — this endpoint does not do that for you."}


def disable_live():
    state = _load_gate_state()
    state["live_enabled"] = False
    _save_gate_state(state)
    return {"success": True}
