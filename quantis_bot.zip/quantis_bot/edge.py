"""
Net-edge gate and structured decisions.

Instead of "trade when score >= 60" (an arbitrary number), every candidate
trade is evaluated like this:

  1. COST: round-trip fees + slippage + spread, expressed in R (multiples of the
     money risked on the trade). A tight stop makes costs a big fraction of R --
     that is why many small-ATR trades are structurally unprofitable.
  2. EDGE: the bot's own history of net realized R-multiples for trades taken at
     similar signal scores, shrunk toward a cautious prior ("no edge, pay costs")
     so a handful of lucky trades can't convince it.
  3. DECISION:
       - fewer than EDGE_MIN_OBSERVATIONS closed trades -> "exploration": allowed only
         if costs are small, at reduced size, clearly labelled. (A bot that refuses to
         trade can never gather the evidence it needs.)
       - enough history -> "calibrated": the *conservative* (lower-bound) expected net
         return must clear EDGE_MIN_EV_R, otherwise NO TRADE.

Outputs are estimates, not facts; the estimate and its uncertainty are recorded.
"""
import math
import sqlite3
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

import numpy as np

import config

SCORE_BUCKETS = [(0, 50), (50, 60), (60, 70), (70, 80), (80, 101)]


# ── execution costs (shared by backtester, demo and paper engines) ────────
def per_side_cost_frac() -> float:
    return config.TAKER_FEE_PCT + config.SLIPPAGE_PCT + config.SPREAD_ASSUMPTION_PCT / 2.0


def round_trip_cost_frac() -> float:
    return 2.0 * per_side_cost_frac()


def apply_costs(price: float, side: str) -> float:
    """Worse-than-mid fill price after fee, slippage and half-spread."""
    f = per_side_cost_frac()
    return price * (1.0 + f) if side == "buy" else price * (1.0 - f)


# ── calibration ───────────────────────────────────────────────────────────
class ScoreCalibrator:
    """Empirical net-R by signal-score bucket with hierarchical shrinkage."""

    def __init__(self):
        self.obs = []  # (score, net_r_multiple)

    def add(self, score: float, r_multiple: float):
        self.obs.append((float(score), float(r_multiple)))

    @property
    def n(self) -> int:
        return len(self.obs)

    @staticmethod
    def bucket_of(score: float):
        for lo, hi in SCORE_BUCKETS:
            if lo <= score < hi:
                return lo, hi
        return SCORE_BUCKETS[-1]

    def estimate(self, score: float, cost_r: float) -> dict:
        k = config.EDGE_PRIOR_STRENGTH
        z = config.EDGE_CONFIDENCE_Z
        prior_mean = -cost_r  # cautious prior: no edge, you still pay the costs

        rs_all = np.array([r for _, r in self.obs], dtype=float)
        n_all = len(rs_all)
        lo, hi = self.bucket_of(score)
        rs_b = np.array([r for s, r in self.obs if lo <= s < hi], dtype=float)
        n_b = len(rs_b)
        # Shrink each bucket toward the cautious prior ("no edge, costs still paid"), NOT toward a pooled
        # mean: pooling would count the same trades twice and let a few lucky wins look like an edge.
        m_b = (rs_b.sum() + prior_mean * k) / (n_b + k)

        sd = float(np.std(rs_all, ddof=1)) if n_all >= 5 else 1.0
        sd = max(sd, 0.5)
        se = sd / math.sqrt(n_b + k)
        return {
            "ev_r": float(m_b), "se_r": float(se), "ev_lower_r": float(m_b - z * se),
            "n_bucket": int(n_b), "n_total": int(n_all),
            "bucket_win_rate": float((rs_b > 0).mean()) if n_b else None,
            "bucket": f"{lo}-{min(hi, 100)}",
        }


@dataclass
class Decision:
    symbol: str
    timestamp: str
    signal: str                    # "BUY" or "NO TRADE"
    approved: bool
    mode: str                      # exploration | calibrated | disabled
    reason: str
    score: float
    regime: str = None
    strategy: str = None
    expected_return_r: float = None     # estimate of net expected return, in R
    uncertainty_r: float = None         # standard error of that estimate
    expected_cost_r: float = 0.0
    expected_cost_pct: float = 0.0
    size_multiplier: float = 1.0
    n_observations: int = 0
    rationale: list = field(default_factory=list)
    invalidation: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        for k in ("expected_return_r", "uncertainty_r", "expected_cost_r", "expected_cost_pct"):
            if d[k] is not None:
                d[k] = round(d[k], 4)
        return d


class DecisionMaker:
    def __init__(self, db_path: str = None):
        self.calibrator = ScoreCalibrator()
        self.recent = deque(maxlen=200)
        if db_path:
            self.load_from_db(db_path)

    def load_from_db(self, db_path: str):
        """Load previously realized (score, net R) outcomes recorded by learner.py."""
        try:
            conn = sqlite3.connect(db_path)
            rows = conn.execute(
                "SELECT signal_score, r_multiple FROM trade_features "
                "WHERE outcome IS NOT NULL AND r_multiple IS NOT NULL AND signal_score IS NOT NULL"
            ).fetchall()
            conn.close()
        except sqlite3.Error:
            rows = []
        for score, r in rows:
            self.calibrator.add(score, r)

    def record_outcome(self, score: float, r_multiple: float):
        self.calibrator.add(score, r_multiple)

    def evaluate(self, symbol: str, result: dict, entry_price: float, atr: float, ts=None) -> Decision:
        score = float(result.get("score", 0))
        regime, strategy = result.get("regime"), result.get("strategy")
        stamp = (ts.isoformat() if hasattr(ts, "isoformat") else str(ts)) if ts is not None else datetime.now(timezone.utc).isoformat(timespec="seconds")

        stop_frac = (1.5 * atr) / entry_price if entry_price > 0 else 0
        cost_frac = round_trip_cost_frac()
        cost_r = cost_frac / stop_frac if stop_frac > 0 else float("inf")
        invalidation = (f"price closes below stop {entry_price - 1.5 * atr:.4f}; regime leaves '{regime}'; "
                        f"or calibrated edge turns negative")
        rationale = [f"strategy={strategy}", f"regime={regime}", f"score={score:.1f}",
                     f"round-trip cost={cost_frac * 100:.3f}% of price = {cost_r:.2f}R"]

        def make(approved, mode, reason, est=None, size_mult=1.0):
            return Decision(
                symbol=symbol, timestamp=stamp, signal="BUY" if approved else "NO TRADE",
                approved=approved, mode=mode, reason=reason, score=score, regime=regime, strategy=strategy,
                expected_return_r=est["ev_r"] if est else None,
                uncertainty_r=est["se_r"] if est else None,
                expected_cost_r=cost_r if math.isfinite(cost_r) else 99.0,
                expected_cost_pct=cost_frac * 100, size_multiplier=size_mult,
                n_observations=self.calibrator.n, rationale=rationale, invalidation=invalidation,
            )

        if not config.USE_EDGE_GATE:
            d = make(True, "disabled", "edge_gate_disabled")
        elif not math.isfinite(cost_r) or cost_r > config.EDGE_MAX_COST_R:
            d = make(False, "cost_gate", f"costs_eat_edge ({cost_r:.2f}R > {config.EDGE_MAX_COST_R}R)")
        else:
            est = self.calibrator.estimate(score, cost_r)
            rationale.append(f"bucket {est['bucket']}: n={est['n_bucket']}, est net EV={est['ev_r']:+.3f}R ± {est['se_r']:.3f}")
            if self.calibrator.n < config.EDGE_MIN_OBSERVATIONS:
                d = make(True, "exploration",
                         f"collecting evidence ({self.calibrator.n}/{config.EDGE_MIN_OBSERVATIONS} trades), reduced size",
                         est, config.EDGE_EXPLORATION_SIZE_MULT)
            elif est["ev_lower_r"] >= config.EDGE_MIN_EV_R:
                d = make(True, "calibrated", f"conservative net EV {est['ev_lower_r']:+.3f}R >= {config.EDGE_MIN_EV_R}R", est)
            else:
                d = make(False, "calibrated",
                         f"insufficient_edge (conservative net EV {est['ev_lower_r']:+.3f}R < {config.EDGE_MIN_EV_R}R)", est)
        self.recent.appendleft(d)
        return d
