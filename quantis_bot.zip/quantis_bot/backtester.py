"""
Backtesting Engine (v2: realistic, causal).

Design rules, each of which exists to stop the backtest flattering the strategy:
  * Signals are computed on bar i's CLOSE. The order can only fill at bar i+1's OPEN
    (never at the close that produced the signal).
  * Every fill pays fee + slippage + half-spread (edge.apply_costs).
  * Exits are checked against the stop that existed BEFORE the bar; the trailing stop
    is only ratcheted AFTER the bar, using that bar's close, for use on the next bar.
    If a bar gaps through the stop, the fill is at the (worse) open, not the stop.
  * If stop and take-profit are both touched in one bar, the stop is assumed first.
  * Equity is marked to market (open positions included) so drawdown isn't understated.
  * The net-edge gate learns only from trades that have already closed (no leakage).
  * Input data is validated first (duplicates, gaps, bad ticks).
Results are HISTORICAL SIMULATION results, not live performance.
"""
from collections import Counter
from dataclasses import dataclass

import numpy as np
import pandas as pd

import config
from signals import add_indicators, generate_signal, market_breadth
from risk import build_trade_plan, CircuitBreaker, check_pre_trade_gates, update_trailing_stop, passes_regime_filter
from correlation import compute_correlation_matrix
from capital import CapitalManager
from edge import DecisionMaker, apply_costs
from data_quality import validate_ohlcv


@dataclass
class BacktestTrade:
    symbol: str
    entry_time: object
    entry_price: float
    exit_time: object
    exit_price: float
    exit_reason: str          # take_profit | stop_loss | trailing_stop | end_of_data
    position_size_usdt: float
    signal_score: float
    pnl_usdt: float
    pnl_pct: float
    cost_usdt: float = 0.0
    r_multiple: float = 0.0
    strategy: str = None
    regime: str = None


class Backtester:
    def __init__(self, price_data: dict, starting_capital: float = None, db_path: str = ":memory:", strict_data: bool = True):
        cleaned, self.data_reports = {}, {}
        for sym, df in price_data.items():
            rep = validate_ohlcv(df, check_stale=False)
            self.data_reports[sym] = {"ok": rep.ok, "issues": rep.issues, "fatal": rep.fatal}
            if not rep.ok and strict_data:
                raise ValueError(f"Data quality failure for {sym}: {rep.fatal}")
            cleaned[sym] = rep.cleaned
        self.price_data = {sym: add_indicators(df) for sym, df in cleaned.items()}
        self.starting_capital = starting_capital or config.STARTING_CAPITAL
        self.capital = CapitalManager(db_path=db_path, starting_capital=self.starting_capital)
        self.decider = DecisionMaker()
        self.trades: list[BacktestTrade] = []
        self.open_positions = {}
        self.pending = {}
        self.rejections = Counter()
        self.equity_curve = []
        self._corr = None
        self._corr_i = -10**9
        self._bar_seconds = None

    # ------------------------------------------------------------------
    def _close_position(self, symbol, pos, ts, raw_exit, reason, circuit_breaker):
        fill = apply_costs(raw_exit, "sell")
        pnl = (fill - pos["entry_price"]) * pos["size_units"]
        cost = (pos["entry_price"] - pos["entry_raw"]) * pos["size_units"] + (raw_exit - fill) * pos["size_units"]
        r = pnl / pos["risk_usdt"] if pos["risk_usdt"] > 0 else 0.0
        self.trades.append(BacktestTrade(
            symbol=symbol, entry_time=pos["entry_time"], entry_price=pos["entry_price"],
            exit_time=ts, exit_price=fill, exit_reason=reason, position_size_usdt=pos["size_usdt"],
            signal_score=pos["score"], pnl_usdt=round(pnl, 4), pnl_pct=round((fill / pos["entry_price"] - 1) * 100, 4),
            cost_usdt=round(cost, 4), r_multiple=round(r, 4), strategy=pos.get("strategy"), regime=pos.get("regime"),
        ))
        self.capital.apply_trade_result(symbol, pnl, strategy=pos.get("strategy"), regime=pos.get("regime"))
        circuit_breaker.record_trade_result(pnl)
        self.decider.record_outcome(pos["score"], r)

    def run(self, warmup_bars: int = None):
        warmup = warmup_bars or max(config.EMA_SLOW, config.RSI_PERIOD, config.ATR_PERIOD, 40) + 5
        idx = None
        for df in self.price_data.values():
            idx = df.index if idx is None else idx.intersection(df.index)
        idx = idx.sort_values()
        if len(idx) > 1:
            self._bar_seconds = float(pd.Series(idx).diff().dt.total_seconds().median())

        cb = CircuitBreaker(capital_at_day_start=self.capital.trading_capital)
        current_day = None
        exposure_samples = []

        for i in range(warmup, len(idx)):
            ts = idx[i]
            if ts.date() != current_day:
                current_day = ts.date()
                cb.reset_for_new_day(self.capital.trading_capital)

            # 0. fill orders that were decided at the previous bar's close, at THIS bar's open
            for symbol, p in list(self.pending.items()):
                bar = self.price_data[symbol].loc[ts]
                raw_open = float(bar["open"])
                fill = apply_costs(raw_open, "buy")
                plan = build_trade_plan(symbol, fill, p["atr"], p["score"], self.capital.trading_capital, p["size_mult"])
                allowed, reason = check_pre_trade_gates(
                    plan, len(self.open_positions), 0.0, self.capital.trading_capital, cb,
                    open_symbols=list(self.open_positions.keys()), corr_matrix=self._corr,
                )
                if allowed and symbol not in self.open_positions:
                    self.open_positions[symbol] = {
                        "entry_price": plan.entry_price, "entry_raw": raw_open, "stop": plan.stop_loss_price,
                        "initial_stop": plan.stop_loss_price, "tp": plan.take_profit_price,
                        "size_units": plan.position_size_units, "size_usdt": plan.position_size_usdt,
                        "risk_usdt": plan.risk_usdt, "score": p["score"], "entry_time": ts,
                        "strategy": p.get("strategy"), "regime": p.get("regime"),
                    }
                else:
                    self.rejections[reason if not allowed else "duplicate_position"] += 1
            self.pending.clear()

            # 1. exits: test the stop that existed BEFORE this bar, then ratchet for the next one
            for symbol in list(self.open_positions.keys()):
                bar = self.price_data[symbol].loc[ts]
                pos = self.open_positions[symbol]
                raw_exit = reason = None
                if bar["low"] <= pos["stop"]:
                    raw_exit = min(pos["stop"], float(bar["open"]))          # gap-through fills at the worse open
                    reason = "trailing_stop" if pos["stop"] > pos["initial_stop"] else "stop_loss"
                elif bar["high"] >= pos["tp"]:
                    raw_exit, reason = pos["tp"], "take_profit"
                if raw_exit is not None:
                    self._close_position(symbol, pos, ts, raw_exit, reason, cb)
                    del self.open_positions[symbol]
                else:
                    pos["stop"] = update_trailing_stop(pos["entry_price"], pos["initial_stop"], float(bar["close"]), pos["stop"])

            # 2. mark-to-market equity (realized + unrealized)
            unreal = sum((float(self.price_data[s].loc[ts]["close"]) - p["entry_price"]) * p["size_units"]
                         for s, p in self.open_positions.items())
            equity = self.capital.total_equity() + unreal
            self.equity_curve.append({"ts": ts, "equity": equity})
            exposure_samples.append(sum(p["size_usdt"] for p in self.open_positions.values()) / equity if equity > 0 else 0)

            # 3. look for new signals on this bar's close -> pending orders for the NEXT open
            if i >= len(idx) - 1 or not cb.can_trade():
                continue
            scored = []
            for symbol, df in self.price_data.items():
                window = df.loc[:ts].tail(config.LOOKBACK_BARS)
                if len(window) < warmup:
                    continue
                r = generate_signal(window)
                r["symbol"] = symbol
                scored.append(r)
            if not scored:
                continue
            breadth = market_breadth(pd.DataFrame(scored))
            if config.USE_CORRELATION_GUARD and (i - self._corr_i >= config.CORRELATION_RECOMPUTE_EVERY_N_BARS or self._corr is None):
                self._corr = compute_correlation_matrix({s: d.loc[:ts].tail(config.CORRELATION_LOOKBACK_BARS) for s, d in self.price_data.items()})
                self._corr_i = i
            slots = config.MAX_CONCURRENT_POSITIONS - len(self.open_positions)
            for r in sorted(scored, key=lambda x: x["score"], reverse=True):
                if slots <= 0:
                    break
                sym = r["symbol"]
                if sym in self.open_positions or r["score"] < config.MIN_SCORE_TO_TRADE:
                    continue
                if not passes_regime_filter(breadth):
                    self.rejections["market_breadth_regime_filter"] += 1
                    continue
                bar = self.price_data[sym].loc[ts]
                atr = bar["atr"]
                if pd.isna(atr) or atr <= 0:
                    continue
                decision = self.decider.evaluate(sym, r, float(bar["close"]), float(atr), ts)
                if not decision.approved:
                    self.rejections[decision.reason.split(" (")[0]] += 1
                    continue
                self.pending[sym] = {"atr": float(atr), "score": r["score"], "size_mult": decision.size_multiplier,
                                     "strategy": r.get("strategy"), "regime": r.get("regime")}
                slots -= 1

        # close anything still open at the final close so the accounting is complete
        last_ts = idx[-1]
        for symbol in list(self.open_positions.keys()):
            self._close_position(symbol, self.open_positions[symbol], last_ts,
                                 float(self.price_data[symbol].loc[last_ts]["close"]), "end_of_data", cb)
            del self.open_positions[symbol]
        self._exposure = float(np.mean(exposure_samples)) if exposure_samples else 0.0
        self._first_ts = idx[warmup] if len(idx) > warmup else idx[0]
        return self.results()

    # ------------------------------------------------------------------
    def results(self) -> dict:
        if not self.trades:
            return {"trades": 0, "total_trades": 0, "rejections": dict(self.rejections),
                    "message": "No trades executed. With the net-edge gate on, this can simply mean no setup cleared costs."}
        df = pd.DataFrame([t.__dict__ for t in self.trades])
        wins, losses = df[df.pnl_usdt > 0], df[df.pnl_usdt <= 0]
        eq = pd.DataFrame(self.equity_curve)
        eq["running_max"] = eq["equity"].cummax()
        eq["drawdown"] = (eq["equity"] - eq["running_max"]) / eq["running_max"]
        final_equity = float(eq["equity"].iloc[-1]) if not eq.empty else self.capital.total_equity()

        rets = eq["equity"].pct_change().dropna()
        ppy = (365 * 24 * 3600 / self._bar_seconds) if self._bar_seconds else None
        sharpe = sortino = None
        if ppy and len(rets) > 10 and rets.std() > 0:
            sharpe = float(rets.mean() / rets.std() * np.sqrt(ppy))
            down = rets[rets < 0]
            if len(down) > 1 and down.std() > 0:
                sortino = float(rets.mean() / down.std() * np.sqrt(ppy))

        bh = []
        for sdf in self.price_data.values():
            seg = sdf.loc[self._first_ts:]["close"]
            if len(seg) > 1:
                bh.append(seg.iloc[-1] / seg.iloc[0] - 1)
        gross_win, gross_loss = wins.pnl_usdt.sum(), -losses.pnl_usdt.sum()
        return {
            "starting_capital": self.starting_capital,
            "final_equity": round(final_equity, 2),
            "total_return_pct": round((final_equity / self.starting_capital - 1) * 100, 2),
            "benchmark_buy_hold_pct": round(float(np.mean(bh)) * 100, 2) if bh else None,
            "total_trades": len(df), "wins": len(wins), "losses": len(losses),
            "win_rate_pct": round(len(wins) / len(df) * 100, 1),
            "avg_win_usdt": round(wins.pnl_usdt.mean(), 2) if len(wins) else 0.0,
            "avg_loss_usdt": round(losses.pnl_usdt.mean(), 2) if len(losses) else 0.0,
            "expected_value_per_trade_usdt": round(df.pnl_usdt.mean(), 3),
            "expected_value_per_trade_r": round(df.r_multiple.mean(), 3),
            "profit_factor": round(gross_win / gross_loss, 2) if gross_loss > 0 else None,
            "max_drawdown_pct": round(eq["drawdown"].min() * 100, 2),
            "sharpe_ratio": round(sharpe, 2) if sharpe is not None else None,
            "sortino_ratio": round(sortino, 2) if sortino is not None else None,
            "total_costs_usdt": round(df.cost_usdt.sum(), 2),
            "turnover_x_capital": round(df.position_size_usdt.sum() / self.starting_capital, 2),
            "avg_exposure_pct": round(self._exposure * 100, 2),
            "rejections": dict(self.rejections),
            "data_quality": self.data_reports,
            "label": "HISTORICAL BACKTEST (simulation) - not live performance",
            "capital_summary": self.capital.summary(),
            "trades_df": df, "equity_df": eq,
        }
