# Running Quantis Online for Free — Oracle Cloud "Always Free" Tier

## Why this platform specifically

I checked current pricing before writing this (September 2026), because free
tiers change constantly and I didn't want to hand you stale advice:

| Platform | Free tier reality in 2026 |
|---|---|
| Railway | **No free tier** — killed in 2023, only a one-time $5 trial credit |
| Fly.io | **No free tier** for accounts created after Oct 2024 — 2-hour trial only |
| Render | Has a real free tier, but web services **sleep after 15 minutes idle** and take ~30-60s to wake up |
| **Oracle Cloud "Always Free"** | **Genuinely free forever** — up to 4 ARM CPUs, 24GB RAM, no time limit, no sleep |

Render's sleep behavior is disqualifying for this specific use case: a
trading bot that goes to sleep stops watching the market, which defeats the
entire point. Oracle's Always Free tier is a real, persistent VM — the same
kind of always-on server `DEPLOYMENT.md` already walks through for a paid
VPS, just at $0/month. Everything in that file about systemd, Docker,
HTTPS, and the safety rails still applies here unchanged — this guide only
covers getting the free VM itself set up.

**The one tradeoff**: Oracle's free compute is ARM-based (Ampere A1), not
the x86 architecture most VPS guides assume. This bot's dependencies
(pandas, numpy, scikit-learn, ccxt, ta) all publish ARM-compatible wheels
for Linux — `pip install` works normally, no special steps. Flagging it so
it's not a mystery if you ever compare notes with an x86 tutorial.

## Step 1: Create the Oracle Cloud account

1. Go to https://www.oracle.com/cloud/free/ and sign up.
2. You'll be asked for a card for identity verification — Oracle explicitly
   does not charge it for Always Free resources, but do set a spending
   limit / budget alert in the console as a personal safety net regardless
   (Billing → Budgets).
3. Pick a home region close to you — this can't be changed later without
   creating a new account, and it affects latency to your exchange's API.

## Step 2: Create the VM instance

1. Console → Compute → Instances → **Create Instance**.
2. Name it (e.g. `quantis-bot`).
3. **Image and shape**: click "Edit" next to Image and Shape.
   - Image: **Ubuntu 24.04** (or latest LTS available).
   - Shape: click "Change Shape" → **Ampere** → **VM.Standard.A1.Flex**.
     Set **2 OCPUs / 12GB RAM** — comfortably within the Always Free
     allowance (4 OCPU / 24GB total, so this leaves room to run the
     dashboard and engine with headroom, or even a second small project).
4. **Networking**: leave the default VCN, ensure "Assign a public IPv4
   address" is checked.
5. **Add SSH keys**: choose "Generate a key pair for me" and **download both
   the public and private key immediately** — Oracle only shows them once.
   Alternatively paste your own public key if you already have one
   (`~/.ssh/id_ed25519.pub`).
6. Click **Create**. Provisioning takes a minute or two.

## Step 3: Open the firewall for HTTPS

Oracle's default security list blocks inbound traffic beyond SSH. Add rules
for the ports you'll need:

1. Instance details page → click the subnet link → **Security Lists** →
   click the default list → **Add Ingress Rules**.
2. Add two rules (Source CIDR `0.0.0.0/0` for both):
   - Destination Port 80 (HTTP — needed for Caddy's automatic HTTPS cert issuance)
   - Destination Port 443 (HTTPS)
3. Leave everything else closed. The bot's own port (5000) never needs to
   be open publicly — it stays behind the reverse proxy, exactly as
   `DEPLOYMENT.md` already describes.

Oracle ALSO runs `iptables` inside the VM itself as a second firewall layer
— the security list alone isn't enough. Once connected (Step 4), run:
```bash
sudo iptables -I INPUT -p tcp --dport 80 -j ACCEPT
sudo iptables -I INPUT -p tcp --dport 443 -j ACCEPT
sudo netfilter-persistent save   # persist across reboots (Ubuntu 24.04 has this preinstalled)
```

## Step 4: Connect and set up the server

```bash
chmod 600 /path/to/your-downloaded-private-key.key
ssh -i /path/to/your-downloaded-private-key.key ubuntu@<your-vm-public-ip>
```

From here, **`DEPLOYMENT.md`'s "Option A: A small VPS" section applies
exactly as written** — creating the `quantis` user, cloning the code,
setting up the virtualenv, the systemd service, and Caddy for HTTPS. The
only Oracle-specific step already happened above (opening ports 80/443 in
both the security list and iptables). Follow that section from
"Create a non-root user" onward.

## Getting the bot's code onto the VM

You have two options:

**Option A — GitHub (recommended, makes future updates a `git pull`):**
```bash
# On your own machine first, from the quantis_bot/ folder:
git init
# .gitignore is already included in this project -- it excludes the trade
# database, trained model files, and reports/ so you never accidentally
# commit trade history or secrets.
git add .
git commit -m "Initial commit"
# Create a new repo on github.com, then:
git remote add origin https://github.com/<your-username>/quantis-bot.git
git branch -M main
git push -u origin main
```
Then on the VM:
```bash
git clone https://github.com/<your-username>/quantis-bot.git /opt/quantis_bot
```
Make the repo **private** on GitHub if it contains anything sensitive —
though it shouldn't, since API keys and passwords are environment
variables, never committed (that's exactly what the `.gitignore` above and
the "never hardcode secrets" rule throughout this project are for).

**Option B — Direct upload (simpler for a one-time deploy, no GitHub needed):**
```bash
# From your own machine:
scp -i /path/to/your-key.key -r ./quantis_bot ubuntu@<your-vm-public-ip>:/tmp/
# Then on the VM:
sudo mv /tmp/quantis_bot /opt/quantis_bot
```
This works fine, but every future code change means re-uploading everything
by hand. GitHub is worth the ten extra minutes of setup the first time.

## Verifying it's actually running

```bash
sudo systemctl status quantis   # should show "active (running)"
curl http://127.0.0.1:5000/healthz   # {"status": "ok", ...}
journalctl -u quantis -f            # live logs, Ctrl+C to stop watching
```
From your own machine/phone: `https://your-domain.com` (or the SSH-tunnel
approach in `DEPLOYMENT.md` if you're not using a domain yet).

## What "free forever" actually means here

Oracle's Always Free resources don't expire or convert to paid after a
trial period, unlike every other platform's "free tier" in the comparison
table above. The one real risk: Oracle has been known to reclaim
long-idle Always Free instances (their terms mention inactivity
reclamation) — since this bot runs continuously and gets HTTP traffic
from your own dashboard checks, that's not a practical concern for an
actively-used deployment, but it's worth knowing the clause exists if you
ever stop checking in on it for months at a time.
