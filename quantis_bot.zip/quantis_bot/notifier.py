"""
Unified notifier — fans out a message to every enabled channel (Telegram,
WhatsApp). Call this one function from anywhere in the bot; channel-specific
logic and credentials stay in their own modules.
"""
from telegram_notifier import send_telegram
from whatsapp_notifier import send_whatsapp
import config


def notify(message: str):
    """Sends to every enabled channel. Never raises -- a notification
    failure should never crash the trading loop."""
    results = {}
    try:
        results["telegram"] = send_telegram(message)
    except Exception as e:
        print(f"[Quantis] notify() telegram error: {e}")
        results["telegram"] = False
    try:
        results["whatsapp"] = send_whatsapp(message)
    except Exception as e:
        print(f"[Quantis] notify() whatsapp error: {e}")
        results["whatsapp"] = False
    return results


def notify_trade_opened(symbol, score, size_usdt):
    notify(f"🟢 Opened {symbol}\nSignal score: {score}\nSize: ${size_usdt:.2f}")


def notify_trade_closed(symbol, reason, pnl_usdt):
    emoji = "✅" if pnl_usdt > 0 else "🔴"
    notify(f"{emoji} Closed {symbol} ({reason})\nP&L: {pnl_usdt:+.2f} USDT")


def notify_circuit_breaker():
    notify("⚠️ Daily loss circuit breaker TRIPPED — trading paused for the rest of the day.")


def notify_daily_report(summary_text: str):
    notify(summary_text)
