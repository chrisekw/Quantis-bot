# Deploying Quantis Online — Running It Autonomously

This covers taking the bot from "runs on my laptop" to "runs 24/7 on a server,"
plus what changes about the risk picture when you do that.

## Before you deploy anywhere — read this

Everything in `README.md` about the paper-trading gate still applies. Putting
the bot on a server makes it run continuously and unattended — it does **not**
make the strategy more validated. Deploy the dashboard early (it's useful for
monitoring), but keep `USE_TESTNET = True` in `config.py` until you've done the
4–8 weeks of paper trading described in the plan. Autonomous operation of an
unvalidated strategy just means it can lose money faster while you're not
watching.

## What "autonomous" requires beyond what you've already built

| Concern | Why it matters | What's in place |
|---|---|---|
| **Dashboard auth** | Anyone who finds the URL could see your capital or stop the bot | HTTP Basic Auth, required whenever bound to a non-local address (`server.py` refuses to start without it) |
| **Process supervision** | The process WILL crash eventually (network blip, exchange downtime) — it needs to restart itself | `quantis.service` (systemd) or Docker's `restart: unless-stopped` |
| **Secrets not in code** | Exchange API keys and dashboard password must never be in a committed file | Everything reads from environment variables (`QUANTIS_API_KEY`, `QUANTIS_DASHBOARD_PASSWORD`, etc.) |
| **Persistent storage** | The SQLite ledger and daily reports must survive restarts/redeploys | Docker volumes / a real disk path outside the app directory — see below |
| **Alerts when something breaks** | An unattended bot that silently stops trading (or silently keeps losing) is the worst case | Telegram alerts (`telegram_notifier.py`) — set these up before going live, not after |
| **HTTPS** | Basic Auth over plain HTTP sends your password in the clear | Put a reverse proxy (Caddy or nginx) in front — see below |

## Option A: A small VPS (DigitalOcean, Linode, Hetzner — recommended for a first-time deploy)

1. **Spin up the smallest Ubuntu 22.04/24.04 droplet.** This bot is lightweight —
   the cheapest tier (1 vCPU, 1GB RAM, ~$4–6/mo) is plenty.

2. **Create a non-root user and clone/copy the project:**
   ```bash
   adduser quantis
   su - quantis
   mkdir -p /opt/quantis_bot && cd /opt/quantis_bot
   # copy the quantis_bot/ folder here (scp, git, whatever you prefer)
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Set real secrets** (don't put these in `config.py`):
   ```bash
   export QUANTIS_API_KEY="your_testnet_or_live_key"
   export QUANTIS_API_SECRET="your_secret"
   export QUANTIS_DASHBOARD_USER="admin"
   export QUANTIS_DASHBOARD_PASSWORD="something-long-and-random"
   ```
   Better: put these in `/etc/quantis.env` (root-owned, `chmod 600`) and reference
   it from the systemd unit with `EnvironmentFile=`.

4. **Install the systemd service:**
   ```bash
   sudo cp quantis.service /etc/systemd/system/quantis.service
   sudo systemctl daemon-reload
   sudo systemctl enable --now quantis
   sudo systemctl status quantis   # confirm it's running
   journalctl -u quantis -f        # tail logs
   ```

5. **Put a reverse proxy in front for HTTPS.** Easiest option is Caddy —
   it gets you free auto-renewing HTTPS with almost no config:
   ```bash
   sudo apt install -y caddy
   ```
   `/etc/caddy/Caddyfile`:
   ```
   yourdomain.com {
       reverse_proxy 127.0.0.1:5000
   }
   ```
   ```bash
   sudo systemctl restart caddy
   ```
   Now the dashboard is at `https://yourdomain.com`, Basic Auth password
   protected, over HTTPS. If you don't have a domain, bind the app to
   `127.0.0.1` only and access it via SSH tunnel instead:
   ```bash
   ssh -L 5000:127.0.0.1:5000 quantis@your-server-ip
   # then open http://127.0.0.1:5000 on your own machine
   ```
   This avoids exposing the port publicly at all — the most conservative option.

6. **Firewall:** only open 22 (SSH) and 443 (HTTPS) if using Caddy; nothing else.
   ```bash
   sudo ufw allow 22
   sudo ufw allow 443
   sudo ufw enable
   ```

## Option B: Docker (works on the same VPS, or any Docker host)

```bash
docker build -t quantis-bot .
docker run -d --name quantis \
  --restart unless-stopped \
  -p 127.0.0.1:5000:5000 \
  -e QUANTIS_DASHBOARD_USER=admin \
  -e QUANTIS_DASHBOARD_PASSWORD="something-long-and-random" \
  -e QUANTIS_API_KEY="your_key" \
  -e QUANTIS_API_SECRET="your_secret" \
  -v quantis_reports:/app/reports \
  -v quantis_data:/app/data \
  quantis-bot
```
Note `-p 127.0.0.1:5000:5000` — this binds only to localhost on the host;
combine with the Caddy or SSH-tunnel approach above rather than publishing
`-p 5000:5000` directly to the internet.

## Option C: Platform-as-a-service (Railway, Render, Fly.io)

These work too and remove most of the server-admin steps above, but two things
to check on whichever you pick:
- **Persistent disk**: the SQLite ledger and `reports/` folder need to survive
  redeploys. Most of these platforms need an explicit "volume" or "persistent
  disk" add-on — without it, your trade history resets every deploy.
- **Single instance**: don't let the platform auto-scale this to multiple
  instances. The trading engine's state lives in one process's memory
  (see the `--workers 1` note in the Dockerfile) — two instances would each
  run an independent, uncoordinated copy of the bot.

## Going from paper → live capital, on a deployed bot

1. Complete the 4–8 week paper trading period with `USE_TESTNET = True` and
   review the daily reports honestly (Section 08 of the plan).
2. Only then, on your server: set `USE_TESTNET = False` in `config.py`,
   swap in your real (non-testnet) exchange API keys with **trading-only
   permissions, no withdrawal rights**, and redeploy.
3. Start with the small real-capital amount from Section 10 of the plan
   ($200–$1,000) — deploying it "online" doesn't change that guidance.
4. Watch the first 48 hours closely. The daily circuit breaker and hard
   stop-losses are there so a bad day doesn't become a bad month, but you
   should still be watching, especially right after any change.
