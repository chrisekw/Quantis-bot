# Deploying the Dashboard to Vercel

## Read this first — the honest architecture

Vercel serverless functions are stateless and short-lived — they cannot run
the always-on trading engine (`demo_engine.py` / `paper_trader.py` /
`live_engine.py`), which needs a persistent background loop and in-memory
state. This is a real platform limitation, not a configuration issue:

- **Vercel Hobby plan**: cron jobs run at most **once per day**. Useless for
  active trading, which needs to check the market every few minutes.
- **Vercel Pro plan**: cron jobs can run **once per minute**, but each
  invocation is a fresh, stateless function call — it can't hold open
  positions in memory between calls, so it would need every piece of state
  (open positions, capital ledger, circuit breaker status) moved to an
  external database and reloaded on every single invocation. That's a much
  bigger rebuild than what's in this codebase today, and isn't included here.

So: **the trading engine and its API stay on your VPS** (see `DEPLOYMENT.md`
— that part is unchanged and already fully tested). What Vercel hosts here
is the **dashboard frontend**, calling your VPS's API over HTTPS from
anywhere in the world. This gets you the actual outcome you asked for — a
Vercel URL you can open on your phone or laptop to watch the bot — without
pretending a serverless platform can run a 24/7 trading loop.

## What's in `vercel_frontend/`

A plain static copy of the dashboard (`index.html`, `static/`) with one
difference from the VPS-served version: instead of calling `/api/...` on
the same origin, it calls `window.QUANTIS_API_BASE + "/api/..."`, configured
in `static/config.js`.

## Setup

### 1. Deploy your backend first (if you haven't already)
Follow `DEPLOYMENT.md` to get `server.py` running on a VPS behind HTTPS
(Caddy or nginx). You need a real domain with a valid cert — browsers block
a Vercel page (always HTTPS) from calling an HTTP-only API.

### 2. Lock down CORS to your Vercel domain
By default `server.py` allows any origin (`QUANTIS_CORS_ORIGIN` env var,
defaults to `*`) so this is easy to test. Once you know your Vercel URL,
restrict it:
```bash
export QUANTIS_CORS_ORIGIN="https://your-project.vercel.app"
```
Restart the backend after setting this.

### 3. Point the frontend at your backend
Edit `vercel_frontend/static/config.js`:
```js
window.QUANTIS_API_BASE = "https://your-vps-domain.com";
```

### 4. Deploy to Vercel
```bash
cd vercel_frontend
npx vercel deploy --prod
```
Or connect the `vercel_frontend/` folder as a project root in the Vercel
dashboard (import from Git, set "Root Directory" to `vercel_frontend`).
No build step needed — it's static HTML/CSS/JS.

### 5. Auth still applies
The backend's HTTP Basic Auth (`QUANTIS_DASHBOARD_USER` /
`QUANTIS_DASHBOARD_PASSWORD`) still guards every `/api/*` call — the browser
will prompt for credentials the first time the Vercel-hosted page calls your
API. This is your only login layer; there's nothing extra to configure on
the Vercel side.

## If you genuinely want zero VPS (fully serverless)

Possible on Vercel Pro, but requires rebuilding the engine's state handling
around an external database (e.g., a free-tier Postgres from Neon or
Supabase) so a stateless per-minute cron function can read positions/ledger
in, do one decision cycle, and write state back out every invocation. That's
a materially different codebase from the always-on `DemoEngine` /
`PaperTrader` / `LiveEngine` classes built here, and isn't something I could
build and actually test from this sandbox (no outbound access to Vercel,
Postgres, or a real exchange). If you want to go this route later, say so
and we can design that rebuild specifically — it's a real option, just not
a drop-in with what exists today.
