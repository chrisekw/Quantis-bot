"""
Quantis Bot — Central Configuration
All risk, capital, and trading parameters live here.
Change these before running — do not hardcode values elsewhere.
"""

# EXCHANGE
EXCHANGE_ID = "binance"
USE_TESTNET = True
API_KEY = ""
API_SECRET = ""

# UNIVERSE
SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
TIMEFRAME = "1h"
LOOKBACK_BARS = 300

# SIGNAL SCORING
EMA_FAST = 20
EMA_SLOW = 50
RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
ATR_PERIOD = 14
MIN_SCORE_TO_TRADE = 60

# RISK MANAGEMENT
RISK_PER_TRADE_PCT = 0.01
MAX_CONCURRENT_POSITIONS = 4
DAILY_LOSS_CIRCUIT_BREAKER_PCT = 0.05
MAX_ALLOCATION_PER_ASSET_PCT = 0.20
REWARD_RISK_RATIO = 2.0
MAX_LEVERAGE = 1

# CAPITAL / PROFIT SEPARATION
STARTING_CAPITAL = 500.0
PROFIT_TO_VAULT_PCT = 0.5

# FEES
TAKER_FEE_PCT = 0.001
SLIPPAGE_PCT = 0.0005

# REPORTING
REPORTS_DIR = "reports"
LEDGER_DB_PATH = "quantis_ledger.sqlite3"

# TELEGRAM ALERTS (optional)
TELEGRAM_ENABLED = False
TELEGRAM_BOT_TOKEN = ""
TELEGRAM_CHAT_ID = ""

# TRAILING STOP (profitability optimization -- let winners run, cut losers fast)
TRAIL_ACTIVATION_R = 1.0   # once price moves 1x the initial risk distance in our favor, move stop to breakeven
TRAIL_DISTANCE_R = 1.0     # after activation, trail the stop this many R behind the current price

# MARKET REGIME FILTER (profitability optimization -- don't fight the overall market)
USE_REGIME_FILTER = True
MARKET_BREADTH_MIN = 0.4   # require at least this fraction of the scanned universe to be in an uptrend
                            # before opening NEW long positions -- avoids buying dips in a broad downtrend

# SPEED / EXECUTION
ASYNC_FETCH = True         # fetch all symbols concurrently instead of sequentially
POLL_SECONDS_LIVE = 60     # how often the live engine re-scans the market

# MACHINE LEARNING / ADAPTIVE LEARNING ("brain")
ML_MIN_SAMPLES_TO_TRAIN = 40   # need at least this many closed trades before training a model at all
ML_MIN_SAMPLES_TO_ACT = 80     # need at least this many before the model is allowed to influence decisions
ML_BLEND_WEIGHT = 0.3          # final_score = rule_score * (1-w) + (ml_probability*100) * w -- rules still dominate
ML_RETRAIN_EVERY_N_TRADES = 10 # retrain after this many new closed trades

# LIVE TRADING READINESS GATE (do not lower these to "get to live" faster)
LIVE_MIN_PAPER_DAYS = 28
LIVE_MIN_PAPER_TRADES = 30
LIVE_MIN_WIN_RATE_PCT = 35.0    # sanity floor, not a profitability guarantee
LIVE_MAX_DRAWDOWN_PCT_ALLOWED = 25.0

# WHATSAPP (via Twilio) + TELEGRAM NOTIFICATIONS
WHATSAPP_ENABLED = False
TWILIO_ACCOUNT_SID = ""
TWILIO_AUTH_TOKEN = ""
TWILIO_WHATSAPP_FROM = ""   # e.g. "whatsapp:+14155238886" (Twilio sandbox number)
WHATSAPP_TO_NUMBER = ""     # e.g. "whatsapp:+2349XXXXXXXX"

# ANALYTICS REPORT CADENCE
ANALYTICS_SEND_DAILY = True
ANALYTICS_SEND_WEEKLY = True

# REGIME-ADAPTIVE STRATEGY (sophistication upgrade -- Section 04 of the plan
# recommended running trend-following AND mean-reversion as complementary
# strategies for different market conditions, not just one strategy always).
USE_MEAN_REVERSION = True
ADX_PERIOD = 14
ADX_TRENDING_THRESHOLD = 22     # ADX above this -> market considered "trending" -> trend-following logic applies
ADX_CHOPPY_THRESHOLD = 18       # ADX below this -> market considered "choppy/ranging" -> mean-reversion logic applies
                                  # (the gap between the two thresholds is a "neutral" zone where neither fires --
                                  # avoids flip-flopping strategy on every small ADX wiggle)
MEAN_REVERSION_RSI_OVERSOLD = 25   # mean-reversion longs only trigger this deep into oversold
MEAN_REVERSION_BB_ENTRY_PCT = 0.05 # price must be within this fraction of the lower Bollinger Band

# CORRELATION / DIVERSIFICATION GUARD (sophistication upgrade -- don't let
# 4 "different" positions actually be one leveraged bet on the same move)
USE_CORRELATION_GUARD = True
CORRELATION_LOOKBACK_BARS = 100
CORRELATION_RECOMPUTE_EVERY_N_BARS = 20   # correlation structure changes slowly -- recomputing every
                                            # single bar/tick is wasted CPU for no real gain in accuracy
CORRELATION_HIGH_THRESHOLD = 0.75   # symbols correlated above this are treated as "the same bet"
MAX_POSITIONS_PER_CORRELATION_CLUSTER = 1   # of the open positions, at most this many may be mutually
                                              # highly-correlated with each other

# VOLUME CONFIRMATION (sophistication upgrade -- don't trust a signal on
# unusually thin volume, which is more likely noise or a stale/illiquid market)
USE_VOLUME_CONFIRMATION = True
VOLUME_MA_PERIOD = 20
VOLUME_MIN_RATIO = 0.6   # current bar's volume must be at least this fraction of its recent average

# LEARNER MODEL UPGRADE
# Default stays logistic_regression: it's the more data-efficient, harder-to-
# overfit choice, which matters because a personal bot generates maybe a
# few hundred trades a YEAR. Testing during development showed gradient
# boosting did NOT reliably beat logistic regression's baseline at ~150
# samples (walk-forward validation correctly caught this) -- it's a real
# option for later, once you have substantially more trade history, not a
# default upgrade. Switch this once your Analytics tab's walk-forward
# accuracy for gradient_boosting is consistently beating logistic_regression's.
ML_MODEL_TYPE = "logistic_regression"   # "logistic_regression" or "gradient_boosting"
ML_WALK_FORWARD_FOLDS = 4               # time-series cross-validation folds for honest out-of-sample reporting

# BUY-AND-HOLD BENCHMARK (honesty check -- Section 02 of the plan flagged
# that many "profitable" bots still underperform simply holding the asset.
# This tracks that comparison directly in the dashboard rather than letting
# it go unchecked.)
BENCHMARK_SYMBOL = "BTC/USDT"

# ══════════════════════════════════════════════════════════════════════════
# NET-EDGE GATE (replaces "trade whenever score >= N" with "trade only when
# expected return AFTER realistic costs is positive, as measured from this
# bot's own recorded outcomes"). See edge.py.
# ══════════════════════════════════════════════════════════════════════════
USE_EDGE_GATE = True
SPREAD_ASSUMPTION_PCT = 0.0004      # assumed round-trip bid/ask spread cost (0.04%); half is charged per side
EDGE_MIN_OBSERVATIONS = 40          # closed trades needed before the gate trusts its own statistics
EDGE_MIN_EV_R = 0.05                # calibrated mode: conservative expected net return must beat this (in R units)
EDGE_MAX_COST_R = 0.30              # any mode: round-trip costs may not exceed this fraction of the risk taken
EDGE_PRIOR_STRENGTH = 20            # pseudo-observations pulling bucket estimates toward the cautious prior
EDGE_CONFIDENCE_Z = 1.0             # lower-bound = mean - Z * standard error
EDGE_EXPLORATION_SIZE_MULT = 0.5    # before enough evidence exists, trade at half size to gather data cheaply

# DATA QUALITY (see data_quality.py)
DQ_MAX_JUMP_PCT = 0.30              # single-bar close-to-close move above this is treated as a bad tick
DQ_MAX_STALE_BARS = 3               # latest candle older than this many bars => stale => no new decisions
DQ_RECENT_GAP_WINDOW = 50           # missing candles inside this many recent bars are fatal
