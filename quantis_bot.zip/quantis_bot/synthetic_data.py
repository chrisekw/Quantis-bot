"""
Synthetic OHLCV generator -- FOR LOCAL TESTING OF THE PIPELINE ONLY.
This is NOT a substitute for real historical data. It exists only so we can
verify the backtester's mechanics (position sizing, stop/TP logic, capital
ledger, circuit breaker) run correctly end-to-end without needing live
exchange access. Real strategy validation must use real historical data
(Section 08 of the plan) -- run this bot's backtester against real Binance
data on your own machine.
"""
import numpy as np
import pandas as pd


def generate_synthetic_ohlcv(
    shared_index, start_price=100.0, annual_drift=0.15, annual_vol=0.6,
    timeframe_hours=1, seed=None
):
    rng = np.random.default_rng(seed)
    n_bars = len(shared_index)
    dt = timeframe_hours / (24 * 365)
    mu = annual_drift
    sigma = annual_vol

    returns = rng.normal(mu * dt, sigma * np.sqrt(dt), n_bars)
    for start in range(0, n_bars, 300):
        regime_len = min(150, n_bars - start)
        regime_drift = rng.choice([-1, 1]) * rng.uniform(0.3, 1.2)
        returns[start:start+regime_len] += regime_drift * mu * dt

    shock_idxs = rng.choice(n_bars, size=max(1, n_bars // 500), replace=False)
    returns[shock_idxs] += rng.normal(0, sigma * 4 * np.sqrt(dt), size=len(shock_idxs))

    close = start_price * np.exp(np.cumsum(returns))

    high = close * (1 + np.abs(rng.normal(0, sigma * np.sqrt(dt) * 0.6, n_bars)))
    low = close * (1 - np.abs(rng.normal(0, sigma * np.sqrt(dt) * 0.6, n_bars)))
    open_ = np.roll(close, 1)
    open_[0] = start_price
    volume = rng.uniform(1000, 5000, n_bars)

    df = pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
        index=shared_index,
    )
    df["high"] = df[["open", "close", "high"]].max(axis=1)
    df["low"] = df[["open", "close", "low"]].min(axis=1)
    return df


def generate_test_universe(symbols, n_bars=2000, timeframe_hours=1, seed=42):
    # All symbols share ONE timestamp index so the backtester can align them.
    shared_index = pd.date_range(end=pd.Timestamp.now().floor("h"), periods=n_bars, freq=f"{timeframe_hours}h")
    out = {}
    for i, sym in enumerate(symbols):
        out[sym] = generate_synthetic_ohlcv(
            shared_index, start_price=100 * (i + 1),
            timeframe_hours=timeframe_hours, seed=seed + i,
        )
    return out
