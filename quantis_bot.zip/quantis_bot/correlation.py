"""
Correlation / Diversification Guard.

Four "different" open positions that are all 90% correlated with each other
aren't diversified — they're one leveraged bet on the same market move
wearing four different tickers. This module computes rolling correlation
across the scanned universe and blocks a new position if it would push too
much concentrated exposure into one correlation cluster.
"""
import pandas as pd
import numpy as np

import config


def compute_correlation_matrix(price_data: dict) -> pd.DataFrame:
    """
    price_data: {symbol: OHLCV dataframe}. Returns a symbol x symbol Pearson
    correlation matrix of recent returns (not price levels -- price-level
    correlation is dominated by both assets trending up over years, which
    tells you nothing about whether they move together day to day).
    """
    returns = {}
    for symbol, df in price_data.items():
        closes = df["close"].tail(config.CORRELATION_LOOKBACK_BARS)
        if len(closes) < 10:
            continue
        returns[symbol] = closes.pct_change().dropna()

    if len(returns) < 2:
        return pd.DataFrame()

    aligned = pd.DataFrame(returns).dropna()
    if len(aligned) < 10:
        return pd.DataFrame()

    return aligned.corr()


def would_exceed_cluster_cap(candidate_symbol: str, open_symbols: list, corr_matrix: pd.DataFrame) -> tuple:
    """
    Returns (blocked: bool, reason: str). Checks whether adding
    candidate_symbol would create a correlation cluster (mutually correlated
    above CORRELATION_HIGH_THRESHOLD) larger than MAX_POSITIONS_PER_CORRELATION_CLUSTER
    among currently-open positions.
    """
    if not config.USE_CORRELATION_GUARD or corr_matrix.empty:
        return False, "guard_disabled_or_no_data"
    if candidate_symbol not in corr_matrix.columns:
        return False, "symbol_not_in_correlation_matrix"

    highly_correlated_open = []
    for sym in open_symbols:
        if sym == candidate_symbol or sym not in corr_matrix.columns:
            continue
        corr = corr_matrix.loc[candidate_symbol, sym]
        if pd.notna(corr) and abs(corr) >= config.CORRELATION_HIGH_THRESHOLD:
            highly_correlated_open.append((sym, round(float(corr), 2)))

    if len(highly_correlated_open) >= config.MAX_POSITIONS_PER_CORRELATION_CLUSTER:
        return True, f"already {len(highly_correlated_open)} correlated open position(s): {highly_correlated_open}"

    return False, "ok"
