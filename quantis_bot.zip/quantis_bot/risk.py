"""
Risk Management — Section 05 of the plan, implemented as code (not a habit
you have to remember under stress).

Every function here is designed to be called BEFORE a trade is placed.
If any check fails, the trade must not happen. No exceptions.
"""
from dataclasses import dataclass
import config


@dataclass
class TradePlan:
    symbol: str
    side: str                # "buy" for spot long
    entry_price: float
    stop_loss_price: float
    take_profit_price: float
    position_size_usdt: float
    position_size_units: float
    risk_usdt: float
    signal_score: float


class CircuitBreaker:
    """Tracks realized loss for the current trading day. Halts new trades if
    losses hit the configured daily threshold."""

    def __init__(self, capital_at_day_start: float):
        self.capital_at_day_start = capital_at_day_start
        self.realized_pnl_today = 0.0
        self.tripped = False

    def record_trade_result(self, pnl_usdt: float):
        self.realized_pnl_today += pnl_usdt
        loss_pct = -self.realized_pnl_today / self.capital_at_day_start if self.capital_at_day_start > 0 else 0
        if loss_pct >= config.DAILY_LOSS_CIRCUIT_BREAKER_PCT:
            self.tripped = True

    def can_trade(self) -> bool:
        return not self.tripped

    def reset_for_new_day(self, capital_at_day_start: float):
        self.capital_at_day_start = capital_at_day_start
        self.realized_pnl_today = 0.0
        self.tripped = False


def calc_position_size(
    trading_capital: float,
    entry_price: float,
    stop_loss_price: float,
    signal_score: float,
) -> dict:
    """
    Position sizing formula (Section 05):
        risk_usdt = trading_capital * RISK_PER_TRADE_PCT
        position_size_units = risk_usdt / abs(entry_price - stop_loss_price)

    Higher signal scores get a size multiplier (within a hard cap) — this is
    how "higher stakes for good signals, lower stakes for weaker signals"
    gets implemented safely: the risk-per-trade % never changes, only how
    much of the allowed risk budget is used.
    """
    stop_distance = abs(entry_price - stop_loss_price)
    if stop_distance <= 0:
        raise ValueError("Stop-loss distance must be > 0")

    base_risk_usdt = trading_capital * config.RISK_PER_TRADE_PCT

    # Signal-strength multiplier: score 60 -> 0.6x of base risk, score 100 -> 1.0x
    # Never exceeds 1.0x of the configured per-trade risk cap.
    score_multiplier = max(0.4, min(1.0, signal_score / 100))
    risk_usdt = base_risk_usdt * score_multiplier

    position_size_units = risk_usdt / stop_distance
    position_size_usdt = position_size_units * entry_price

    # Hard cap: never exceed max allocation per asset regardless of formula output
    max_position_usdt = trading_capital * config.MAX_ALLOCATION_PER_ASSET_PCT
    if position_size_usdt > max_position_usdt:
        position_size_usdt = max_position_usdt
        position_size_units = position_size_usdt / entry_price
        risk_usdt = position_size_units * stop_distance

    return {
        "risk_usdt": round(risk_usdt, 2),
        "position_size_usdt": round(position_size_usdt, 2),
        "position_size_units": position_size_units,
        "score_multiplier": round(score_multiplier, 2),
    }


def build_trade_plan(
    symbol: str,
    entry_price: float,
    atr: float,
    signal_score: float,
    trading_capital: float,
    size_multiplier: float = 1.0,
) -> TradePlan:
    """
    Builds a complete, risk-checked trade plan using ATR-based stop distance
    (a volatility-adjusted stop is far more robust than a fixed % stop).
    """
    stop_loss_price = entry_price - (1.5 * atr)   # 1.5x ATR stop, long-only v1
    take_profit_price = entry_price + (1.5 * atr * config.REWARD_RISK_RATIO)

    sizing = calc_position_size(trading_capital, entry_price, stop_loss_price, signal_score)
    if size_multiplier != 1.0:   # e.g. half size while the edge gate is still gathering evidence
        m = max(0.0, min(1.0, size_multiplier))
        sizing = dict(sizing)
        sizing["risk_usdt"] = round(sizing["risk_usdt"] * m, 2)
        sizing["position_size_usdt"] = round(sizing["position_size_usdt"] * m, 2)
        sizing["position_size_units"] = sizing["position_size_units"] * m

    return TradePlan(
        symbol=symbol,
        side="buy",
        entry_price=entry_price,
        stop_loss_price=round(stop_loss_price, 6),
        take_profit_price=round(take_profit_price, 6),
        position_size_usdt=sizing["position_size_usdt"],
        position_size_units=sizing["position_size_units"],
        risk_usdt=sizing["risk_usdt"],
        signal_score=signal_score,
    )


def check_pre_trade_gates(
    trade_plan: TradePlan,
    open_positions_count: int,
    current_allocation_in_symbol_usdt: float,
    trading_capital: float,
    circuit_breaker: CircuitBreaker,
    open_symbols: list = None,
    corr_matrix=None,
    decision=None,
) -> tuple[bool, str]:
    """
    Final gate before any order is sent. Returns (allowed: bool, reason: str).
    ALL checks must pass. open_symbols + corr_matrix are optional -- when
    provided (see correlation.py), adds the diversification guard; when
    omitted, that check is simply skipped (keeps this function backward
    compatible with callers that don't yet compute correlation).
    """
    if not circuit_breaker.can_trade():
        return False, "daily_circuit_breaker_tripped"

    if decision is not None and not decision.approved:
        return False, f"edge_gate: {decision.reason}"

    if open_symbols is not None and corr_matrix is not None:
        from correlation import would_exceed_cluster_cap
        blocked, corr_reason = would_exceed_cluster_cap(trade_plan.symbol, open_symbols, corr_matrix)
        if blocked:
            return False, f"correlation_guard: {corr_reason}"

    if open_positions_count >= config.MAX_CONCURRENT_POSITIONS:
        return False, "max_concurrent_positions_reached"

    projected_allocation = current_allocation_in_symbol_usdt + trade_plan.position_size_usdt
    # +0.011 tolerance: sizes are rounded to cents, and a position capped at exactly the limit
    # must not be rejected because rounding pushed it half a cent over.
    if projected_allocation > trading_capital * config.MAX_ALLOCATION_PER_ASSET_PCT + 0.011:
        return False, "max_allocation_per_asset_exceeded"

    if trade_plan.position_size_usdt <= 0:
        return False, "zero_or_negative_position_size"

    if trade_plan.signal_score < config.MIN_SCORE_TO_TRADE:
        return False, "signal_score_below_threshold"

    min_notional = 10.0  # typical exchange minimum order size
    if trade_plan.position_size_usdt < min_notional:
        return False, "position_size_below_exchange_minimum"

    return True, "ok"


def update_trailing_stop(entry_price: float, initial_stop: float, current_price: float, current_stop: float) -> float:
    """
    Trailing stop logic (profitability optimization):
      - R = initial risk distance (entry - initial_stop)
      - Once price has moved TRAIL_ACTIVATION_R * R in our favor, move the stop
        to breakeven (entry price) -- the trade can no longer become a loss.
      - Once price moves further, trail the stop TRAIL_DISTANCE_R * R behind the
        current price, locking in more profit as the trade continues to work.
    Only ever moves the stop UP (for a long), never down -- a trailing stop must
    be monotonic or it isn't protecting anything.
    """
    r = entry_price - initial_stop
    if r <= 0:
        return current_stop

    gain_in_r = (current_price - entry_price) / r

    new_stop = current_stop
    if gain_in_r >= config.TRAIL_ACTIVATION_R:
        breakeven_stop = entry_price
        trailing_stop = current_price - (config.TRAIL_DISTANCE_R * r)
        candidate = max(breakeven_stop, trailing_stop)
        new_stop = max(current_stop, candidate)

    return new_stop


def passes_regime_filter(breadth: float) -> bool:
    """Returns True if the broad market is healthy enough to open new longs."""
    if not config.USE_REGIME_FILTER:
        return True
    return breadth >= config.MARKET_BREADTH_MIN


def blend_ml_score(rule_score: float, ml_win_probability) -> float:
    """
    Blends the rules-based signal score (0-100) with the learner's predicted
    win probability (0-1), if available. Rules always dominate (see
    config.ML_BLEND_WEIGHT, default 0.3) -- the model can nudge the score,
    not override the underlying strategy logic.
    """
    if ml_win_probability is None:
        return rule_score
    ml_component = ml_win_probability * 100
    w = config.ML_BLEND_WEIGHT
    blended = rule_score * (1 - w) + ml_component * w
    return round(float(max(0, min(100, blended))), 1)
