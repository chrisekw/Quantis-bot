"""
Analytics — computes real performance statistics from the trade ledger and
trade_features table. Powers both the dashboard Analytics tab and the
periodic Telegram/WhatsApp summary messages.

Every number here is computed from actual recorded trades (capital.py's
ledger table + learner.py's trade_features table) -- nothing here is
simulated or estimated when real data exists.
"""
import sqlite3
from datetime import datetime, timedelta

import re
import numpy as np
import pandas as pd

import config


_TAG_RE = re.compile(r"\[strategy=(\w+) regime=(\w+)\]")


def _parse_tags(note: str) -> tuple:
    """Extracts the (strategy, regime) tags capital.py prepends to each
    trade_close ledger note. Returns (None, None) for older rows recorded
    before this tagging existed -- handled gracefully, not an error."""
    if not isinstance(note, str):
        return None, None
    m = _TAG_RE.search(note)
    if not m:
        return None, None
    return m.group(1), m.group(2)


def _load_ledger_df(db_path: str) -> pd.DataFrame:
    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql(
            "SELECT * FROM ledger WHERE event = 'trade_close' ORDER BY ts ASC", conn
        )
    except Exception:
        df = pd.DataFrame()
    conn.close()
    if not df.empty:
        df["dt"] = pd.to_datetime(df["ts"], unit="s")
    return df


def _load_features_df(db_path: str) -> pd.DataFrame:
    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql(
            "SELECT * FROM trade_features WHERE outcome IS NOT NULL ORDER BY ts ASC", conn
        )
    except Exception:
        df = pd.DataFrame()
    conn.close()
    if not df.empty:
        df["dt"] = pd.to_datetime(df["ts"], unit="s")
    return df


def compute_summary(db_path: str) -> dict:
    ledger = _load_ledger_df(db_path)
    if ledger.empty:
        return {"trades": 0, "message": "No closed trades recorded yet."}

    pnl = ledger["pnl_usdt"]
    wins = pnl[pnl > 0]
    losses = pnl[pnl <= 0]

    gross_profit = wins.sum()
    gross_loss = abs(losses.sum())
    profit_factor = round(gross_profit / gross_loss, 2) if gross_loss > 0 else None

    equity = ledger["trading_capital_after"] + ledger["profit_vault_after"]
    running_max = equity.cummax()
    drawdown = (equity - running_max) / running_max.replace(0, np.nan)
    max_drawdown_pct = round(float(drawdown.min() * 100), 2) if not drawdown.empty else 0.0

    # simple day-over-day return series for a Sharpe-like consistency measure
    daily = ledger.set_index("dt")["pnl_usdt"].resample("D").sum()
    sharpe_like = None
    if len(daily) > 1 and daily.std() > 0:
        sharpe_like = round(float(daily.mean() / daily.std() * np.sqrt(365)), 2)

    # win/loss streaks
    outcomes = (pnl > 0).astype(int).tolist()
    cur_streak, best_win_streak, best_loss_streak = 1, 1, 1
    for i in range(1, len(outcomes)):
        if outcomes[i] == outcomes[i - 1]:
            cur_streak += 1
        else:
            cur_streak = 1
        if outcomes[i] == 1:
            best_win_streak = max(best_win_streak, cur_streak)
        else:
            best_loss_streak = max(best_loss_streak, cur_streak)

    per_symbol = (
        ledger.groupby("symbol")["pnl_usdt"]
        .agg(trades="count", net_pnl="sum", win_rate=lambda s: round((s > 0).mean() * 100, 1))
        .reset_index()
        .sort_values("net_pnl", ascending=False)
        .to_dict("records")
    )

    # per-strategy breakdown (trend_following vs mean_reversion vs
    # trend_following_low_confidence) -- parsed from the note field tags
    # capital.py writes on each trade_close event.
    if "note" in ledger.columns:
        tags = ledger["note"].apply(_parse_tags)
        ledger = ledger.assign(_strategy=[t[0] for t in tags], _regime=[t[1] for t in tags])
        tagged = ledger[ledger["_strategy"].notna()]
        if not tagged.empty:
            per_strategy = (
                tagged.groupby("_strategy")["pnl_usdt"]
                .agg(trades="count", net_pnl="sum", win_rate=lambda s: round((s > 0).mean() * 100, 1))
                .reset_index()
                .rename(columns={"_strategy": "strategy"})
                .sort_values("net_pnl", ascending=False)
                .to_dict("records")
            )
        else:
            per_strategy = []
    else:
        per_strategy = []

    by_reason = {}
    if "note" in ledger.columns:
        pass  # reason isn't stored in ledger table directly; comes from trade_features if needed

    return {
        "trades": len(ledger),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(len(wins) / len(ledger) * 100, 1),
        "net_pnl_usdt": round(float(pnl.sum()), 2),
        "gross_profit_usdt": round(float(gross_profit), 2),
        "gross_loss_usdt": round(float(gross_loss), 2),
        "profit_factor": profit_factor,
        "avg_win_usdt": round(float(wins.mean()), 2) if len(wins) else 0.0,
        "avg_loss_usdt": round(float(losses.mean()), 2) if len(losses) else 0.0,
        "max_drawdown_pct": max_drawdown_pct,
        "sharpe_like": sharpe_like,
        "best_win_streak": best_win_streak,
        "best_loss_streak": best_loss_streak,
        "per_symbol": per_symbol,
        "per_strategy": per_strategy,
        "current_equity": round(float(equity.iloc[-1]), 2) if len(equity) else None,
        "first_trade_at": ledger["dt"].iloc[0].isoformat() if len(ledger) else None,
        "last_trade_at": ledger["dt"].iloc[-1].isoformat() if len(ledger) else None,
    }


def compute_equity_series(db_path: str, max_points: int = 300) -> list:
    ledger = _load_ledger_df(db_path)
    if ledger.empty:
        return []
    equity = ledger["trading_capital_after"] + ledger["profit_vault_after"]
    step = max(1, len(ledger) // max_points)
    out = [
        {"t": row["dt"].isoformat(), "equity": round(float(eq), 2)}
        for (_, row), eq in zip(ledger.iloc[::step].iterrows(), equity.iloc[::step])
    ]
    return out


def compute_rolling_win_rate(db_path: str, window: int = 20) -> list:
    """
    Rolling win rate over the last `window` trades, one point per trade
    once enough history exists. Complements the cumulative win_rate_pct in
    compute_summary(): cumulative win rate can look stable while recent
    performance has quietly degraded (a regime change, an edge decaying) --
    this is what surfaces that.
    """
    ledger = _load_ledger_df(db_path)
    if ledger.empty or len(ledger) < window:
        return []
    is_win = (ledger["pnl_usdt"] > 0).astype(int)
    rolling = is_win.rolling(window=window).mean() * 100
    out = [
        {"t": row["dt"].isoformat(), "win_rate": round(float(wr), 1)}
        for (_, row), wr in zip(ledger.iterrows(), rolling)
        if pd.notna(wr)
    ]
    return out


def compute_r_multiple_distribution(db_path: str) -> dict:
    feat = _load_features_df(db_path)
    if feat.empty or "r_multiple" not in feat.columns:
        return {"buckets": [], "labels": []}
    r = feat["r_multiple"].dropna()
    if r.empty:
        return {"buckets": [], "labels": []}
    bins = [-5, -3, -2, -1, 0, 1, 2, 3, 5, 10]
    labels = ["<-3R", "-3..-2R", "-2..-1R", "-1..0R", "0..1R", "1..2R", "2..3R", "3..5R", "5..10R"]
    counts = pd.cut(r, bins=bins, labels=labels).value_counts().reindex(labels, fill_value=0)
    return {"labels": labels, "buckets": counts.tolist()}


def compute_learner_summary(db_path: str, model_path: str = None) -> dict:
    from learner import TradeLearner
    model_path = model_path or (db_path.replace(".sqlite3", "") + "_model.joblib")
    learner = TradeLearner(db_path=db_path, model_path=model_path)
    status = learner.status()
    learner.close()
    return status


def format_daily_message(db_path: str, report_date=None) -> str:
    s = compute_summary(db_path)
    if s.get("trades", 0) == 0:
        return "Quantis daily summary: no trades closed today."
    lines = [
        f"*Quantis Daily Summary*",
        f"Trades: {s['trades']} ({s['wins']}W / {s['losses']}L, {s['win_rate_pct']}% win rate)",
        f"Net P&L: {s['net_pnl_usdt']:+.2f} USDT",
        f"Profit Factor: {s['profit_factor']}",
        f"Max Drawdown: {s['max_drawdown_pct']}%",
        f"Current Equity: {s['current_equity']}",
    ]
    return "\n".join(lines)


def format_weekly_message(db_path: str) -> str:
    s = compute_summary(db_path)
    if s.get("trades", 0) == 0:
        return "Quantis weekly summary: no trades recorded."
    top_symbols = s.get("per_symbol", [])[:3]
    top_lines = [f"  {r['symbol']}: {r['net_pnl']:+.2f} ({r['trades']} trades, {r['win_rate']}% win)" for r in top_symbols]
    lines = [
        "*Quantis Weekly Summary*",
        f"Total trades: {s['trades']} | Win rate: {s['win_rate_pct']}%",
        f"Net P&L: {s['net_pnl_usdt']:+.2f} USDT | Profit Factor: {s['profit_factor']}",
        f"Max Drawdown: {s['max_drawdown_pct']}% | Best win streak: {s['best_win_streak']}",
        "Top symbols:",
        *top_lines,
    ]
    return "\n".join(lines)
