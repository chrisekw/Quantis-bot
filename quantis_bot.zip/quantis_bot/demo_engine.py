"""
Demo Engine — runs the REAL bot logic (signals.py, risk.py, capital.py,
backtester-equivalent live loop) continuously against a locally-simulated,
incrementally-growing market feed. This exists so the dashboard has real,
live, moving data to display without needing outbound access to an exchange.

This is NOT a mock of the UI — every number the dashboard shows (scores,
positions, stops, capital splits) comes from the actual trading engine
running on this data. Swap DemoEngine for the real `exchange.py` fetch
(see paper_trader.py) to run this exact engine against live Binance
Testnet data on your own machine — the strategy code does not change.
"""
import threading
import time
from datetime import datetime, date
from collections import deque

import numpy as np
import pandas as pd

import config
from signals import add_indicators, score_asset, generate_signal, market_breadth
from correlation import compute_correlation_matrix
from edge import DecisionMaker, apply_costs
from data_quality import validate_ohlcv
from trading_mode import get_trading_mode
from risk import build_trade_plan, CircuitBreaker, check_pre_trade_gates, update_trailing_stop, passes_regime_filter, blend_ml_score
from capital import CapitalManager
from learner import TradeLearner
from notifier import notify_trade_opened, notify_trade_closed, notify_circuit_breaker, notify
from analytics import format_daily_message, format_weekly_message
from reporter import generate_report


class LiveSyntheticFeed:
    """Grows a synthetic OHLCV series by one bar at a time, symbol by symbol,
    to simulate a live market ticking forward. Same statistical engine as
    synthetic_data.py, but stateful/incremental."""

    def __init__(self, symbols, seed=123, bar_seconds=8):
        self.symbols = symbols
        self.bar_seconds = bar_seconds
        self.rng = {s: np.random.default_rng(seed + i) for i, s in enumerate(symbols)}
        self.data = {}
        for i, s in enumerate(symbols):
            start_price = 100 * (i + 1) * 300  # rough plausible starting prices
            idx = pd.date_range(end=pd.Timestamp.now().floor("h"), periods=400, freq="1h")
            self.data[s] = self._seed_series(s, idx, start_price)
        self.mu = {s: 0.15 for s in symbols}
        self.sigma = {s: 0.55 for s in symbols}
        self.regime_counter = {s: 0 for s in symbols}
        self.regime_bias = {s: 0.0 for s in symbols}

    def _seed_series(self, sym, idx, start_price):
        rng = self.rng[sym]
        n = len(idx)
        dt = 1 / (24 * 365)
        returns = rng.normal(0.15 * dt, 0.55 * np.sqrt(dt), n)
        close = start_price * np.exp(np.cumsum(returns))
        high = close * (1 + np.abs(rng.normal(0, 0.004, n)))
        low = close * (1 - np.abs(rng.normal(0, 0.004, n)))
        open_ = np.roll(close, 1); open_[0] = start_price
        vol = rng.uniform(50, 400, n)
        df = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close, "volume": vol}, index=idx)
        df["high"] = df[["open", "close", "high"]].max(axis=1)
        df["low"] = df[["open", "close", "low"]].min(axis=1)
        return df

    def tick(self):
        """Advance every symbol's series by one bar."""
        for sym in self.symbols:
            rng = self.rng[sym]
            df = self.data[sym]
            last_close = df["close"].iloc[-1]

            self.regime_counter[sym] -= 1
            if self.regime_counter[sym] <= 0:
                self.regime_counter[sym] = rng.integers(20, 60)
                self.regime_bias[sym] = rng.choice([-1, 1]) * rng.uniform(0.3, 1.3)

            dt = 1 / (24 * 365)
            drift = (self.mu[sym] + self.regime_bias[sym] * self.mu[sym]) * dt
            ret = rng.normal(drift, self.sigma[sym] * np.sqrt(dt))
            new_close = last_close * np.exp(ret)
            new_high = max(new_close, last_close) * (1 + abs(rng.normal(0, 0.003)))
            new_low = min(new_close, last_close) * (1 - abs(rng.normal(0, 0.003)))
            new_open = last_close
            new_vol = rng.uniform(50, 400)

            new_ts = df.index[-1] + pd.Timedelta(hours=1)
            new_row = pd.DataFrame(
                {"open": [new_open], "high": [new_high], "low": [new_low],
                 "close": [new_close], "volume": [new_vol]}, index=[new_ts],
            )
            self.data[sym] = pd.concat([df, new_row]).iloc[-500:]

    def snapshot(self):
        return {s: df.copy() for s, df in self.data.items()}


class DemoEngine:
    def __init__(self, symbols=None, db_path="demo_ledger.sqlite3"):
        self.symbols = symbols or config.SYMBOLS
        self.feed = LiveSyntheticFeed(self.symbols)
        self.capital = CapitalManager(db_path=db_path, starting_capital=config.STARTING_CAPITAL)
        model_path = db_path.replace(".sqlite3", "") + "_model.joblib"
        self.learner = TradeLearner(db_path=db_path, model_path=model_path)
        self.decider = DecisionMaker(db_path=db_path)   # net-edge gate, calibrated from this ledger's own closed trades
        self.data_issues = {}
        self.trades_since_last_train = 0
        self.open_positions = {}
        self.trades_today = []
        self.trade_log = deque(maxlen=200)
        self.equity_curve = deque(maxlen=500)
        self.current_day = date.today()
        self.circuit_breaker = CircuitBreaker(capital_at_day_start=self.capital.trading_capital)
        self.last_scan = []
        self.market_breadth_val = 0.0
        self.tick_count = 0
        self._lock = threading.Lock()
        self._running = False
        self._thread = None
        self.benchmark_symbol = config.BENCHMARK_SYMBOL if config.BENCHMARK_SYMBOL in self.symbols else (self.symbols[0] if self.symbols else None)
        self.benchmark_start_price = None
        self.benchmark_current_price = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _roll_day_if_needed(self):
        today = date.today()
        if today != self.current_day:
            try:
                generate_report(
                    report_date=self.current_day, trades_today=self.trades_today,
                    scanned_symbols=self.last_scan, capital_summary=self.capital.summary(),
                    circuit_breaker_tripped=self.circuit_breaker.tripped,
                )
                if config.ANALYTICS_SEND_DAILY:
                    notify(format_daily_message(self.capital.db_path, self.current_day))
                if config.ANALYTICS_SEND_WEEKLY and today.weekday() == 0:  # Monday: summarize the week just ended
                    notify(format_weekly_message(self.capital.db_path))
            except Exception as e:
                print(f"[DemoEngine] report/notification generation failed: {e}")
            self.current_day = today
            self.trades_today = []
            self.circuit_breaker.reset_for_new_day(self.capital.trading_capital)

    def _loop(self):
        print("[DemoEngine] started")
        while self._running:
            self.feed.tick()
            self.tick_count += 1
            self._roll_day_if_needed()

            snap = self.feed.snapshot()
            scored = []
            indicator_frames = {}
            for sym, df in snap.items():
                rep = validate_ohlcv(df, bar_seconds=3600, check_stale=False)
                if not rep.ok:
                    self.data_issues[sym] = rep.fatal   # bad data => no new decisions on this symbol
                    continue
                self.data_issues.pop(sym, None)
                df2 = add_indicators(df)
                indicator_frames[sym] = df2
                result = generate_signal(df2)   # regime-adaptive: trend-following, mean-reversion, or reduced-confidence
                result["symbol"] = sym
                result["_last_price"] = float(df2["close"].iloc[-1])
                result["_atr"] = float(df2["atr"].iloc[-1]) if not pd.isna(df2["atr"].iloc[-1]) else None
                scored.append(result)

            corr_matrix = compute_correlation_matrix(snap) if config.USE_CORRELATION_GUARD else None

            with self._lock:
                self.last_scan = [{k: v for k, v in r.items() if k != "_atr"} | {"close": r["_last_price"]} for r in scored]
                self.market_breadth_val = market_breadth(pd.DataFrame(scored))

                bm_match = next((r for r in scored if r["symbol"] == self.benchmark_symbol), None)
                if bm_match:
                    if self.benchmark_start_price is None:
                        self.benchmark_start_price = bm_match["_last_price"]
                    self.benchmark_current_price = bm_match["_last_price"]

                # --- exits (with trailing stop) ---
                for sym in list(self.open_positions.keys()):
                    match = next((r for r in scored if r["symbol"] == sym), None)
                    if not match:
                        continue
                    price = match["_last_price"]
                    pos = self.open_positions[sym]
                    pos["stop"] = update_trailing_stop(
                        entry_price=pos["entry_price"], initial_stop=pos["initial_stop"],
                        current_price=price, current_stop=pos["stop"],
                    )
                    exit_price, reason = None, None
                    if price <= pos["stop"]:
                        exit_price, reason = pos["stop"], ("trailing_stop" if pos["stop"] > pos["initial_stop"] else "stop_loss")
                    elif price >= pos["tp"]:
                        exit_price, reason = pos["tp"], "take_profit"

                    if exit_price:
                        exit_price = apply_costs(exit_price, "sell")   # fee + slippage + half-spread
                        pnl = (exit_price - pos["entry_price"]) * pos["size_units"]
                        self.decider.record_outcome(pos["score"], pnl / pos["risk_usdt"] if pos.get("risk_usdt") else 0.0)
                        self.capital.apply_trade_result(sym, pnl, strategy=pos.get("strategy"), regime=pos.get("regime"))
                        self.circuit_breaker.record_trade_result(pnl)

                        if pos.get("feature_row_id") is not None:
                            self.learner.record_exit(pos["feature_row_id"], pnl_usdt=pnl, risk_usdt=pos.get("risk_usdt", 1.0))
                            self.trades_since_last_train += 1
                            if self.trades_since_last_train >= config.ML_RETRAIN_EVERY_N_TRADES:
                                self.learner.train()
                                self.trades_since_last_train = 0

                        trade_record = {
                            "symbol": sym, "entry_price": round(pos["entry_price"], 4),
                            "exit_price": round(exit_price, 4), "position_size_usdt": pos["size_usdt"],
                            "signal_score": pos["score"], "ml_probability": pos.get("ml_probability"),
                            "regime": pos.get("regime"), "strategy": pos.get("strategy"),
                            "exit_reason": reason,
                            "pnl_usdt": round(pnl, 2), "closed_at": datetime.now().isoformat(timespec="seconds"),
                        }
                        self.trades_today.append(trade_record)
                        self.trade_log.appendleft(trade_record)
                        notify_trade_closed(sym, reason, pnl)
                        if self.circuit_breaker.tripped:
                            notify_circuit_breaker()
                        del self.open_positions[sym]

                # --- entries (regime-filtered) ---
                regime_ok = passes_regime_filter(self.market_breadth_val)
                if self.circuit_breaker.can_trade() and regime_ok and len(self.open_positions) < config.MAX_CONCURRENT_POSITIONS:
                    scored.sort(key=lambda r: r["score"], reverse=True)
                    for result in scored:
                        if len(self.open_positions) >= config.MAX_CONCURRENT_POSITIONS:
                            break
                        sym = result["symbol"]
                        if sym in self.open_positions or result["score"] < config.MIN_SCORE_TO_TRADE:
                            continue
                        atr = result["_atr"]
                        if not atr or atr <= 0:
                            continue
                        raw_price = result["_last_price"]
                        decision = self.decider.evaluate(sym, result, raw_price, atr)
                        if not decision.approved:
                            continue
                        entry_price = apply_costs(raw_price, "buy")

                        # Blend the rules-based score with the learner's predicted win
                        # probability (if the model has enough data to be trusted --
                        # see learner.py's ML_MIN_SAMPLES_TO_ACT gate).
                        ml_features = {
                            "trend_score": result.get("trend"), "momentum_score": result.get("momentum"),
                            "volatility_score": result.get("volatility"), "rsi": result.get("rsi"),
                            "atr_pct": result.get("atr_pct"), "market_breadth": self.market_breadth_val,
                            "signal_score": result["score"],
                        }
                        ml_prob = self.learner.predict_win_probability(ml_features)
                        blended_score = blend_ml_score(result["score"], ml_prob)

                        plan = build_trade_plan(
                            symbol=sym, entry_price=entry_price, atr=atr,
                            signal_score=blended_score, trading_capital=self.capital.trading_capital,
                            size_multiplier=decision.size_multiplier,
                        )
                        allowed, _why = check_pre_trade_gates(
                            plan, len(self.open_positions), 0.0,
                            self.capital.trading_capital, self.circuit_breaker,
                            open_symbols=list(self.open_positions.keys()), corr_matrix=corr_matrix, decision=decision,
                        )
                        if not allowed:
                            continue

                        feature_row_id = self.learner.record_entry(sym, ml_features)

                        self.open_positions[sym] = {
                            "entry_price": plan.entry_price, "stop": plan.stop_loss_price,
                            "initial_stop": plan.stop_loss_price, "tp": plan.take_profit_price,
                            "size_units": plan.position_size_units, "size_usdt": plan.position_size_usdt,
                            "score": result["score"], "blended_score": blended_score,
                            "ml_probability": round(ml_prob, 3) if ml_prob is not None else None,
                            "risk_usdt": plan.risk_usdt, "feature_row_id": feature_row_id,
                            "regime": result.get("regime"), "strategy": result.get("strategy"),
                            "volume_ratio": result.get("volume_ratio"),
                            "opened_at": datetime.now().isoformat(timespec="seconds"),
                        }
                        notify_trade_opened(sym, blended_score, plan.position_size_usdt)

                self.equity_curve.append({
                    "t": datetime.now().isoformat(timespec="seconds"),
                    "equity": round(self.capital.total_equity(), 2),
                })

            time.sleep(self.feed.bar_seconds)

    def benchmark_snapshot(self) -> dict:
        """
        The honesty check from Section 02 of the plan: a bot can look
        "profitable" in isolation while still underperforming simply
        holding the benchmark asset the whole time. Compares the bot's
        total return since its capital started against buy-and-hold on
        BENCHMARK_SYMBOL over the same period.
        """
        with self._lock:
            if self.benchmark_start_price is None or self.benchmark_current_price is None:
                return {"available": False, "symbol": self.benchmark_symbol}

            bh_pct = (self.benchmark_current_price / self.benchmark_start_price - 1) * 100
            bot_equity = self.capital.total_equity()
            bot_pct = (bot_equity / config.STARTING_CAPITAL - 1) * 100

            return {
                "available": True,
                "symbol": self.benchmark_symbol,
                "start_price": round(self.benchmark_start_price, 4),
                "current_price": round(self.benchmark_current_price, 4),
                "buy_and_hold_pct": round(bh_pct, 2),
                "bot_pct": round(bot_pct, 2),
                "bot_beating_buy_and_hold": bool(bot_pct > bh_pct),
            }

    def snapshot_state(self) -> dict:
        with self._lock:
            return {
                "running": self._running,
                "trading_mode": get_trading_mode(),
                "data_source": "SIMULATED_FEED",   # explicit label: this engine's market is generated, not real
                "data_issues": dict(self.data_issues),
                "edge": {"observations": self.decider.calibrator.n, "required": config.EDGE_MIN_OBSERVATIONS,
                         "mode": "calibrated" if self.decider.calibrator.n >= config.EDGE_MIN_OBSERVATIONS else "exploration"},
                "recent_decisions": [d.to_dict() for d in list(self.decider.recent)[:25]],
                "tick": self.tick_count,
                "capital": self.capital.summary(),
                "circuit_breaker_tripped": self.circuit_breaker.tripped,
                "market_breadth": round(self.market_breadth_val * 100, 1),
                "regime_ok": passes_regime_filter(self.market_breadth_val),
                "learner": self.learner.status(),
                "open_positions": [
                    {"symbol": s, **{k: (round(v, 4) if isinstance(v, float) else v) for k, v in p.items()}}
                    for s, p in self.open_positions.items()
                ],
                "scan": sorted(self.last_scan, key=lambda r: r.get("score", 0), reverse=True),
                "recent_trades": list(self.trade_log)[:30],
                "equity_curve": list(self.equity_curve),
            }
