# Quantis Bot — Personal AI-Assisted Crypto Trading System

Implements the plan in *Quantis_Personal_Trading_Bot_Plan_2026.pdf*: hard
stop-losses, 1% risk-per-trade cap, daily loss circuit breaker, signal-based
position sizing, trailing stops, a market-regime filter, automatic
profit/capital separation, an adaptive learning layer, multi-channel
notifications, and a full web dashboard with a gated path to live trading.
**Trades your own capital only — there is no investor logic anywhere in
this codebase, and it should stay that way.**

## Quick start (dashboard, local machine)

```bash
pip install -r requirements.txt
python server.py
```
Open **http://127.0.0.1:5000**. No password needed for local-only access.

Runs a **live demo engine** by default: the real trading engine (signals,
risk, capital ledger, trailing stops, regime filter, ML learner) running
continuously against a locally-simulated market feed. Every number on the
dashboard comes from the actual strategy code — nothing is hardcoded.

## Latest update: smarter by being more honest (read this first)

**What changed, and why it matters for profit**

- **Net-edge gate (`edge.py`).** The old rule was "trade when score >= 60", an arbitrary number. Now every candidate
  is costed (fee + slippage + spread, in R = multiples of money risked) and the bot's own *recorded net results*
  for similar signals are used to estimate expected return **after costs**, shrunk toward a cautious prior and
  reported with its uncertainty. Until `EDGE_MIN_OBSERVATIONS` (40) trades exist it is in **exploration** mode
  (half size, cost-limited, clearly labelled) because a bot that never trades can never gather evidence. After that,
  a trade must clear `EDGE_MIN_EV_R` on the *conservative* lower bound, otherwise the decision is **NO TRADE**.
  The Markets tab shows every BUY / NO TRADE with expected net return, uncertainty, cost and reason.
- **Realistic backtester.** Orders fill at the *next bar's open* (never the close that produced the signal), every
  fill pays costs, stops are tested before trailing is ratcheted, gaps through a stop fill at the worse open, equity is
  marked to market, and results include Sharpe, Sortino, profit factor, EV per trade, costs paid, turnover, exposure and a
  buy-and-hold benchmark. Output is labelled as historical simulation.
- **Paper/demo engines now pay costs too.** They previously filled at raw prices, which made paper results look better
  than the backtest. That is fixed, so paper results are comparable evidence.
- **Data-quality layer (`data_quality.py`).** Duplicates, gaps, NaNs, impossible candles, bad ticks and stale
  candles are detected; fatal issues suspend new decisions on that symbol (and make the backtester refuse to run).
- **`TRADING_MODE` guard (`trading_mode.py`).** Defaults to `paper`; anything unrecognised is rejected. `live_engine.py`
  will not run unless `TRADING_MODE=live` is set explicitly, *in addition to* all the earlier live gates.
- **A real bug was found and fixed.** Position sizes capped at the 20% allocation limit were rounded to cents and then
  rejected by the gate for being half a cent over. This silently blocked trades in every engine.
- **Test suite (`tests/`, 49 tests).** Run `pip install -r requirements-dev.txt && pytest`. Includes look-ahead tests
  (altering future bars must not change any past indicator/signal), cost and edge logic, data quality, risk limits,
  ledger accounting, backtest reproducibility and no-same-bar-fill, mode/secret handling and an auth smoke test.

**What the evidence does and doesn't say.** On random-walk synthetic data (no edge exists), a naive "score >= 60" bot
took ~456 trades and lost ~23% (mostly costs); with the edge gate it took ~41 trades and lost ~2%. That shows the gate
*avoids bleeding costs when there is no edge*. It does **not** show the bot can create profit; only real historical
data (`python main.py backtest --real`) and weeks of paper trading can say whether an edge exists. With 0.10% taker fees
per side, tight-stop strategies on short timeframes are cost-marginal; if the gate keeps saying NO TRADE on real data,
the likely fixes are a longer timeframe or lower fees, not a looser gate.

**Status against the build specification**

| Area | Status |
|---|---|
| Data validation, edge gate and calibration, structured decisions, realistic backtester, cost model, TRADING_MODE guard, risk limits, ledger accounting, causality tests | Implemented and tested (49 passing tests) |
| Exchange connectivity (ccxt), Telegram/WhatsApp, async fetch, `live_engine.py` | Implemented; **not tested against real services** from the build sandbox. Live remains behind all gates |
| Default dashboard feed | **Simulated** (labelled in the UI banner and API); not evidence of profitability |
| PostgreSQL + migrations, Docker Compose, job queue, heartbeats/health endpoints beyond `/healthz`, audit-log and risk-event tables | **Not implemented** (SQLite and a single-process worker are used) |
| Separate momentum and volatility-regime strategy modules; model version registry, drift detection, keep-previous-model rule | **Not implemented** (trend-following, mean-reversion and a logistic-regression learner exist) |
| Order-book, funding-rate, open-interest and news ingestion | **Not implemented** (OHLCV only) |
| Tests for partial fills, API timeouts, DB failures, model-version changes; dependency lockfile; architecture diagram; API docs | **Not implemented** |
| Critical-incident "safe state requiring manual resume" | **Not implemented** (daily circuit breaker only) |

## The "brain" — what got more sophisticated, and what that does and doesn't mean

**Regime-adaptive strategy (`signals.py`'s `generate_signal()`)** — the bot
now detects whether the market is trending or choppy (via ADX) and switches
strategy accordingly, matching what the original plan actually recommended
in Section 04 rather than running one strategy in every condition:
- **Trending** (ADX ≥ 22): trend-following — the six-component scoring
  (trend/momentum/volatility/MACD/Bollinger/multi-timeframe) described below.
- **Choppy** (ADX ≤ 18): mean-reversion — looks for price pressed against
  the lower Bollinger Band with RSI deeply oversold, targeting a bounce
  back to the mean rather than a continued trend.
- **Neutral** (in between): trend-following logic still runs but at 60%
  confidence — deliberately avoids flip-flopping strategy on every minor
  ADX wiggle.
- **Volume confirmation**: any signal on unusually thin volume (below 60%
  of its recent average) gets its score halved — thin volume is more
  likely noise or a stale quote than genuine conviction.

**Correlation / diversification guard (`correlation.py`)** — computes
rolling return correlation across your scanned universe and blocks a new
position if it would be >75% correlated with one already open. Four
"different" positions that are all really one leveraged bet on the same
move aren't diversified — this stops that specific mistake. Tested against
a deliberately correlated pair: correctly blocked; tested against a
genuinely independent pair: correctly allowed through.

**Signal scoring (`signals.py`)** combines six components in trending
regimes: trend (EMA separation), momentum (RSI), volatility (ATR range),
MACD confirmation, Bollinger Band positioning, and an optional
multi-timeframe bonus/penalty. All rules-based and auditable — every
component score is visible in the Markets tab, including which regime and
strategy produced it.

**Adaptive learning (`learner.py`)** logs the market conditions present at
every trade's entry and the outcome, and periodically trains a model to
predict win probability from those conditions. What changed this round:
- **Walk-forward (time-series) cross-validation** replaces a single
  train/test split — more honest, since it doesn't let one lucky split
  overstate accuracy.
- **Gradient boosting is available** as a model option (`ML_MODEL_TYPE` in
  config.py) alongside logistic regression. Honest finding from testing
  this during development: gradient boosting did **not** reliably beat
  logistic regression's baseline accuracy at realistic sample sizes (~150
  trades) — the walk-forward validation caught this correctly. **Logistic
  regression stays the default** for that reason; gradient boosting is a
  real option once you have substantially more trade history, not an
  automatic upgrade.
- Same honesty rules as before: refuses to influence decisions until 80
  real closed trades exist, blends at 30% weight rather than overriding
  the rules-based score, reports its own out-of-sample accuracy against a
  coin-flip baseline including when it doesn't beat it.

**What this does NOT mean**: "more sophisticated scoring" and "more
profitable" are different claims. Only `backtest --real` against genuine
market history and a real paper-trading period tell you the second one.

## Analytics — seeing how it's actually performing

The Analytics tab now includes:
- **Buy-and-hold benchmark**: the honesty check from Section 02 of the
  plan — many "profitable" bots still underperform simply holding the
  asset. This compares the bot's return against holding BTC over the same
  period, reported either way, including when the bot is currently behind.
- **Rolling win rate** (last 20 trades): cumulative win rate can look
  stable while recent performance has quietly degraded — this surfaces that.
- **Per-strategy breakdown**: which of trend-following or mean-reversion is
  actually working right now, from real tagged trade data, not a guess.
- Plus the existing net P&L, profit factor, max drawdown, Sharpe-like
  consistency, streaks, per-symbol breakdown, R-multiple distribution, and
  learner status.

The Markets tab now shows each symbol's detected regime (trending/choppy/
neutral badge), which strategy is active for it, and its volume
confirmation ratio — so you can see *why* the bot is or isn't trading a
given asset, not just its final score.

## Notifications — Telegram + WhatsApp

Both route through one function (`notifier.notify()`), called on trade
opens/closes, circuit breaker trips, and daily/weekly analytics summaries
(`ANALYTICS_SEND_DAILY` / `ANALYTICS_SEND_WEEKLY` in config.py).

- **Telegram** (`telegram_notifier.py`): message @BotFather to create a bot,
  get a token, set `TELEGRAM_ENABLED = True` and the token/chat_id via env
  vars (`QUANTIS_TG_TOKEN`, `QUANTIS_TG_CHAT_ID`). Free, no account needed
  beyond Telegram itself.
- **WhatsApp** (`whatsapp_notifier.py`): via Twilio's WhatsApp Sandbox — free,
  but requires your own Twilio account and re-linking your phone roughly
  every 72 hours (sandbox limitation; Twilio's paid WhatsApp Business API
  removes that). Full setup steps are in the file's docstring. Set
  `WHATSAPP_ENABLED = True` plus `QUANTIS_TWILIO_SID`, `QUANTIS_TWILIO_TOKEN`,
  `QUANTIS_WHATSAPP_FROM`, `QUANTIS_WHATSAPP_TO` env vars.

Test either from the dashboard's Settings tab ("Send Test Notification") or:
```bash
python -c "from notifier import notify; print(notify('test'))"
```

## Live trading — how "switch from demo to live" actually works here

> **Gate 0 (new):** `TRADING_MODE=live` must be set explicitly (default `paper`; unknown values are rejected). It is required *in addition to* the gates below.

This was deliberately built as **four separate gates**, not a toggle,
because that phrase should never be a single accidental step with real
money involved:

1. **`config.USE_TESTNET = False`** — you have to edit this yourself.
2. **Data-driven readiness** (`live_gate.py`) — checks your *own* recorded
   paper-trading history against minimum thresholds in config.py (default:
   28 days running, 30 closed trades, 35% win rate floor, ≤25% max
   drawdown). Computed from real data, visible on the **Live Mode** tab,
   with a live pass/fail breakdown.
3. **Explicit dashboard confirmation** — the Live Mode tab only unlocks the
   enable button once #2 passes, and requires typing
   `I UNDERSTAND THE RISK` exactly.
4. **A second typed confirmation at process start** — `live_engine.py`
   re-checks all of the above and asks you to type the phrase again before
   placing a single real order.

Meeting the thresholds is a floor, not a green light to stop paying
attention — read `live_gate.py`'s own docstring, it says this directly.
`live_engine.py` places real market orders via `exchange.py` and attaches
an **exchange-native stop-loss order** (not just an in-memory check) so
protection holds even if this process crashes.

Run it with:
```bash
python main.py live
```

## Running against a real exchange (Binance Testnet first)

1. Create a free account at https://testnet.binance.vision/ and generate a
   **trading-only** API key (no withdrawal rights).
2. Set credentials as environment variables:
   ```bash
   export QUANTIS_API_KEY="your_testnet_api_key"
   export QUANTIS_API_SECRET="your_testnet_api_secret"
   ```
3. Real historical backtest: `python main.py backtest --real`
4. Live paper-trading loop (simulated fills, real market data, this is what
   the live-gate readiness checks measure): `python main.py paper`

## The web dashboard

```
Dashboard │ equity, open positions, recent trades, animated trade toasts
Markets   │ live signal scan — every component score visible, incl. MACD/BB
Backtest  │ run a backtest from the browser
Trades    │ full session trade history
Reports   │ daily markdown reports, browsable
Analytics │ real performance stats + learner status
Live Mode │ readiness checklist + gated enable flow
Settings  │ current risk config (read-only) + notification test
```
Binance-inspired dark styling, plain Flask + vanilla JS + Chart.js. Polls
`/api/state` every 3 seconds and toasts new trade closes as they happen.

## Deploying online

- **`FREE_DEPLOYMENT.md`** — running the engine 24/7 for **$0/month** on
  Oracle Cloud's "Always Free" tier (a real, persistent VM — not a trial).
  Checked current pricing before writing this: Railway and Fly.io killed
  their free tiers in 2023/2024; Render's free tier sleeps after 15 minutes
  idle, which breaks a bot that needs to keep watching the market. Oracle's
  is the one genuinely free, always-on option. Start here if cost is the
  deciding factor.
- **`DEPLOYMENT.md`** — the same architecture on a paid VPS (DigitalOcean,
  Linode, Hetzner) if you'd rather not deal with Oracle's setup flow, plus
  the full systemd/Docker/HTTPS reference that `FREE_DEPLOYMENT.md` builds on.
- **`VERCEL_DEPLOYMENT.md`** — hosting just the dashboard frontend on
  Vercel, pointed at your VPS-hosted engine via CORS. Read the top of that
  file first: Vercel's serverless model genuinely cannot run the always-on
  engine itself (confirmed against Vercel's current cron/function limits)
  — this isn't a workaround, it's the architecture that's actually correct
  for what each platform does well.

All three already have the safety rails from before: dashboard password
required the moment this is exposed beyond `127.0.0.1`, Gunicorn for
production serving, systemd auto-restart with a restart-storm cap.

## Getting the code onto a server

A `.gitignore` is included — it excludes the trade database, trained model
files, daily reports, and anything named `.env` from version control, so a
plain `git init && git add . && git commit` only stages real project files
(verified: 36 files, zero databases/secrets). Push to a GitHub repo (private
if you'd rather), then `git clone` it on your server — see either deployment
guide's "Getting the bot's code onto the VM" section for the exact commands.

## Project structure
```
config.py            - all risk/capital/strategy/ML/live-gate/regime parameters
signals.py             - EMA/RSI/ATR/MACD/Bollinger/ADX scoring, regime-adaptive routing, mean-reversion
correlation.py           - diversification guard, blocks concentrated correlated positions
risk.py                    - position sizing, stops, trailing stop, circuit breaker, regime filter, ML blending
capital.py                  - SQLite ledger: trading capital vs. profit vault, strategy/regime tagging
learner.py                    - adaptive "brain" (logistic regression or gradient boosting), walk-forward validated
analytics.py                   - performance stats, per-strategy breakdown, rolling win rate, buy-and-hold benchmark
notifier.py                     - unified fan-out to Telegram + WhatsApp
telegram_notifier.py             - Telegram channel
whatsapp_notifier.py              - WhatsApp channel (via Twilio)
live_gate.py                       - data-driven readiness gate for demo->live
live_engine.py                      - REAL order execution, gated behind live_gate + typed confirmation
exchange.py                          - ccxt wrapper (sync + async), needs real network access
backtester.py                         - runs the full strategy (incl. regime-adaptive logic) against history
paper_trader.py                        - live loop against real exchange data, simulated fills
demo_engine.py                          - live loop against a simulated feed, powers the default dashboard view
reporter.py                              - generates the daily markdown report
synthetic_data.py                         - FOR TESTING ONLY — fake OHLCV data
server.py                                  - Flask dashboard + REST API (CORS-enabled)
templates/, static/                         - dashboard HTML/CSS/JS (animations, analytics, live-mode, regime badges)
vercel_frontend/                             - static frontend deployable to Vercel, calls your VPS API
main.py                                       - CLI entrypoint (backtest / paper / live)
.gitignore                                     - excludes trade DBs, models, reports, secrets from version control
Dockerfile, quantis.service                     - deployment
DEPLOYMENT.md, FREE_DEPLOYMENT.md,                deployment guides (paid VPS / free Oracle Cloud / Vercel frontend)
VERCEL_DEPLOYMENT.md
```

## Before you ever run this with real money — re-read this

1. **Never** set `USE_TESTNET = False` until the live-gate readiness checks
   pass on their own — don't lower the thresholds in config.py to get there
   faster; that defeats the entire point of the gate.
2. Start real capital at an amount you can fully afford to lose ($200–$1,000).
3. Don't raise `DAILY_LOSS_CIRCUIT_BREAKER_PCT` to "let it run."
4. Every trade has a hard, exchange-native stop-loss attached at entry.
5. Read the daily reports and Analytics tab. They're your honest record.
6. The learner needs 80 real trades before it affects anything — don't
   expect it to matter in week one, and don't be alarmed if it doesn't beat
   its own baseline for a while. That's the honest, expected case.

## What this bot does NOT do (by design)
- No leverage (spot only)
- No shorting in v1
- No investor capital handling of any kind
- No guaranteed-return logic anywhere
- No serverless execution of the actual trading loop (see VERCEL_DEPLOYMENT.md)
