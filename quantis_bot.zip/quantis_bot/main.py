"""
Quantis Bot -- CLI Entrypoint

Usage:
    python main.py backtest --real        # backtest on real historical data (needs network)
    python main.py backtest --synthetic   # backtest on synthetic data (works anywhere, sanity check only)
    python main.py paper                  # run the paper trading loop (needs network + testnet keys)
    python main.py live                   # run the LIVE trading engine (real orders, real money --
                                           # gated behind live_gate readiness checks + typed confirmation)
"""
import argparse
import sys


def run_backtest(use_real: bool):
    import config
    from backtester import Backtester

    if use_real:
        from exchange import ExchangeClient
        print(f"Fetching real historical data for {config.SYMBOLS} ...")
        client = ExchangeClient(use_testnet=config.USE_TESTNET)
        data = client.fetch_universe(limit=1000)
    else:
        from synthetic_data import generate_test_universe
        print("Using SYNTHETIC data -- sanity check only, not a real strategy validation.")
        data = generate_test_universe(config.SYMBOLS, n_bars=3000)

    bt = Backtester(data, starting_capital=config.STARTING_CAPITAL)
    results = bt.run()

    print("\n===== BACKTEST RESULTS =====")
    for k, v in results.items():
        if k in ("trades_df", "equity_df"):
            continue
        print(f"{k}: {v}")

    if "trades_df" in results:
        out_path = "backtest_trades.csv"
        results["trades_df"].to_csv(out_path, index=False)
        print(f"\nFull trade log written to {out_path}")


def run_paper():
    from paper_trader import PaperTrader
    trader = PaperTrader()
    trader.run()


def run_live():
    import live_engine
    live_engine._run_startup_gates()
    engine = live_engine.LiveEngine()
    engine.run()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Quantis Bot CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    bt_parser = sub.add_parser("backtest")
    group = bt_parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--real", action="store_true", help="Use real historical data (needs network)")
    group.add_argument("--synthetic", action="store_true", help="Use synthetic data (sanity check only)")

    sub.add_parser("paper", help="Run the paper trading loop")
    sub.add_parser("live", help="Run the LIVE trading engine (real orders -- gated, see live_gate.py)")

    args = parser.parse_args()

    if args.command == "backtest":
        run_backtest(use_real=args.real)
    elif args.command == "paper":
        run_paper()
    elif args.command == "live":
        run_live()
