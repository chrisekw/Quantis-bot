"""
Trade Learner — the "brain" that learns from the bot's own trade history.

Honest framing, read this before trusting it:
  A personal bot generates maybe a few hundred trades a YEAR. Machine
  learning models trained on a few dozen or even a few hundred samples
  overfit extremely easily -- they will "discover" patterns that are just
  noise, and be confidently wrong. This module is built to respect that:

  - It refuses to influence any trading decision until MIN_SAMPLES_TO_ACT
    real trade outcomes have been recorded (config.py).
  - It always validates itself on held-out data (a simple time-based
    train/test split) and reports its own out-of-sample accuracy honestly
    -- including when that accuracy is no better than a coin flip, which
    is a likely and useful outcome to know.
  - Its output is a probability that BLENDS with the existing rules-based
    score (signals.py) rather than replacing it -- so a bad model can only
    nudge decisions, not take them over.
  - It retrains periodically (not on every trade) on the full history
    each time, using a fresh, interpretable model (logistic regression)
    rather than a black box -- so its learned weights can be inspected.

What it actually learns: given the market conditions present at trade
ENTRY (trend/momentum/volatility component scores, RSI, ATR%, market
breadth, hour of day, day of week), predict the probability THIS bot's
strategy wins the trade. This is meta-learning about your own strategy's
blind spots, not a market-prediction oracle.
"""
import os
import time
import sqlite3
import threading
from dataclasses import dataclass, asdict
from datetime import datetime

import numpy as np
import pandas as pd

import config

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import accuracy_score, brier_score_loss
    from sklearn.model_selection import TimeSeriesSplit
    import joblib
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


def _build_model():
    """Model type is configurable (config.ML_MODEL_TYPE). Gradient boosting
    can capture non-linear interactions between features (e.g. "high trend
    score only matters when volatility is also in the healthy range") that
    a linear logistic regression structurally cannot -- at the cost of being
    less directly interpretable, which is why walk-forward validation below
    matters even more with this model type: a flexible model overfits a
    small sample more easily than a rigid one."""
    if config.ML_MODEL_TYPE == "gradient_boosting":
        return GradientBoostingClassifier(
            n_estimators=60, max_depth=2, learning_rate=0.08,
            subsample=0.8, random_state=42,
        )
    return LogisticRegression(max_iter=1000, C=0.5, class_weight="balanced")


FEATURE_COLUMNS = [
    "trend_score", "momentum_score", "volatility_score", "rsi",
    "atr_pct", "market_breadth", "hour_of_day", "day_of_week", "signal_score",
]


@dataclass
class TradeFeatureRecord:
    ts: float
    symbol: str
    trend_score: float
    momentum_score: float
    volatility_score: float
    rsi: float
    atr_pct: float
    market_breadth: float
    hour_of_day: int
    day_of_week: int
    signal_score: float
    outcome: int = None       # 1 = win, 0 = loss -- filled in on close
    pnl_usdt: float = None
    r_multiple: float = None  # pnl / initial risk_usdt


class TradeLearner:
    def __init__(self, db_path: str = "quantis_ledger.sqlite3", model_path: str = "quantis_model.joblib"):
        self.db_path = db_path
        self.model_path = model_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._db_lock = threading.Lock()
        self._init_schema()
        self.model = None
        self.scaler = None
        self.last_trained_at = None
        self.last_train_metrics = {"status": "untrained"}
        self._try_load_model()

    def _init_schema(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS trade_features (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL, symbol TEXT,
                trend_score REAL, momentum_score REAL, volatility_score REAL,
                rsi REAL, atr_pct REAL, market_breadth REAL,
                hour_of_day INTEGER, day_of_week INTEGER, signal_score REAL,
                outcome INTEGER, pnl_usdt REAL, r_multiple REAL,
                entry_open INTEGER DEFAULT 1
            )
        """)
        self.conn.commit()

    def record_entry(self, symbol: str, feature_dict: dict) -> int:
        """Called when a trade opens. Returns the row id to close out later."""
        row = {
            "ts": time.time(), "symbol": symbol,
            "trend_score": feature_dict.get("trend_score", feature_dict.get("trend")),
            "momentum_score": feature_dict.get("momentum_score", feature_dict.get("momentum")),
            "volatility_score": feature_dict.get("volatility_score", feature_dict.get("volatility")),
            "rsi": feature_dict.get("rsi") or 50.0,
            "atr_pct": feature_dict.get("atr_pct") or 0.0,
            "market_breadth": feature_dict.get("market_breadth") or 0.5,
            "hour_of_day": datetime.now().hour,
            "day_of_week": datetime.now().weekday(),
            "signal_score": feature_dict.get("signal_score") or feature_dict.get("score") or 0.0,
            "outcome": None, "pnl_usdt": None, "r_multiple": None, "entry_open": 1,
        }
        with self._db_lock:
            cur = self.conn.execute(
                "INSERT INTO trade_features (ts, symbol, trend_score, momentum_score, volatility_score, "
                "rsi, atr_pct, market_breadth, hour_of_day, day_of_week, signal_score, outcome, pnl_usdt, "
                "r_multiple, entry_open) VALUES (:ts,:symbol,:trend_score,:momentum_score,:volatility_score,"
                ":rsi,:atr_pct,:market_breadth,:hour_of_day,:day_of_week,:signal_score,:outcome,:pnl_usdt,"
                ":r_multiple,:entry_open)",
                row,
            )
            self.conn.commit()
            return cur.lastrowid

    def record_exit(self, row_id: int, pnl_usdt: float, risk_usdt: float):
        """Called when a trade closes. Fills in the outcome for the matching entry."""
        outcome = 1 if pnl_usdt > 0 else 0
        r_multiple = (pnl_usdt / risk_usdt) if risk_usdt else None
        with self._db_lock:
            self.conn.execute(
                "UPDATE trade_features SET outcome=?, pnl_usdt=?, r_multiple=?, entry_open=0 WHERE id=?",
                (outcome, pnl_usdt, r_multiple, row_id),
            )
            self.conn.commit()

    def sample_count(self) -> int:
        with self._db_lock:
            row = self.conn.execute("SELECT COUNT(*) FROM trade_features WHERE outcome IS NOT NULL").fetchone()
        return row[0] if row else 0

    def _load_training_frame(self) -> pd.DataFrame:
        with self._db_lock:
            return pd.read_sql(
                "SELECT * FROM trade_features WHERE outcome IS NOT NULL ORDER BY ts ASC", self.conn
            )

    def train(self) -> dict:
        """
        Retrains on all closed trades. Uses a simple time-based 80/20
        train/test split (train on older trades, test on the most recent
        20%) rather than random shuffling -- random splits on time-series
        trade data leak future information into training and produce
        falsely optimistic accuracy. Reports honest out-of-sample metrics.
        """
        if not SKLEARN_AVAILABLE:
            self.last_train_metrics = {"status": "sklearn_not_available"}
            return self.last_train_metrics

        df = self._load_training_frame()
        n = len(df)

        if n < config.ML_MIN_SAMPLES_TO_TRAIN:
            self.last_train_metrics = {
                "status": "insufficient_data",
                "samples": n,
                "min_required": config.ML_MIN_SAMPLES_TO_TRAIN,
            }
            return self.last_train_metrics

        X = df[FEATURE_COLUMNS].fillna(df[FEATURE_COLUMNS].median())
        y = df["outcome"].astype(int)

        if y.nunique() < 2:
            self.last_train_metrics = {"status": "insufficient_class_variety", "samples": n}
            return self.last_train_metrics

        # --- Walk-forward validation: more honest than a single 80/20 split.
        # TimeSeriesSplit never trains on future data to predict the past --
        # each fold trains on everything before it, tests on what comes next,
        # and we average across folds. A single split can get lucky or
        # unlucky on which 20% landed in the test set; averaging several
        # time-respecting folds is a materially more honest accuracy number,
        # especially important now that the model type can be a more
        # flexible gradient-boosted tree that overfits more easily than
        # logistic regression.
        n_folds = min(config.ML_WALK_FORWARD_FOLDS, max(2, n // 15))
        fold_accuracies, fold_briers = [], []
        try:
            tscv = TimeSeriesSplit(n_splits=n_folds)
            for train_idx, test_idx in tscv.split(X):
                if y.iloc[train_idx].nunique() < 2 or len(test_idx) == 0:
                    continue
                fold_scaler = StandardScaler()
                Xf_train = fold_scaler.fit_transform(X.iloc[train_idx])
                Xf_test = fold_scaler.transform(X.iloc[test_idx])
                fold_model = _build_model()
                fold_model.fit(Xf_train, y.iloc[train_idx])
                preds = fold_model.predict(Xf_test)
                proba = fold_model.predict_proba(Xf_test)[:, 1]
                fold_accuracies.append(accuracy_score(y.iloc[test_idx], preds))
                try:
                    fold_briers.append(brier_score_loss(y.iloc[test_idx], proba))
                except Exception:
                    pass
        except Exception as e:
            fold_accuracies = []

        walk_forward_accuracy = round(float(np.mean(fold_accuracies)), 3) if fold_accuracies else None
        walk_forward_brier = round(float(np.mean(fold_briers)), 4) if fold_briers else None
        walk_forward_folds_used = len(fold_accuracies)

        # --- Final model: fit on ALL data for actual live predictions, but
        # still report a single most-recent-slice holdout for continuity
        # with the simpler metric shown in earlier versions.
        split_idx = int(n * 0.8)
        X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

        if y_train.nunique() < 2 or len(X_test) == 0:
            self.last_train_metrics = {"status": "insufficient_class_variety", "samples": n}
            return self.last_train_metrics

        holdout_scaler = StandardScaler()
        X_train_s = holdout_scaler.fit_transform(X_train)
        X_test_s = holdout_scaler.transform(X_test)
        holdout_model = _build_model()
        holdout_model.fit(X_train_s, y_train)
        test_preds = holdout_model.predict(X_test_s)
        test_proba = holdout_model.predict_proba(X_test_s)[:, 1]
        acc = accuracy_score(y_test, test_preds) if len(y_test) else None
        baseline_acc = max(y_test.mean(), 1 - y_test.mean()) if len(y_test) else None

        # Production model: refit on ALL available data with the final scaler
        scaler = StandardScaler()
        X_all_s = scaler.fit_transform(X)
        model = _build_model()
        model.fit(X_all_s, y)

        if config.ML_MODEL_TYPE == "gradient_boosting":
            importances = dict(zip(FEATURE_COLUMNS, [round(float(w), 3) for w in model.feature_importances_]))
            weights_key = "feature_importances"
        else:
            importances = dict(zip(FEATURE_COLUMNS, [round(float(w), 3) for w in model.coef_[0]]))
            weights_key = "feature_weights"

        self.model = model
        self.scaler = scaler
        self.last_trained_at = datetime.now().isoformat(timespec="seconds")
        self.last_train_metrics = {
            "status": "trained",
            "model_type": config.ML_MODEL_TYPE,
            "samples_total": n,
            "samples_train": len(X_train),
            "samples_test": len(X_test),
            "test_accuracy": round(float(acc), 3) if acc is not None else None,
            "baseline_accuracy": round(float(baseline_acc), 3) if baseline_acc is not None else None,
            "beats_baseline": bool(acc is not None and baseline_acc is not None and acc > baseline_acc),
            "walk_forward_accuracy": walk_forward_accuracy,
            "walk_forward_brier": walk_forward_brier,
            "walk_forward_folds_used": walk_forward_folds_used,
            "walk_forward_beats_baseline": bool(
                walk_forward_accuracy is not None and baseline_acc is not None
                and walk_forward_accuracy > baseline_acc
            ) if walk_forward_accuracy is not None else None,
            "trained_at": self.last_trained_at,
            weights_key: importances,
        }

        self._save_model()
        return self.last_train_metrics

    def predict_win_probability(self, feature_dict: dict):
        """
        Returns a win probability in [0,1], or None if the model isn't
        trained/ready yet (caller must handle None by falling back to
        rules-only scoring -- see risk.py blend_ml_score()).
        """
        if not SKLEARN_AVAILABLE or self.model is None or self.scaler is None:
            return None
        if self.sample_count() < config.ML_MIN_SAMPLES_TO_ACT:
            return None

        row = {
            "trend_score": feature_dict.get("trend_score", feature_dict.get("trend", 0)),
            "momentum_score": feature_dict.get("momentum_score", feature_dict.get("momentum", 0)),
            "volatility_score": feature_dict.get("volatility_score", feature_dict.get("volatility", 0)),
            "rsi": feature_dict.get("rsi") or 50.0,
            "atr_pct": feature_dict.get("atr_pct") or 0.0,
            "market_breadth": feature_dict.get("market_breadth") or 0.5,
            "hour_of_day": datetime.now().hour,
            "day_of_week": datetime.now().weekday(),
            "signal_score": feature_dict.get("signal_score") or feature_dict.get("score") or 0.0,
        }
        X = pd.DataFrame([row])[FEATURE_COLUMNS]
        X_s = self.scaler.transform(X)
        proba = self.model.predict_proba(X_s)[0, 1]
        return float(proba)

    def _save_model(self):
        if self.model is not None:
            try:
                joblib.dump({"model": self.model, "scaler": self.scaler, "metrics": self.last_train_metrics}, self.model_path)
            except Exception as e:
                print(f"[Learner] failed to save model: {e}")

    def _try_load_model(self):
        if not SKLEARN_AVAILABLE or not os.path.exists(self.model_path):
            return
        try:
            payload = joblib.load(self.model_path)
            self.model = payload["model"]
            self.scaler = payload["scaler"]
            self.last_train_metrics = payload.get("metrics", {"status": "loaded_from_disk"})
        except Exception as e:
            print(f"[Learner] failed to load model: {e}")

    def status(self) -> dict:
        return {
            "sklearn_available": SKLEARN_AVAILABLE,
            "samples_recorded": self.sample_count(),
            "min_samples_to_train": config.ML_MIN_SAMPLES_TO_TRAIN,
            "min_samples_to_act": config.ML_MIN_SAMPLES_TO_ACT,
            "model_ready": self.model is not None and self.sample_count() >= config.ML_MIN_SAMPLES_TO_ACT,
            "last_train_metrics": self.last_train_metrics,
        }

    def close(self):
        self.conn.close()
