"""
Capital & Profit Separation Ledger — Section 06 of the plan.

Tracks three balances:
  - trading_capital: the working pool used to size new positions
  - profit_vault: realized, locked-in gains removed from trading risk
  - reserve: optional untouched buffer (not traded, tracked separately by the user)

Persists to a local SQLite database so the ledger survives restarts.
"""
import sqlite3
import threading
import time
from dataclasses import dataclass, asdict

import config


@dataclass
class LedgerEntry:
    ts: float
    event: str                 # "trade_close", "deposit", "manual_adjustment"
    symbol: str
    pnl_usdt: float
    trading_capital_after: float
    profit_vault_after: float
    note: str = ""


class CapitalManager:
    def __init__(self, db_path: str = None, starting_capital: float = None):
        self.db_path = db_path or config.LEDGER_DB_PATH
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._db_lock = threading.Lock()
        self._init_schema()

        row = self.conn.execute("SELECT trading_capital, profit_vault FROM state WHERE id = 1").fetchone()
        if row is None:
            self.trading_capital = starting_capital if starting_capital is not None else config.STARTING_CAPITAL
            self.profit_vault = 0.0
            self.conn.execute(
                "INSERT INTO state (id, trading_capital, profit_vault) VALUES (1, ?, ?)",
                (self.trading_capital, self.profit_vault),
            )
            self.conn.commit()
        else:
            self.trading_capital, self.profit_vault = row

    def _init_schema(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS state (
                id INTEGER PRIMARY KEY,
                trading_capital REAL,
                profit_vault REAL
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL, event TEXT, symbol TEXT, pnl_usdt REAL,
                trading_capital_after REAL, profit_vault_after REAL, note TEXT
            )
        """)
        self.conn.commit()

    def _persist_state(self):
        with self._db_lock:
            self.conn.execute(
                "UPDATE state SET trading_capital = ?, profit_vault = ? WHERE id = 1",
                (self.trading_capital, self.profit_vault),
            )
            self.conn.commit()

    def _log(self, event, symbol, pnl_usdt, note=""):
        entry = LedgerEntry(
            ts=time.time(), event=event, symbol=symbol, pnl_usdt=pnl_usdt,
            trading_capital_after=self.trading_capital,
            profit_vault_after=self.profit_vault, note=note,
        )
        d = asdict(entry)
        with self._db_lock:
            self.conn.execute(
                "INSERT INTO ledger (ts, event, symbol, pnl_usdt, trading_capital_after, profit_vault_after, note) "
                "VALUES (:ts, :event, :symbol, :pnl_usdt, :trading_capital_after, :profit_vault_after, :note)",
                d,
            )
            self.conn.commit()

    def apply_trade_result(self, symbol: str, pnl_usdt: float, strategy: str = None, regime: str = None):
        """
        Applies the Section 06 split rule:
          - Original position capital always returns to trading_capital (implicit —
            trading_capital only ever moves by pnl, not by the full position size,
            since the position was already carved out of trading_capital at entry).
          - If pnl > 0: split the PROFIT itself — PROFIT_TO_VAULT_PCT goes to the
            vault (locked), the remainder compounds back into trading_capital.
          - If pnl <= 0: the full loss reduces trading_capital directly. No vault
            impact — losses are never taken from locked profit.

        strategy/regime are optional tags (e.g. "trend_following"/"trending")
        recorded in the ledger note for later per-strategy analytics -- see
        analytics.py's _parse_tags(). Purely descriptive; doesn't affect the
        capital math above.
        """
        if pnl_usdt > 0:
            to_vault = pnl_usdt * config.PROFIT_TO_VAULT_PCT
            to_capital = pnl_usdt - to_vault
            self.profit_vault += to_vault
            self.trading_capital += to_capital
            note = f"profit split: {to_vault:.2f} -> vault, {to_capital:.2f} -> capital"
        else:
            self.trading_capital += pnl_usdt  # pnl_usdt is negative here
            note = f"loss absorbed by trading capital: {pnl_usdt:.2f}"

        tag = f"[strategy={strategy or 'unknown'} regime={regime or 'unknown'}] "
        note = tag + note

        self._persist_state()
        self._log("trade_close", symbol, pnl_usdt, note)

    def total_equity(self) -> float:
        return self.trading_capital + self.profit_vault

    def summary(self) -> dict:
        return {
            "trading_capital": round(self.trading_capital, 2),
            "profit_vault": round(self.profit_vault, 2),
            "total_equity": round(self.total_equity(), 2),
        }

    def recent_ledger(self, limit=50):
        with self._db_lock:
            cur = self.conn.execute(
                "SELECT ts, event, symbol, pnl_usdt, trading_capital_after, profit_vault_after, note "
                "FROM ledger ORDER BY id DESC LIMIT ?", (limit,)
            )
            rows = cur.fetchall()
        cols = ["ts", "event", "symbol", "pnl_usdt", "trading_capital_after", "profit_vault_after", "note"]
        return [dict(zip(cols, row)) for row in rows]

    def close(self):
        self.conn.close()
