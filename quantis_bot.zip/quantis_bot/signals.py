"""
Signal Scoring Engine
Scores each asset 0-100 based on trend strength, momentum, volatility regime,
MACD confirmation, and Bollinger Band positioning. Optionally confirmed by a
higher timeframe (multi-timeframe alignment) when higher-timeframe data is
supplied. This is the decision core described in Section 03/04 of the plan
-- pure, auditable rules-based logic. No black box, before any ML blending
happens on top of it (see risk.py's blend_ml_score + learner.py).
"""
import pandas as pd
import numpy as np
import ta

import config


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Attach EMA fast/slow, RSI, ATR, MACD, and Bollinger Band columns."""
    df = df.copy()
    df["ema_fast"] = ta.trend.ema_indicator(df["close"], window=config.EMA_FAST)
    df["ema_slow"] = ta.trend.ema_indicator(df["close"], window=config.EMA_SLOW)
    df["rsi"] = ta.momentum.rsi(df["close"], window=config.RSI_PERIOD)
    df["atr"] = ta.volatility.average_true_range(
        df["high"], df["low"], df["close"], window=config.ATR_PERIOD
    )

    macd = ta.trend.MACD(df["close"], window_slow=26, window_fast=12, window_sign=9)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_hist"] = macd.macd_diff()

    bb = ta.volatility.BollingerBands(df["close"], window=20, window_dev=2)
    df["bb_high"] = bb.bollinger_hband()
    df["bb_low"] = bb.bollinger_lband()
    df["bb_mid"] = bb.bollinger_mavg()
    df["bb_pct"] = bb.bollinger_pband()  # 0 = at lower band, 1 = at upper band

    df["adx"] = ta.trend.adx(df["high"], df["low"], df["close"], window=config.ADX_PERIOD)
    df["volume_ma"] = df["volume"].rolling(window=config.VOLUME_MA_PERIOD).mean()

    return df


def detect_regime(df: pd.DataFrame) -> str:
    """
    Classifies the current market condition using ADX (Average Directional
    Index), which measures trend STRENGTH regardless of direction:
      - ADX above ADX_TRENDING_THRESHOLD  -> "trending"  (trend-following applies)
      - ADX below ADX_CHOPPY_THRESHOLD    -> "choppy"     (mean-reversion applies)
      - in between                         -> "neutral"    (neither strategy gets
        full confidence -- this deliberate gap between the two thresholds
        stops the bot from flip-flopping strategy on every minor ADX wiggle)
    """
    if len(df) < config.ADX_PERIOD + 2:
        return "neutral"
    adx = df["adx"].iloc[-1]
    if pd.isna(adx):
        return "neutral"
    if adx >= config.ADX_TRENDING_THRESHOLD:
        return "trending"
    elif adx <= config.ADX_CHOPPY_THRESHOLD:
        return "choppy"
    return "neutral"


def volume_confirmation_factor(df: pd.DataFrame) -> dict:
    """
    Returns whether the current bar's volume is healthy enough to trust the
    signal, plus the ratio itself for transparency. Thin volume means a move
    is more likely noise, a stale quote, or a single large order distorting
    price briefly -- not a reflection of genuine market conviction.
    """
    if len(df) < config.VOLUME_MA_PERIOD + 1:
        return {"passes": True, "ratio": None, "reason": "insufficient_data_default_pass"}
    last = df.iloc[-1]
    vol_ma = last.get("volume_ma")
    if pd.isna(vol_ma) or vol_ma <= 0:
        return {"passes": True, "ratio": None, "reason": "no_volume_ma_default_pass"}
    ratio = last["volume"] / vol_ma
    passes = ratio >= config.VOLUME_MIN_RATIO
    return {"passes": bool(passes), "ratio": round(float(ratio), 2), "reason": "ok"}


def score_mean_reversion(df: pd.DataFrame) -> dict:
    """
    Mean-reversion scoring for choppy/range-bound conditions (Section 04 of
    the plan: grid/mean-reversion as a complement to trend-following, not a
    replacement). Looks for price pressed against the lower Bollinger Band
    with RSI deeply oversold -- a bounce-back-to-the-mean setup, NOT a
    "catch the falling knife" setup (that distinction matters: this only
    fires in a *choppy* regime, never in a confirmed downtrend, which the
    regime filter in risk.py separately guards against).
    """
    if len(df) < 25:
        return {"score": 0, "strategy": "mean_reversion", "reason": "insufficient_data"}

    last = df.iloc[-1]
    bb_pct = last.get("bb_pct")
    rsi = last.get("rsi")
    atr = last.get("atr")

    if bb_pct is None or pd.isna(bb_pct) or rsi is None or pd.isna(rsi) or pd.isna(atr) or atr <= 0:
        return {"score": 0, "strategy": "mean_reversion", "reason": "nan_indicators"}

    score = 0.0
    # Near/below the lower band
    if bb_pct <= config.MEAN_REVERSION_BB_ENTRY_PCT:
        score += 50
    elif bb_pct <= 0.15:
        score += 30
    elif bb_pct <= 0.25:
        score += 12

    # Deeply oversold RSI
    if rsi <= config.MEAN_REVERSION_RSI_OVERSOLD:
        score += 35
    elif rsi <= 35:
        score += 20
    elif rsi <= 40:
        score += 8

    # Volatility sanity (same tradeable-range logic as trend scoring)
    atr_pct = atr / last["close"]
    if 0.002 <= atr_pct <= 0.02:
        score += 15
    elif 0.02 < atr_pct <= 0.04:
        score += 8

    score = float(np.clip(score, 0, 100))
    return {
        "score": round(score, 1), "strategy": "mean_reversion",
        "bb_pct": round(float(bb_pct), 3), "rsi": round(float(rsi), 1),
        "atr_pct": round(float(atr_pct) * 100, 3), "close": float(last["close"]),
        "target_price": float(last.get("bb_mid", last["close"])),  # mean-reversion target: back to the mid band
        "reason": "ok",
    }


def score_asset(df: pd.DataFrame, higher_tf_df: pd.DataFrame = None) -> dict:
    """
    Produce a 0-100 signal score for the most recent bar. Component budget:
      - Trend (0-40): EMA fast/slow separation, normalized by ATR
      - Momentum (0-20): RSI positioned constructively
      - Volatility (0-15): ATR in a "tradeable" range
      - MACD confirmation (0-15): MACD histogram agrees with the EMA trend
        direction and is expanding (rising conviction), not fading
      - Bollinger positioning (0-10): price in the healthy-trend zone of the
        bands (roughly the upper-middle band on an uptrend) rather than
        already stretched to the extreme band (chase risk) or sitting at
        the midline (no edge yet)
      - Multi-timeframe bonus (up to +10, or -15 penalty): if higher_tf_df is
        supplied, reward alignment between this timeframe's trend and the
        higher timeframe's trend, and penalize disagreement -- entering a
        1h uptrend signal against a 4h downtrend is exactly the kind of
        trade that tends to reverse on you.
    """
    if len(df) < max(config.EMA_SLOW, config.RSI_PERIOD, config.ATR_PERIOD, 26) + 2:
        return {"score": 0, "trend": 0, "momentum": 0, "volatility": 0, "macd": 0, "bollinger": 0, "mtf": 0, "reason": "insufficient_data"}

    last = df.iloc[-1]
    prev = df.iloc[-2]

    if pd.isna(last["ema_fast"]) or pd.isna(last["ema_slow"]) or pd.isna(last["atr"]) or last["atr"] == 0:
        return {"score": 0, "trend": 0, "momentum": 0, "volatility": 0, "macd": 0, "bollinger": 0, "mtf": 0, "reason": "nan_indicators"}

    # --- Trend component (0-40) ---
    ema_gap = (last["ema_fast"] - last["ema_slow"]) / last["atr"]
    trend_score = np.clip(40 * (0.5 + ema_gap / 4), 0, 40)
    is_uptrend = last["ema_fast"] > last["ema_slow"]

    # --- Momentum component (0-20) ---
    rsi = last["rsi"]
    if pd.isna(rsi):
        momentum_score = 0
    elif is_uptrend:
        if config.RSI_OVERBOUGHT <= rsi:
            momentum_score = 5
        elif 45 <= rsi < config.RSI_OVERBOUGHT:
            momentum_score = 20
        elif 40 <= rsi < 45:
            momentum_score = 12
        else:
            momentum_score = 3
    else:
        momentum_score = 3

    # --- Volatility component (0-15) ---
    atr_pct = last["atr"] / last["close"]
    if atr_pct < 0.002:
        volatility_score = 2
    elif 0.002 <= atr_pct <= 0.02:
        volatility_score = 15
    elif 0.02 < atr_pct <= 0.04:
        volatility_score = 9
    else:
        volatility_score = 3

    # --- MACD confirmation component (0-15) ---
    macd_score = 0
    if not pd.isna(last.get("macd_hist")) and not pd.isna(prev.get("macd_hist")):
        hist = last["macd_hist"]
        hist_prev = prev["macd_hist"]
        hist_expanding = abs(hist) > abs(hist_prev)
        if is_uptrend and hist > 0:
            macd_score = 15 if hist_expanding else 9
        elif is_uptrend and hist <= 0:
            macd_score = 3   # trend says up, momentum says down -- disagreement, don't reward
        else:
            macd_score = 2

    # --- Bollinger positioning component (0-10) ---
    bollinger_score = 0
    bb_pct = last.get("bb_pct")
    if bb_pct is not None and not pd.isna(bb_pct):
        if is_uptrend:
            if 0.5 <= bb_pct <= 0.85:
                bollinger_score = 10   # healthy trend zone, room to run
            elif 0.85 < bb_pct <= 1.05:
                bollinger_score = 5    # stretched, chase risk rising
            elif bb_pct > 1.05:
                bollinger_score = 2    # extreme, high chase risk
            else:
                bollinger_score = 4    # below midline in an uptrend -- early or weak
        else:
            bollinger_score = 2

    # --- Multi-timeframe confirmation (bonus/penalty, not part of the 100-pt budget) ---
    mtf_adjustment = 0
    mtf_note = "not_checked"
    if higher_tf_df is not None and len(higher_tf_df) >= config.EMA_SLOW + 2:
        htf_last = higher_tf_df.iloc[-1]
        if not pd.isna(htf_last.get("ema_fast")) and not pd.isna(htf_last.get("ema_slow")):
            htf_uptrend = htf_last["ema_fast"] > htf_last["ema_slow"]
            if is_uptrend and htf_uptrend:
                mtf_adjustment = 10
                mtf_note = "aligned_bullish"
            elif is_uptrend and not htf_uptrend:
                mtf_adjustment = -15
                mtf_note = "conflict_lower_tf_up_higher_tf_down"
            else:
                mtf_adjustment = 0
                mtf_note = "not_applicable"

    total = trend_score + momentum_score + volatility_score + macd_score + bollinger_score + mtf_adjustment
    total = float(np.clip(total, 0, 100))

    return {
        "score": round(total, 1),
        "trend": round(float(trend_score), 1),
        "momentum": round(float(momentum_score), 1),
        "volatility": round(float(volatility_score), 1),
        "macd": round(float(macd_score), 1),
        "bollinger": round(float(bollinger_score), 1),
        "mtf": mtf_adjustment,
        "mtf_note": mtf_note,
        "is_uptrend": bool(is_uptrend),
        "rsi": round(float(rsi), 1) if not pd.isna(rsi) else None,
        "atr_pct": round(float(atr_pct) * 100, 3),
        "bb_pct": round(float(bb_pct), 3) if bb_pct is not None and not pd.isna(bb_pct) else None,
        "close": float(last["close"]),
        "reason": "ok",
    }


def generate_signal(df: pd.DataFrame, higher_tf_df: pd.DataFrame = None) -> dict:
    """
    Unified entry point: detects the current regime and routes to the
    appropriate strategy. This is the "which brain do I use right now"
    decision -- trend-following in trending markets, mean-reversion in
    choppy ones, and reduced confidence in the neutral zone between them.
    Volume confirmation is applied as a final gate on top of either strategy.
    """
    regime = detect_regime(df)

    if regime == "trending":
        result = score_asset(df, higher_tf_df=higher_tf_df)
        result["strategy"] = "trend_following"
        result["regime"] = regime
    elif regime == "choppy" and config.USE_MEAN_REVERSION:
        result = score_mean_reversion(df)
        result["regime"] = regime
    else:
        # neutral zone (or mean-reversion disabled in a choppy market):
        # still score with trend-following logic but cap confidence, since
        # neither strategy has a real edge here.
        result = score_asset(df, higher_tf_df=higher_tf_df)
        result["strategy"] = "trend_following_low_confidence"
        result["regime"] = regime
        result["score"] = round(result["score"] * 0.6, 1)

    if config.USE_VOLUME_CONFIRMATION:
        vol = volume_confirmation_factor(df)
        result["volume_ratio"] = vol["ratio"]
        if not vol["passes"]:
            result["score"] = round(result["score"] * 0.5, 1)
            result["volume_penalized"] = True
        else:
            result["volume_penalized"] = False

    return result


def scan_universe(price_data: dict, higher_tf_data: dict = None) -> pd.DataFrame:
    """
    price_data: {symbol: OHLCV dataframe}. higher_tf_data: optional
    {symbol: OHLCV dataframe on a higher timeframe} for multi-timeframe
    confirmation. Returns a DataFrame sorted by score, descending.
    """
    rows = []
    for symbol, df in price_data.items():
        if "ema_fast" not in df.columns:
            df = add_indicators(df)
        htf_df = None
        if higher_tf_data and symbol in higher_tf_data:
            htf_df = higher_tf_data[symbol]
            if "ema_fast" not in htf_df.columns:
                htf_df = add_indicators(htf_df)
        result = score_asset(df, higher_tf_df=htf_df)
        result["symbol"] = symbol
        rows.append(result)

    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values("score", ascending=False).reset_index(drop=True)
    return out


def market_breadth(scan_df) -> float:
    """
    Fraction of the scanned universe currently in an uptrend (ema_fast > ema_slow).
    Used as a regime filter: don't open new long positions when the broad market
    is weak, even if one asset's individual score looks good -- fighting the tape
    is one of the most common ways retail strategies bleed out.
    """
    if scan_df is None or len(scan_df) == 0:
        return 0.0
    if "is_uptrend" not in scan_df.columns:
        return 0.0
    valid = scan_df["is_uptrend"].dropna()
    if len(valid) == 0:
        return 0.0
    return float(valid.mean())
