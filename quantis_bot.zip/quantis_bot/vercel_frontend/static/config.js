// Vercel frontend configuration.
// Set this to your VPS's public URL where server.py/gunicorn is running
// (see ../../DEPLOYMENT.md). Must be HTTPS if this page is served over
// HTTPS (Vercel always is) — browsers block HTTPS pages from calling HTTP
// APIs. Put a reverse proxy (Caddy/nginx) with a real cert in front of
// your VPS if it isn't already, per DEPLOYMENT.md.
window.QUANTIS_API_BASE = "https://your-vps-domain.com";
