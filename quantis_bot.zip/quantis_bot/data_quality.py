"""
Market-data validation. Never assume missing, delayed or odd data is accurate.

validate_ohlcv() checks timestamps, duplicates, gaps, NaNs, impossible candles,
bad ticks and staleness, and returns a cleaned frame plus a report. Fatal issues
mean: take no new decisions on this instrument until the data is healthy again.
"""
from dataclasses import dataclass, field

import pandas as pd

import config

_UNITS = {"m": 60, "h": 3600, "d": 86400}


def timeframe_seconds(tf: str) -> int:
    return int(tf[:-1]) * _UNITS[tf[-1]]


@dataclass
class DataQualityReport:
    ok: bool
    issues: list = field(default_factory=list)
    fatal: list = field(default_factory=list)
    cleaned: pd.DataFrame = None
    stats: dict = field(default_factory=dict)


def validate_ohlcv(df: pd.DataFrame, bar_seconds: int = None, check_stale: bool = False, now=None) -> DataQualityReport:
    issues, fatal = [], []
    need = {"open", "high", "low", "close", "volume"}
    if df is None or len(df) == 0:
        return DataQualityReport(False, [], ["empty_dataframe"], df, {})
    if not need.issubset(df.columns):
        return DataQualityReport(False, [], [f"missing_columns:{sorted(need - set(df.columns))}"], df, {})

    d = df.copy()
    if not isinstance(d.index, pd.DatetimeIndex):
        try:
            d.index = pd.to_datetime(d.index)
        except Exception:
            return DataQualityReport(False, [], ["unparseable_timestamps"], df, {})
    if d.index.tz is not None:
        d.index = d.index.tz_convert("UTC").tz_localize(None)

    n_dup = int(d.index.duplicated().sum())
    if n_dup:
        issues.append(f"duplicate_timestamps:{n_dup}")
        d = d[~d.index.duplicated(keep="last")]
    if not d.index.is_monotonic_increasing:
        issues.append("unsorted_index_fixed")
        d = d.sort_index()

    price_cols = ["open", "high", "low", "close"]
    nan_rows = int(d[price_cols].isna().any(axis=1).sum())
    if nan_rows:
        issues.append(f"nan_rows_dropped:{nan_rows}")
        if nan_rows / len(d) > 0.05:
            fatal.append("too_many_nan_rows")
        d = d.dropna(subset=price_cols)
    if len(d) == 0:
        return DataQualityReport(False, issues, fatal + ["no_valid_rows"], d, {})

    if (d[price_cols] <= 0).any().any():
        fatal.append("non_positive_prices")

    bad = (d["high"] < d["low"] - 1e-12) | (d["close"] > d["high"] + 1e-9) | (d["close"] < d["low"] - 1e-9) \
        | (d["open"] > d["high"] + 1e-9) | (d["open"] < d["low"] - 1e-9)
    recent_n = config.DQ_RECENT_GAP_WINDOW
    if bad.any():
        issues.append(f"invalid_candles:{int(bad.sum())}")
        if bad.tail(recent_n).any():
            fatal.append("invalid_candle_in_recent_bars")

    jumps = d["close"].pct_change().abs() > config.DQ_MAX_JUMP_PCT
    if jumps.any():
        issues.append(f"abnormal_price_jumps:{int(jumps.sum())}")
        if jumps.tail(recent_n).any():
            fatal.append("abnormal_price_jump_in_recent_bars")

    diffs = d.index.to_series().diff().dt.total_seconds().dropna()
    bar = bar_seconds or (float(diffs.median()) if len(diffs) else None)
    n_gaps = 0
    if bar and len(diffs):
        gap_mask = diffs > 1.5 * bar
        n_gaps = int(gap_mask.sum())
        if n_gaps:
            issues.append(f"missing_candles_gaps:{n_gaps}")
            if gap_mask.tail(recent_n).any():
                fatal.append("missing_candles_in_recent_bars")

    if check_stale and bar:
        ref = now if now is not None else pd.Timestamp.now("UTC").tz_localize(None)
        age = (ref - d.index[-1]).total_seconds()
        if age > config.DQ_MAX_STALE_BARS * bar:
            fatal.append(f"stale_data:{age:.0f}s_old")

    return DataQualityReport(len(fatal) == 0, issues, fatal, d,
                             {"rows": len(d), "bar_seconds": bar, "gaps": n_gaps, "duplicates": n_dup})
