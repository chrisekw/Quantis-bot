import numpy as np, pandas as pd, pytest
import config
from synthetic_data import generate_test_universe
from backtester import Backtester
from edge import apply_costs

SYMS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]


@pytest.fixture(scope="module")
def run_a():
    data = generate_test_universe(SYMS, n_bars=1500, seed=21)
    return data, Backtester(data, 500.0).run()


def test_reproducible(run_a):
    data, a = run_a
    b = Backtester(generate_test_universe(SYMS, n_bars=1500, seed=21), 500.0).run()
    assert a.get("total_trades") == b.get("total_trades")
    if a.get("total_trades"):
        pd.testing.assert_frame_equal(a["trades_df"], b["trades_df"])
        assert a["final_equity"] == b["final_equity"]


def test_entries_fill_at_bar_open_plus_costs_never_signal_close(run_a):
    data, r = run_a
    if not r.get("total_trades"):
        pytest.skip("no trades in this run")
    for _, t in r["trades_df"].iterrows():
        bar = data[t.symbol].loc[t.entry_time]
        assert abs(t.entry_price - apply_costs(bar["open"], "buy")) < 1e-6 * bar["open"] + 1e-9


def test_accounting_closes_exactly(run_a):
    _, r = run_a
    if not r.get("total_trades"):
        pytest.skip("no trades")
    assert abs(r["capital_summary"]["total_equity"] - (500 + r["trades_df"].pnl_usdt.sum())) < 0.05


def test_no_overlapping_positions_in_same_symbol_and_concurrency_cap(run_a):
    _, r = run_a
    if not r.get("total_trades"):
        pytest.skip("no trades")
    df = r["trades_df"]
    for sym, g in df.groupby("symbol"):
        g = g.sort_values("entry_time")
        assert (g.entry_time.iloc[1:].values >= g.exit_time.iloc[:-1].values).all()
    events = sorted([(t, 1) for t in df.entry_time] + [(t, -1) for t in df.exit_time], key=lambda x: (x[0], x[1]))
    open_n = peak = 0
    for _, d in events:
        open_n += d; peak = max(peak, open_n)
    assert peak <= config.MAX_CONCURRENT_POSITIONS


def test_costs_are_actually_charged(run_a):
    _, r = run_a
    if r.get("total_trades"):
        assert r["total_costs_usdt"] > 0
        assert r["label"].startswith("HISTORICAL BACKTEST")


def test_bad_data_refuses_to_backtest():
    data = generate_test_universe(SYMS, n_bars=400, seed=2)
    data["BTC/USDT"].iloc[-5:, data["BTC/USDT"].columns.get_indexer(["open", "high", "low", "close"])] *= 4
    with pytest.raises(ValueError):
        Backtester(data, 500.0)
