import config
from capital import CapitalManager


def test_accounting_identity_and_vault_split(tmp_path):
    cm = CapitalManager(db_path=str(tmp_path / "c.sqlite3"), starting_capital=500.0)
    pnls = [10.0, -4.0, 6.0, -1.5, 3.0]
    for p in pnls:
        cm.apply_trade_result("BTC/USDT", p)
    assert abs(cm.total_equity() - (500 + sum(pnls))) < 1e-9
    gains = sum(p for p in pnls if p > 0)
    assert abs(cm.profit_vault - gains * config.PROFIT_TO_VAULT_PCT) < 1e-9


def test_losses_never_touch_the_vault(tmp_path):
    cm = CapitalManager(db_path=str(tmp_path / "c.sqlite3"), starting_capital=500.0)
    cm.apply_trade_result("X", 10.0)
    vault = cm.profit_vault
    cm.apply_trade_result("X", -50.0)
    assert cm.profit_vault == vault


def test_state_survives_restart(tmp_path):
    db = str(tmp_path / "c.sqlite3")
    cm = CapitalManager(db_path=db, starting_capital=500.0)
    cm.apply_trade_result("X", 12.0); cm.apply_trade_result("X", -3.0)
    snap = cm.summary(); cm.close()
    assert CapitalManager(db_path=db, starting_capital=999.0).summary() == snap   # reopen ignores new starting value
