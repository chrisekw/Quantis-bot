import numpy as np, pandas as pd
from data_quality import validate_ohlcv


def make(n=200, freq="1h", seed=0):
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2026-01-01", periods=n, freq=freq)
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.003, n)))
    return pd.DataFrame({"open": close, "high": close * 1.001, "low": close * 0.999, "close": close, "volume": 100.0}, index=idx)


def test_clean_data_passes():
    r = validate_ohlcv(make())
    assert r.ok and not r.fatal


def test_duplicates_removed_and_reported():
    d = make(); d = pd.concat([d, d.iloc[[50]]]).sort_index()
    r = validate_ohlcv(d)
    assert any("duplicate" in i for i in r.issues)
    assert not r.cleaned.index.duplicated().any()


def test_recent_gap_is_fatal():
    d = make().drop(make().index[-10])
    r = validate_ohlcv(d)
    assert not r.ok and "missing_candles_in_recent_bars" in r.fatal


def test_old_gap_only_reported():
    d = make(300); d = d.drop(d.index[5])
    r = validate_ohlcv(d)
    assert r.ok and any("missing_candles" in i for i in r.issues)


def test_abnormal_jump_recent_is_fatal():
    d = make(); d.iloc[-3:, d.columns.get_indexer(["open", "high", "low", "close"])] *= 2.0
    assert not validate_ohlcv(d).ok


def test_stale_data_detected_only_when_checked():
    d = make()
    now = d.index[-1] + pd.Timedelta(hours=10)
    assert validate_ohlcv(d, check_stale=False).ok
    r = validate_ohlcv(d, check_stale=True, now=now)
    assert not r.ok and any(f.startswith("stale_data") for f in r.fatal)


def test_invalid_candle_recent_is_fatal():
    d = make(); d.iloc[-2, d.columns.get_loc("high")] = d.iloc[-2]["low"] * 0.5
    assert not validate_ohlcv(d).ok


def test_missing_columns_and_empty():
    assert not validate_ohlcv(make().drop(columns=["volume"])).ok
    assert not validate_ohlcv(make().iloc[0:0]).ok


def test_non_positive_price_fatal():
    d = make(); d.iloc[10, d.columns.get_loc("close")] = -1
    assert not validate_ohlcv(d).ok
