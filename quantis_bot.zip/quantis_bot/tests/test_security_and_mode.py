import os, subprocess, sys
import pytest
import config
from trading_mode import get_trading_mode, TradingModeError

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _env(**kw):
    e = {k: v for k, v in os.environ.items() if not k.startswith(("QUANTIS_", "TRADING_MODE"))}
    e.update(kw); return e


def test_mode_defaults_to_paper(monkeypatch):
    monkeypatch.delenv("TRADING_MODE", raising=False)
    assert get_trading_mode() == "paper"


@pytest.mark.parametrize("val", ["yolo", "LIVE ", " paper", "papr", "true", "1"])
def test_ambiguous_or_unknown_mode_rejected(monkeypatch, val):
    monkeypatch.setenv("TRADING_MODE", val)
    with pytest.raises(TradingModeError):
        get_trading_mode()


def test_live_engine_refuses_without_explicit_live_mode():
    code = "import live_engine; live_engine._run_startup_gates()"
    r = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=_env(), capture_output=True, text=True)
    assert r.returncode == 1 and "TRADING_MODE is not 'live'" in r.stdout


def test_server_refuses_bad_mode_and_open_production():
    r = subprocess.run([sys.executable, "-c", "import server"], cwd=ROOT, env=_env(TRADING_MODE="bogus"), capture_output=True, text=True, timeout=60)
    assert r.returncode == 1 and "TRADING_MODE" in r.stderr
    r = subprocess.run([sys.executable, "-c", "import server"], cwd=ROOT, env=_env(QUANTIS_PRODUCTION="1"), capture_output=True, text=True, timeout=60)
    assert r.returncode == 1 and "PASSWORD" in r.stderr.upper()


def test_no_secrets_committed_and_gitignored():
    assert config.API_KEY == "" and config.API_SECRET == ""
    assert config.TELEGRAM_BOT_TOKEN == ""
    gi = open(os.path.join(ROOT, ".gitignore")).read()
    for pat in (".env", "*.sqlite3", "*.joblib"):
        assert pat in gi
    assert config.USE_TESTNET is True


def test_api_requires_auth_when_password_set(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    import importlib, server
    importlib.reload(server)
    server.DASHBOARD_PASSWORD = "s3cret"; server.DASHBOARD_USER = "admin"
    c = server.app.test_client()
    assert c.get("/healthz").status_code == 200
    assert c.get("/api/state").status_code == 401
    import base64
    h = {"Authorization": "Basic " + base64.b64encode(b"admin:s3cret").decode()}
    assert c.get("/api/state", headers=h).status_code == 200
    st = c.get("/api/state", headers=h).get_json()
    assert st["trading_mode"] == "paper" and st["data_source"] == "SIMULATED_FEED"
    assert c.get("/api/decisions", headers=h).status_code == 200
    server.engine.stop()
