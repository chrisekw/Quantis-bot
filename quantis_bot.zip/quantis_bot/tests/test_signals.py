import numpy as np, pandas as pd
from synthetic_data import generate_test_universe
from signals import add_indicators, generate_signal


def test_indicators_use_only_past_data():
    """Appending or altering FUTURE bars must not change any indicator value at an earlier timestamp."""
    df = generate_test_universe(["BTC/USDT"], n_bars=400, seed=3)["BTC/USDT"]
    cut = 300
    a = add_indicators(df.iloc[:cut])
    future = df.copy()
    future.iloc[cut:, future.columns.get_indexer(["open", "high", "low", "close"])] *= 5     # wreck the future
    b = add_indicators(future).iloc[:cut]
    pd.testing.assert_frame_equal(a, b)


def test_signal_at_t_ignores_future():
    df = generate_test_universe(["BTC/USDT"], n_bars=400, seed=4)["BTC/USDT"]
    full = add_indicators(df)
    s_cut = generate_signal(full.iloc[:300])
    changed = df.copy(); changed.iloc[300:, changed.columns.get_loc("close")] *= 3
    s_alt = generate_signal(add_indicators(changed).iloc[:300])
    assert s_cut["score"] == s_alt["score"] and s_cut["regime"] == s_alt["regime"]


def test_signal_is_structured_and_bounded():
    df = add_indicators(generate_test_universe(["BTC/USDT"], n_bars=300, seed=5)["BTC/USDT"])
    s = generate_signal(df)
    assert 0 <= s["score"] <= 100 and s["regime"] in ("trending", "choppy", "neutral") and s["strategy"]
