import config
from edge import DecisionMaker, ScoreCalibrator, apply_costs, round_trip_cost_frac


def sig(score=75, regime="trending", strategy="trend_following"):
    return {"score": score, "regime": regime, "strategy": strategy}


def test_costs_are_adverse_both_ways():
    assert apply_costs(100, "buy") > 100 > apply_costs(100, "sell")
    assert abs((apply_costs(100, "buy") - apply_costs(100, "sell")) / 100 - round_trip_cost_frac()) < 1e-3


def test_cost_gate_rejects_tiny_stops():
    d = DecisionMaker().evaluate("BTC/USDT", sig(), entry_price=100, atr=0.05)   # stop = 0.075% of price
    assert not d.approved and d.mode == "cost_gate" and d.signal == "NO TRADE"


def test_fresh_bot_explores_at_reduced_size():
    d = DecisionMaker().evaluate("BTC/USDT", sig(), entry_price=100, atr=1.5)
    assert d.approved and d.mode == "exploration" and d.size_multiplier == config.EDGE_EXPLORATION_SIZE_MULT


def test_calibrated_rejects_when_history_is_negative():
    dm = DecisionMaker()
    for _ in range(config.EDGE_MIN_OBSERVATIONS + 20):
        dm.record_outcome(75, -0.4)
    d = dm.evaluate("BTC/USDT", sig(), 100, 1.5)
    assert not d.approved and d.mode == "calibrated" and "insufficient_edge" in d.reason


def test_calibrated_approves_with_strong_positive_history():
    dm = DecisionMaker()
    for i in range(200):
        dm.record_outcome(75, 1.0 if i % 3 else -1.0)      # mean about +0.33R
    d = dm.evaluate("BTC/USDT", sig(), 100, 1.5)
    assert d.approved and d.mode == "calibrated" and d.size_multiplier == 1.0 and d.expected_return_r > 0


def test_few_lucky_trades_do_not_flip_the_gate():
    dm = DecisionMaker()
    for _ in range(5):
        dm.record_outcome(75, 2.0)
    est = dm.calibrator.estimate(75, cost_r=0.25)
    assert est["ev_r"] < 0.5          # shrunk hard toward the cautious prior


def test_decision_is_structured_and_explains_itself():
    d = DecisionMaker().evaluate("ETH/USDT", sig(), 100, 1.5).to_dict()
    for k in ("symbol", "timestamp", "signal", "regime", "expected_return_r", "uncertainty_r",
              "expected_cost_pct", "rationale", "invalidation"):
        assert k in d
    assert d["invalidation"] and d["rationale"]


def test_calibration_survives_restart(tmp_path):
    from learner import TradeLearner
    db = str(tmp_path / "l.sqlite3")
    l = TradeLearner(db_path=db, model_path=str(tmp_path / "m.joblib"))
    for i in range(12):
        rid = l.record_entry("BTC/USDT", {"signal_score": 70, "trend_score": 20, "momentum_score": 10,
                                          "volatility_score": 10, "rsi": 50, "atr_pct": 1.0, "market_breadth": 0.5})
        l.record_exit(rid, pnl_usdt=1.0 if i % 2 else -1.0, risk_usdt=1.0)
    l.close()
    assert DecisionMaker(db_path=db).calibrator.n == 12
