import config
from risk import (build_trade_plan, calc_position_size, check_pre_trade_gates, CircuitBreaker,
                  update_trailing_stop)
from edge import Decision


def plan(capital=500.0, score=80, price=100.0, atr=1.0, **kw):
    return build_trade_plan("BTC/USDT", price, atr, score, capital, **kw)


def test_risk_per_trade_never_exceeds_cap():
    p = plan()
    assert p.risk_usdt <= 500 * config.RISK_PER_TRADE_PCT + 1e-6


def test_allocation_cap_respected():
    p = plan(atr=0.2)       # tiny stop would imply a huge size; the cap must bind
    assert p.position_size_usdt <= 500 * config.MAX_ALLOCATION_PER_ASSET_PCT + 0.011


def test_capped_position_is_not_rejected_by_rounding():
    """Regression: a position sized exactly at the allocation cap used to be rejected by half a cent."""
    for capital in (499.31, 487.77, 463.19, 512.04):
        p = plan(capital=capital, atr=0.2)
        ok, why = check_pre_trade_gates(p, 0, 0.0, capital, CircuitBreaker(capital))
        assert ok, (capital, why)


def test_size_multiplier_scales_down_never_up():
    full, half, over = plan(), plan(size_multiplier=0.5), plan(size_multiplier=3.0)
    assert abs(half.position_size_usdt - full.position_size_usdt / 2) < 0.02
    assert over.position_size_usdt <= full.position_size_usdt + 1e-9


def test_circuit_breaker_trips_and_blocks():
    cb = CircuitBreaker(500.0)
    cb.record_trade_result(-config.DAILY_LOSS_CIRCUIT_BREAKER_PCT * 500 - 0.01)
    assert cb.tripped
    ok, why = check_pre_trade_gates(plan(), 0, 0.0, 500.0, cb)
    assert not ok and "circuit_breaker" in why
    cb.reset_for_new_day(500.0)
    assert check_pre_trade_gates(plan(), 0, 0.0, 500.0, cb)[0]


def test_max_concurrent_positions_enforced():
    ok, why = check_pre_trade_gates(plan(), config.MAX_CONCURRENT_POSITIONS, 0.0, 500.0, CircuitBreaker(500.0))
    assert not ok and "max_concurrent" in why


def test_low_score_and_tiny_order_rejected():
    assert not check_pre_trade_gates(plan(score=config.MIN_SCORE_TO_TRADE - 1), 0, 0.0, 500.0, CircuitBreaker(500.0))[0]
    assert not check_pre_trade_gates(plan(capital=20.0), 0, 0.0, 20.0, CircuitBreaker(20.0))[0]


def test_edge_gate_rejection_blocks_trade():
    rejected = Decision("BTC/USDT", "t", "NO TRADE", False, "calibrated", "insufficient_edge", 80.0)
    ok, why = check_pre_trade_gates(plan(), 0, 0.0, 500.0, CircuitBreaker(500.0), decision=rejected)
    assert not ok and why.startswith("edge_gate")


def test_trailing_stop_only_moves_up():
    entry, init = 100.0, 98.0
    stop = init
    prev = stop
    for price in [101, 102, 104, 103, 99, 106, 100]:
        stop = update_trailing_stop(entry, init, price, stop)
        assert stop >= prev
        prev = stop
    assert stop >= entry          # once well in profit the stop sits at least at breakeven
