// Quantis Dashboard — talks to the real Flask backend (server.py), which is
// wired to the real trading engine (signals.py, risk.py, capital.py,
// backtester.py, demo_engine.py). No numbers on this page are hardcoded.

// API_BASE is "" for same-origin deployment (VPS serving both frontend and
// API). When this file is deployed separately on Vercel, static/config.js
// (loaded before this file) sets window.QUANTIS_API_BASE to your VPS's
// public API URL, and every fetch() below is prefixed with it.
const API_BASE = (typeof window !== "undefined" && window.QUANTIS_API_BASE) || "";
const apiUrl = (path) => API_BASE + path;

const $ = (sel) => document.querySelector(sel);
const $all = (sel) => document.querySelectorAll(sel);

function fmtUsd(n) {
  if (n === null || n === undefined) return "—";
  return "$" + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtPct(n) {
  if (n === null || n === undefined) return "—";
  return Number(n).toFixed(2) + "%";
}
function pnlClass(v) { return v >= 0 ? "pnl-pos" : "pnl-neg"; }
function scoreClass(v) { return v >= 70 ? "score-high" : v >= 50 ? "score-mid" : "score-low"; }

// ── TAB SWITCHING ──────────────────────────────────────────
$all(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    $all(".tab-btn").forEach(b => b.classList.remove("active"));
    $all(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $("#tab-" + btn.dataset.tab).classList.add("active");
    if (btn.dataset.tab === "reports") loadReportsList();
  });
});

// ── EQUITY CHART ───────────────────────────────────────────
let equityChart = null;
function initEquityChart() {
  const ctx = $("#equity-chart").getContext("2d");
  equityChart = new Chart(ctx, {
    type: "line",
    data: { labels: [], datasets: [{
      data: [], borderColor: "#F0B90B", backgroundColor: "rgba(240,185,11,0.08)",
      borderWidth: 2, pointRadius: 0, fill: true, tension: 0.25,
    }]},
    options: {
      responsive: true, animation: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { display: false },
        y: { grid: { color: "#2B3139" }, ticks: { color: "#848E9C", font: { family: "JetBrains Mono", size: 11 } } },
      },
    },
  });
}

// ── STATE POLLING ──────────────────────────────────────────
let engineRunning = false;

async function pollState() {
  try {
    const res = await fetch(apiUrl("/api/state"));
    if (!res.ok) throw new Error("state fetch failed: " + res.status);
    const s = await res.json();
    renderState(s);
  } catch (e) {
    $("#engine-status-text").textContent = "connection error";
    $("#engine-status").className = "status-dot off";
    console.error(e);
  }
}

function renderState(s) {
  engineRunning = s.running;
  $("#engine-status").className = "status-dot " + (s.running ? "on" : "off");
  $("#engine-status-text").textContent = s.running ? `live (tick ${s.tick})` : "stopped";
  $("#engine-toggle").textContent = s.running ? "Stop" : "Start";

  $("#stat-trading-capital").textContent = fmtUsd(s.capital.trading_capital);
  $("#stat-profit-vault").textContent = fmtUsd(s.capital.profit_vault);
  $("#stat-total-equity").textContent = fmtUsd(s.capital.total_equity);
  $("#stat-breadth").textContent = fmtPct(s.market_breadth) + (s.regime_ok ? "" : " ⚠");
  $("#stat-breadth").className = "card-value " + (s.regime_ok ? "" : "neg");
  $("#stat-breaker").textContent = s.circuit_breaker_tripped ? "TRIPPED" : "Normal";
  $("#stat-breaker").className = "card-value " + (s.circuit_breaker_tripped ? "neg" : "pos");

  // equity chart
  if (equityChart && s.equity_curve && s.equity_curve.length) {
    equityChart.data.labels = s.equity_curve.map(p => p.t);
    equityChart.data.datasets[0].data = s.equity_curve.map(p => p.equity);
    equityChart.update("none");
  }

  // open positions
  const posBody = $("#positions-table tbody");
  if (s.open_positions && s.open_positions.length) {
    posBody.innerHTML = s.open_positions.map(p => `
      <tr>
        <td>${p.symbol}</td>
        <td>${Number(p.entry_price).toFixed(4)}</td>
        <td>${Number(p.stop).toFixed(4)}</td>
        <td>${Number(p.tp).toFixed(4)}</td>
        <td>${fmtUsd(p.size_usdt)}</td>
        <td class="${scoreClass(p.score)}">${p.score}</td>
      </tr>`).join("");
  } else {
    posBody.innerHTML = `<tr><td colspan="6" class="empty">No open positions</td></tr>`;
  }

  // recent trades (dashboard + trades tab)
  const tradeRows = (s.recent_trades || []).map(t => `
    <tr>
      <td>${t.closed_at ? t.closed_at.split("T")[1] || t.closed_at : ""}</td>
      <td>${t.symbol}</td>
      <td>${Number(t.entry_price).toFixed(4)}</td>
      <td>${Number(t.exit_price).toFixed(4)}</td>
      <td>${t.exit_reason}</td>
      <td class="${scoreClass(t.signal_score)}">${t.signal_score}</td>
      <td class="${pnlClass(t.pnl_usdt)}">${t.pnl_usdt >= 0 ? "+" : ""}${fmtUsd(t.pnl_usdt)}</td>
    </tr>`).join("");
  $("#recent-trades-table tbody").innerHTML = tradeRows || `<tr><td colspan="7" class="empty">No trades yet</td></tr>`;

  const allTradeRows = (s.recent_trades || []).map(t => `
    <tr>
      <td>${t.closed_at || ""}</td>
      <td>${t.symbol}</td>
      <td>${Number(t.entry_price).toFixed(4)}</td>
      <td>${Number(t.exit_price).toFixed(4)}</td>
      <td>${fmtUsd(t.position_size_usdt)}</td>
      <td>${t.exit_reason}</td>
      <td class="${scoreClass(t.signal_score)}">${t.signal_score}</td>
      <td class="${pnlClass(t.pnl_usdt)}">${t.pnl_usdt >= 0 ? "+" : ""}${fmtUsd(t.pnl_usdt)}</td>
    </tr>`).join("");
  $("#all-trades-table tbody").innerHTML = allTradeRows || `<tr><td colspan="8" class="empty">No trades yet</td></tr>`;

  // markets scan table
  const regimeBadge = (regime) => {
    if (regime === "trending") return '<span class="regime-badge regime-trending">trending</span>';
    if (regime === "choppy") return '<span class="regime-badge regime-choppy">choppy</span>';
    return '<span class="regime-badge regime-neutral">neutral</span>';
  };
  const strategyLabel = (strat) => {
    if (strat === "trend_following") return "Trend-following";
    if (strat === "mean_reversion") return "Mean-reversion";
    if (strat === "trend_following_low_confidence") return "Trend (low conf.)";
    return strat || "—";
  };
  const scanRows = (s.scan || []).map(r => `
    <tr>
      <td>${r.symbol}</td>
      <td>${r.close ? Number(r.close).toFixed(4) : "—"}</td>
      <td class="${scoreClass(r.score)}">${r.score}</td>
      <td>${regimeBadge(r.regime)}</td>
      <td style="font-size:11px;">${strategyLabel(r.strategy)}</td>
      <td>${r.trend ?? "—"}</td>
      <td>${r.momentum ?? "—"}</td>
      <td>${r.volatility ?? "—"}</td>
      <td>${r.rsi ?? "—"}</td>
      <td>${r.volume_ratio != null ? (r.volume_penalized ? `<span class="pnl-neg">${r.volume_ratio}x thin</span>` : r.volume_ratio + "x") : "—"}</td>
      <td>${r.is_uptrend ? '<span class="pnl-pos">▲ up</span>' : '<span class="pnl-neg">▼ down</span>'}</td>
    </tr>`).join("");
  $("#markets-table tbody").innerHTML = scanRows || `<tr><td colspan="11" class="empty">Loading…</td></tr>`;

  if (s.market_breadth != null) {
    $("#markets-breadth").textContent = fmtPct(s.market_breadth) + (s.regime_ok ? " (healthy)" : " (weak — new longs paused)");
  }
}

$("#engine-toggle").addEventListener("click", async () => {
  const endpoint = engineRunning ? "/api/engine/stop" : "/api/engine/start";
  await fetch(apiUrl(endpoint), { method: "POST" });
  pollState();
});

// ── BACKTEST ───────────────────────────────────────────────
let btChart = null;

$("#bt-run").addEventListener("click", async () => {
  const btn = $("#bt-run");
  btn.disabled = true;
  btn.textContent = "Running…";

  const payload = {
    symbols: $("#bt-symbols").value.split(",").map(s => s.trim()).filter(Boolean),
    n_bars: parseInt($("#bt-bars").value, 10),
    starting_capital: parseFloat($("#bt-capital").value),
    seed: parseInt($("#bt-seed").value, 10),
  };

  try {
    const res = await fetch(apiUrl("/api/backtest"), {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    const r = await res.json();
    renderBacktestResults(r);
  } catch (e) {
    console.error(e);
    alert("Backtest failed — check the server console.");
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Backtest";
  }
});

function renderBacktestResults(r) {
  $("#bt-note").textContent = r.note || "";
  $("#bt-results-cards").style.display = "grid";
  $("#bt-chart-panel").style.display = "block";
  $("#bt-trades-panel").style.display = "block";

  $("#bt-return").textContent = fmtPct(r.total_return_pct);
  $("#bt-return").className = "card-value " + (r.total_return_pct >= 0 ? "pos" : "neg");
  $("#bt-trades").textContent = r.total_trades ?? 0;
  $("#bt-winrate").textContent = fmtPct(r.win_rate_pct);
  $("#bt-maxdd").textContent = fmtPct(r.max_drawdown_pct);
  $("#bt-maxdd").className = "card-value neg";

  const ctx = $("#bt-equity-chart").getContext("2d");
  if (btChart) btChart.destroy();
  btChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: (r.equity_curve || []).map(p => p.t),
      datasets: [{
        data: (r.equity_curve || []).map(p => p.equity),
        borderColor: "#0ECB81", backgroundColor: "rgba(14,203,129,0.08)",
        borderWidth: 2, pointRadius: 0, fill: true, tension: 0.2,
      }],
    },
    options: {
      responsive: true, animation: false,
      plugins: { legend: { display: false } },
      scales: { x: { display: false }, y: { grid: { color: "#2B3139" }, ticks: { color: "#848E9C" } } },
    },
  });

  const rows = (r.trades || []).map(t => `
    <tr>
      <td>${t.symbol}</td>
      <td>${Number(t.entry_price).toFixed(4)}</td>
      <td>${Number(t.exit_price).toFixed(4)}</td>
      <td>${t.exit_reason}</td>
      <td class="${scoreClass(t.signal_score)}">${t.signal_score}</td>
      <td class="${pnlClass(t.pnl_usdt)}">${t.pnl_usdt >= 0 ? "+" : ""}${fmtUsd(t.pnl_usdt)}</td>
    </tr>`).join("");
  $("#bt-trades-table tbody").innerHTML = rows || `<tr><td colspan="6" class="empty">No trades in this run</td></tr>`;
}

// ── REPORTS ────────────────────────────────────────────────
async function loadReportsList() {
  const res = await fetch(apiUrl("/api/reports"));
  const files = await res.json();
  const list = $("#reports-list");
  if (!files.length) {
    list.innerHTML = `<li class="empty">No reports yet — reports are generated at end of each trading day.</li>`;
    return;
  }
  list.innerHTML = files.map(f => `<li data-file="${f}">${f}</li>`).join("");
  $all("#reports-list li").forEach(li => {
    li.addEventListener("click", async () => {
      $all("#reports-list li").forEach(x => x.classList.remove("selected"));
      li.classList.add("selected");
      const res = await fetch(apiUrl("/api/reports/") + li.dataset.file);
      const text = await res.text();
      $("#report-preview").textContent = text;
    });
  });
}

// ── SETTINGS ───────────────────────────────────────────────
async function loadSettings() {
  const res = await fetch(apiUrl("/api/config"));
  const cfg = await res.json();
  const labels = {
    symbols: "Symbols", timeframe: "Timeframe", risk_per_trade_pct: "Risk per Trade",
    max_concurrent_positions: "Max Concurrent Positions", daily_loss_circuit_breaker_pct: "Daily Loss Circuit Breaker",
    max_allocation_per_asset_pct: "Max Allocation per Asset", reward_risk_ratio: "Reward:Risk Ratio",
    min_score_to_trade: "Min Signal Score to Trade", trail_activation_r: "Trailing Stop Activation (R)",
    trail_distance_r: "Trailing Stop Distance (R)", use_regime_filter: "Market Regime Filter",
    market_breadth_min: "Min Market Breadth", use_testnet: "Testnet Mode", starting_capital: "Starting Capital",
  };
  const rows = Object.entries(cfg).map(([k, v]) => `
    <tr><td style="color:#848E9C">${labels[k] || k}</td><td>${Array.isArray(v) ? v.join(", ") : String(v)}</td></tr>
  `).join("");
  $("#settings-table tbody").innerHTML = rows;
}

// ── INIT ───────────────────────────────────────────────────
initEquityChart();
pollState();
loadSettings();
setInterval(pollState, 3000);

// ══════════════════════════════════════════════════════════
// ANIMATIONS: toasts + flash-on-new-trade
// ══════════════════════════════════════════════════════════
let seenTradeKeys = new Set();

function showToast(title, body, kind) {
  const el = document.createElement("div");
  el.className = "toast " + (kind || "");
  el.innerHTML = `<div class="toast-title">${title}</div><div>${body}</div>`;
  $("#toast-container").appendChild(el);
  setTimeout(() => el.remove(), 5100);
}

function checkForNewTradesAndToast(trades) {
  (trades || []).forEach(t => {
    const key = `${t.symbol}-${t.closed_at}-${t.pnl_usdt}`;
    if (seenTradeKeys.has(key)) return;
    seenTradeKeys.add(key);
    if (seenTradeKeys.size > 500) {
      // trim to avoid unbounded growth in a long-running tab
      seenTradeKeys = new Set(Array.from(seenTradeKeys).slice(-200));
    }
    const win = t.pnl_usdt >= 0;
    showToast(
      win ? `✅ ${t.symbol} closed in profit` : `🔴 ${t.symbol} closed at a loss`,
      `${t.exit_reason} · ${win ? "+" : ""}${fmtUsd(t.pnl_usdt)}`,
      win ? "win" : "loss"
    );
  });
}

// Wrap the existing renderState to also drive toasts (first call establishes
// baseline so we don't toast every historical trade on page load)
const _origRenderState = renderState;
let _firstStateRender = true;
renderState = function (s) {
  _origRenderState(s);
  if (_firstStateRender) {
    (s.recent_trades || []).forEach(t => seenTradeKeys.add(`${t.symbol}-${t.closed_at}-${t.pnl_usdt}`));
    _firstStateRender = false;
  } else {
    checkForNewTradesAndToast(s.recent_trades);
  }
};

// ══════════════════════════════════════════════════════════
// ANALYTICS TAB
// ══════════════════════════════════════════════════════════
let anEquityChart = null, anRChart = null;

async function loadAnalytics() {
  const res = await fetch(apiUrl("/api/analytics"));
  const data = await res.json();
  const s = data.summary || {};

  if (!s.trades) {
    $("#an-netpnl").textContent = "—";
    $("#an-winrate").textContent = "—";
    $("#an-pf").textContent = "—";
    $("#an-maxdd").textContent = "—";
    $("#an-sharpe").textContent = "—";
    $("#an-symbol-table tbody").innerHTML = `<tr><td colspan="4" class="empty">No trades recorded yet — analytics fill in as the bot trades.</td></tr>`;
  } else {
    $("#an-netpnl").textContent = (s.net_pnl_usdt >= 0 ? "+" : "") + fmtUsd(s.net_pnl_usdt);
    $("#an-netpnl").className = "card-value " + (s.net_pnl_usdt >= 0 ? "pos" : "neg");
    $("#an-winrate").textContent = fmtPct(s.win_rate_pct);
    $("#an-pf").textContent = s.profit_factor ?? "—";
    $("#an-maxdd").textContent = fmtPct(s.max_drawdown_pct);
    $("#an-maxdd").className = "card-value neg";
    $("#an-sharpe").textContent = s.sharpe_like ?? "n/a (needs more days)";

    $("#an-symbol-table tbody").innerHTML = (s.per_symbol || []).map(r => `
      <tr>
        <td>${r.symbol}</td>
        <td>${r.trades}</td>
        <td>${fmtPct(r.win_rate)}</td>
        <td class="${pnlClass(r.net_pnl)}">${r.net_pnl >= 0 ? "+" : ""}${fmtUsd(r.net_pnl)}</td>
      </tr>`).join("") || `<tr><td colspan="4" class="empty">No trades yet</td></tr>`;

    const stratLabel = (k) => ({
      trend_following: "Trend-following", mean_reversion: "Mean-reversion",
      trend_following_low_confidence: "Trend (low conf.)",
    }[k] || k);
    $("#an-strategy-table tbody").innerHTML = (s.per_strategy || []).map(r => `
      <tr>
        <td>${stratLabel(r.strategy)}</td>
        <td>${r.trades}</td>
        <td>${fmtPct(r.win_rate)}</td>
        <td class="${pnlClass(r.net_pnl)}">${r.net_pnl >= 0 ? "+" : ""}${fmtUsd(r.net_pnl)}</td>
      </tr>`).join("") || `<tr><td colspan="4" class="empty">Not enough data yet to break down by strategy</td></tr>`;
  }

  // buy-and-hold benchmark comparison (the honesty check)
  const bm = data.benchmark || {};
  if (bm.available) {
    $("#an-benchmark-symbol-label").textContent = "(" + bm.symbol + ")";
    $("#an-bot-return").textContent = (bm.bot_pct >= 0 ? "+" : "") + fmtPct(bm.bot_pct);
    $("#an-bot-return").className = "card-value " + (bm.bot_pct >= 0 ? "pos" : "neg");
    $("#an-bh-return").textContent = (bm.buy_and_hold_pct >= 0 ? "+" : "") + fmtPct(bm.buy_and_hold_pct);
    $("#an-bh-return").className = "card-value " + (bm.buy_and_hold_pct >= 0 ? "pos" : "neg");
    $("#an-benchmark-verdict").innerHTML = bm.bot_beating_buy_and_hold
      ? `<span style="color:var(--green)">The bot is currently ahead of just holding ${bm.symbol} over this period.</span>`
      : `<span style="color:var(--yellow)">Just holding ${bm.symbol} would currently have done better than the bot over this period — worth knowing, not hiding.</span>`;
  } else {
    $("#an-benchmark-symbol-label").textContent = "";
    $("#an-bot-return").textContent = "—";
    $("#an-bh-return").textContent = "—";
    $("#an-benchmark-verdict").textContent = "Benchmark comparison starts once the engine has run for at least one tick.";
  }

  // rolling win rate chart
  const rw = data.rolling_win_rate || [];
  const ctxR = $("#an-rollingwr-chart").getContext("2d");
  if (window._anRollingWrChart) window._anRollingWrChart.destroy();
  window._anRollingWrChart = new Chart(ctxR, {
    type: "line",
    data: { labels: rw.map(p => p.t), datasets: [{
      data: rw.map(p => p.win_rate),
      borderColor: "#7FE8B8", backgroundColor: "rgba(127,232,184,0.08)",
      borderWidth: 2, pointRadius: 0, fill: true, tension: 0.25,
    }]},
    options: { responsive: true, animation: false, plugins: { legend: { display: false } },
      scales: { x: { display: false }, y: { min: 0, max: 100, grid: { color: "#2B3139" }, ticks: { color: "#848E9C", callback: v => v + "%" } } } },
  });

  // equity chart
  const ctx1 = $("#an-equity-chart").getContext("2d");
  if (anEquityChart) anEquityChart.destroy();
  anEquityChart = new Chart(ctx1, {
    type: "line",
    data: { labels: (data.equity_series || []).map(p => p.t), datasets: [{
      data: (data.equity_series || []).map(p => p.equity),
      borderColor: "#F0B90B", backgroundColor: "rgba(240,185,11,0.08)",
      borderWidth: 2, pointRadius: 0, fill: true, tension: 0.2,
    }]},
    options: { responsive: true, animation: false, plugins: { legend: { display: false } },
      scales: { x: { display: false }, y: { grid: { color: "#2B3139" }, ticks: { color: "#848E9C" } } } },
  });

  // R-multiple distribution chart
  const rd = data.r_multiple_distribution || { labels: [], buckets: [] };
  const ctx2 = $("#an-rmultiple-chart").getContext("2d");
  if (anRChart) anRChart.destroy();
  anRChart = new Chart(ctx2, {
    type: "bar",
    data: { labels: rd.labels, datasets: [{
      data: rd.buckets,
      backgroundColor: rd.labels.map(l => l.includes("-") ? "#F6465D" : "#0ECB81"),
    }]},
    options: { responsive: true, animation: false, plugins: { legend: { display: false } },
      scales: { x: { ticks: { color: "#848E9C", font: { size: 10 } } }, y: { grid: { color: "#2B3139" }, ticks: { color: "#848E9C" } } } },
  });

  // learner status
  const lrn = data.learner || {};
  const box = $("#learner-status-box");
  if (!lrn.sklearn_available) {
    box.innerHTML = `<span class="lb-warn">scikit-learn not installed on the server — adaptive learning is inactive.</span>`;
  } else if (!lrn.model_ready) {
    box.innerHTML = `
      Samples recorded: ${lrn.samples_recorded}<br>
      Needed to train: ${lrn.min_samples_to_train} · Needed to act on: ${lrn.min_samples_to_act}<br>
      <span class="lb-warn">Not yet influencing trade decisions — needs more closed trades first.</span>`;
  } else {
    const m = lrn.last_train_metrics || {};
    box.innerHTML = `
      Samples: ${lrn.samples_recorded} · Trained: ${m.trained_at || "—"}<br>
      Out-of-sample accuracy: ${m.test_accuracy ?? "—"} (baseline: ${m.baseline_accuracy ?? "—"})<br>
      <span class="${m.beats_baseline ? 'lb-good' : 'lb-warn'}">${m.beats_baseline ? "Beats baseline — currently influencing trade scores." : "Not beating baseline yet — blend weight is low by design."}</span>`;
  }
}

// ══════════════════════════════════════════════════════════
// LIVE MODE PANEL
// ══════════════════════════════════════════════════════════
async function loadLiveGate() {
  const res = await fetch(apiUrl("/api/live_gate/status"));
  const g = await res.json();

  const labels = {
    days_running: "Paper trading days running",
    trade_count: "Closed trades recorded",
    win_rate_pct: "Win rate",
    max_drawdown_pct: "Max drawdown",
  };
  const rows = Object.entries(g.checks || {}).map(([k, c]) => `
    <tr>
      <td>${labels[k] || k}</td>
      <td>${c.value}${k.includes("pct") ? "%" : ""}</td>
      <td>${k === "max_drawdown_pct" ? "≤" : "≥"} ${c.required}${k.includes("pct") ? "%" : ""}</td>
      <td class="${c.passed ? 'check-pass' : 'check-fail'}">${c.passed ? "✓ PASS" : "✗ FAIL"}</td>
    </tr>`).join("");

  $("#live-gate-checks").innerHTML = `
    <table>
      <thead><tr><th>Check</th><th>Current</th><th>Required</th><th>Status</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  $("#live-gate-note").textContent = g.note || "";

  const enablePanel = $("#live-gate-enable-panel");
  if (!g.ready) {
    enablePanel.style.opacity = "0.5";
    enablePanel.querySelector("#live-enable-btn").disabled = true;
  } else {
    enablePanel.style.opacity = "1";
    enablePanel.querySelector("#live-enable-btn").disabled = false;
  }

  if (g.live_currently_enabled) {
    $("#live-gate-result").innerHTML = `<span class="lb-good" style="color:var(--green)">Live gate is currently ENABLED.</span> You still need USE_TESTNET=False and real API keys, plus the confirmation prompt in live_engine.py, for real orders to actually be placed.`;
  }
}

$("#live-enable-btn")?.addEventListener("click", async () => {
  const phrase = $("#live-confirm-input").value;
  const res = await fetch(apiUrl("/api/live_gate/enable"), {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ confirmation_phrase: phrase }),
  });
  const r = await res.json();
  $("#live-gate-result").textContent = r.message || r.reason || JSON.stringify(r);
  loadLiveGate();
});

$("#live-disable-btn")?.addEventListener("click", async () => {
  await fetch(apiUrl("/api/live_gate/disable"), { method: "POST" });
  loadLiveGate();
});

// ══════════════════════════════════════════════════════════
// NOTIFICATIONS TEST (Settings tab)
// ══════════════════════════════════════════════════════════
async function loadNotifStatus() {
  const res = await fetch(apiUrl("/api/config"));
  const cfg = await res.json();
  $("#notif-status").innerHTML = `
    <span class="notif-chip ${cfg.telegram_enabled ? 'on' : 'off'}">Telegram: ${cfg.telegram_enabled ? 'ON' : 'OFF'}</span>
    <span class="notif-chip ${cfg.whatsapp_enabled ? 'on' : 'off'}">WhatsApp: ${cfg.whatsapp_enabled ? 'ON' : 'OFF'}</span>`;
}

$("#notif-test-btn")?.addEventListener("click", async () => {
  const btn = $("#notif-test-btn");
  btn.textContent = "Sending…";
  const res = await fetch(apiUrl("/api/notify_test"), { method: "POST" });
  const r = await res.json();
  btn.textContent = "Send Test Notification";
  showToast("Notification test", JSON.stringify(r), "win");
});

// ── Hook new tabs into the existing tab-switch logic ──────
$all(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    if (btn.dataset.tab === "analytics") loadAnalytics();
    if (btn.dataset.tab === "livemode") loadLiveGate();
    if (btn.dataset.tab === "settings") loadNotifStatus();
  });
});


// ══════════════════════════════════════════════════════════
// DATA-SOURCE BANNER, EDGE STATUS, DECISIONS TABLE
// ══════════════════════════════════════════════════════════
function renderEdgeAndDecisions(s) {
  const banner = $("#data-banner");
  const issues = s.data_issues || {};
  const bad = Object.keys(issues).length;
  if (s.data_source === "SIMULATED_FEED" || bad) {
    let msg = "";
    if (s.data_source === "SIMULATED_FEED") {
      msg += "SIMULATED MARKET DATA — prices on this view are generated, not real. Nothing here is evidence of profitability. ";
    }
    if (bad) msg += "DATA QUALITY: new decisions suspended for " + Object.keys(issues).join(", ") + ".";
    banner.textContent = msg;
    banner.style.display = "block";
    banner.className = "data-banner" + (bad ? " bad" : "");
  } else {
    banner.style.display = "none";
  }

  const e = s.edge;
  if (e) {
    $("#edge-status").textContent = e.mode === "exploration"
      ? `Edge gate: exploration — ${e.observations}/${e.required} closed trades needed before it enforces net-edge`
      : `Edge gate: calibrated on ${e.observations} closed trades`;
  }

  const rows = (s.recent_decisions || []).map(d => `
    <tr>
      <td>${(d.timestamp || "").split("T")[1] || d.timestamp}</td>
      <td>${d.symbol}</td>
      <td class="${d.approved ? "pnl-pos" : "pnl-neg"}">${d.signal}</td>
      <td>${d.mode}</td>
      <td>${d.expected_return_r != null ? (d.expected_return_r >= 0 ? "+" : "") + d.expected_return_r.toFixed(3) : "—"}</td>
      <td>${d.uncertainty_r != null ? d.uncertainty_r.toFixed(3) : "—"}</td>
      <td>${d.expected_cost_r != null ? d.expected_cost_r.toFixed(2) : "—"}</td>
      <td style="font-size:11px; white-space:normal;">${d.reason}</td>
    </tr>`).join("");
  $("#decisions-table tbody").innerHTML = rows || `<tr><td colspan="8" class="empty">No candidate setups evaluated yet</td></tr>`;
}
const _origRenderState3 = renderState;
renderState = function (s) { _origRenderState3(s); renderEdgeAndDecisions(s); };

// richer backtest metrics
const _origRenderBt = renderBacktestResults;
renderBacktestResults = function (r) {
  _origRenderBt(r);
  const f = (v, suf = "") => (v === null || v === undefined) ? "n/a" : v + suf;
  const rej = r.rejections ? Object.entries(r.rejections).map(([k, v]) => `${k}: ${v}`).join(" · ") : "none";
  const el = $("#bt-extra");
  el.style.display = "block";
  el.innerHTML = `<b>${r.label || ""}</b><br>
    Sharpe ${f(r.sharpe_ratio)} · Sortino ${f(r.sortino_ratio)} · Profit factor ${f(r.profit_factor)} ·
    EV/trade ${f(r.ev_per_trade_r, "R")} · Costs paid $${f(r.total_costs_usdt)} · Turnover ${f(r.turnover_x_capital, "x")} ·
    Avg exposure ${f(r.avg_exposure_pct, "%")} · Buy&hold (same period) ${f(r.benchmark_buy_hold_pct, "%")}<br>
    Setups rejected: ${rej}`;
};
