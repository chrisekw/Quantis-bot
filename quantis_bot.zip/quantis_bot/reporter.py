"""
Daily Reporting System — Section 09 of the plan.
Generates a markdown report covering everything from the day's trades,
signal scans, risk metrics, and capital movement.
"""
import os
from datetime import datetime, date
import pandas as pd

import config


def generate_report(
    report_date: date,
    trades_today: list,          # list of dicts: symbol, entry_price, exit_price, pnl_usdt, score, exit_reason
    scanned_symbols: list,       # list of dicts from signals.scan_universe (as records)
    capital_summary: dict,
    circuit_breaker_tripped: bool,
    cumulative_stats: dict = None,
    ai_commentary: str = "",
    out_dir: str = None,
) -> str:
    out_dir = out_dir or config.REPORTS_DIR
    os.makedirs(out_dir, exist_ok=True)

    lines = []
    lines.append(f"# Quantis Daily Report — {report_date.isoformat()}")
    lines.append("")
    lines.append("## Summary")
    total_trades = len(trades_today)
    wins = [t for t in trades_today if t["pnl_usdt"] > 0]
    losses = [t for t in trades_today if t["pnl_usdt"] <= 0]
    net_pnl = sum(t["pnl_usdt"] for t in trades_today)
    lines.append(f"- Trades taken: **{total_trades}** ({len(wins)} win / {len(losses)} loss)")
    lines.append(f"- Net P&L today: **{net_pnl:+.2f} USDT**")
    lines.append(f"- Trading Capital: **{capital_summary['trading_capital']:.2f} USDT**")
    lines.append(f"- Profit Vault: **{capital_summary['profit_vault']:.2f} USDT**")
    lines.append(f"- Total Equity: **{capital_summary['total_equity']:.2f} USDT**")
    lines.append(f"- Daily circuit breaker tripped: **{'YES' if circuit_breaker_tripped else 'No'}**")
    lines.append("")

    lines.append("## Trade-by-Trade Log")
    if trades_today:
        lines.append("| Symbol | Entry | Exit | Size (USDT) | Score | Result | P&L |")
        lines.append("|---|---|---|---|---|---|---|")
        for t in trades_today:
            lines.append(
                f"| {t['symbol']} | {t['entry_price']:.4f} | {t['exit_price']:.4f} | "
                f"{t['position_size_usdt']:.2f} | {t['signal_score']:.1f} | {t['exit_reason']} | "
                f"{t['pnl_usdt']:+.2f} |"
            )
    else:
        lines.append("_No trades executed today._")
    lines.append("")

    lines.append("## Signal Scan Summary")
    if scanned_symbols:
        lines.append("| Symbol | Score | Trend | Momentum | Volatility | Traded? |")
        lines.append("|---|---|---|---|---|---|")
        traded_symbols = {t["symbol"] for t in trades_today}
        for s in scanned_symbols:
            traded = "Yes" if s["symbol"] in traded_symbols else ("Skipped" if s["score"] < config.MIN_SCORE_TO_TRADE else "No (capacity/risk gate)")
            lines.append(
                f"| {s['symbol']} | {s['score']:.1f} | {s.get('trend','-')} | "
                f"{s.get('momentum','-')} | {s.get('volatility','-')} | {traded} |"
            )
    else:
        lines.append("_No scan data available._")
    lines.append("")

    if cumulative_stats:
        lines.append("## Cumulative Stats")
        for k, v in cumulative_stats.items():
            lines.append(f"- {k}: **{v}**")
        lines.append("")

    if ai_commentary:
        lines.append("## Market Commentary")
        lines.append(ai_commentary)
        lines.append("")

    lines.append("---")
    lines.append(f"_Generated {datetime.now().isoformat(timespec='seconds')} by Quantis Bot_")

    content = "\n".join(lines)
    filepath = os.path.join(out_dir, f"report_{report_date.isoformat()}.md")
    with open(filepath, "w") as f:
        f.write(content)

    return filepath
