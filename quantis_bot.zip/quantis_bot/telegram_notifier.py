"""
Telegram alerts. Fill in TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in
config.py (or set env vars) and set TELEGRAM_ENABLED = True to activate.

To create a bot: message @BotFather on Telegram, /newbot, copy the token.
To get your chat_id: message your new bot, then visit
https://api.telegram.org/bot<TOKEN>/getUpdates and read the chat id from the response.
"""
import os
import requests
import config


def send_telegram(message: str) -> bool:
    if not config.TELEGRAM_ENABLED:
        return False
    token = os.getenv("QUANTIS_TG_TOKEN", config.TELEGRAM_BOT_TOKEN)
    chat_id = os.getenv("QUANTIS_TG_CHAT_ID", config.TELEGRAM_CHAT_ID)
    if not token or not chat_id:
        return False
    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": message, "parse_mode": "Markdown"},
            timeout=10,
        )
        return resp.status_code == 200
    except Exception as e:
        print(f"[Quantis] Telegram alert failed: {e}")
        return False
