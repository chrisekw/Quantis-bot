"""
Live Trading Engine — places REAL orders on a REAL exchange with REAL money.

This file will refuse to run unless ALL of the following are true:
  1. config.USE_TESTNET is False (you've explicitly decided to leave testnet)
  2. live_gate's readiness checks pass (paper-trading days/trades/win-rate/
     drawdown thresholds from config.py, computed from YOUR actual paper
     trading history)
  3. The live gate has been explicitly enabled via the dashboard or
     live_gate.attempt_enable_live() with the typed confirmation phrase
  4. You type the confirmation phrase AGAIN, right here, at process start

That's intentionally four separate gates. Every one of them exists because
"switch from demo to live" should never be a single accidental step.

This does not guarantee profitability. Nothing can. It only guarantees you
can't back into live trading by accident.
"""
import sys
import time
from datetime import datetime, date

import config
from exchange import ExchangeClient
from signals import add_indicators, score_asset, generate_signal, market_breadth
from correlation import compute_correlation_matrix
from edge import DecisionMaker
from trading_mode import get_trading_mode, TradingModeError
from risk import build_trade_plan, CircuitBreaker, check_pre_trade_gates, update_trailing_stop, passes_regime_filter, blend_ml_score
from capital import CapitalManager
from learner import TradeLearner
from notifier import notify_trade_opened, notify_trade_closed, notify_circuit_breaker, notify
from reporter import generate_report
import live_gate


def _run_startup_gates():
    print("=" * 70)
    print("QUANTIS LIVE TRADING ENGINE — REAL MONEY, REAL ORDERS")
    print("=" * 70)

    try:
        mode = get_trading_mode()
    except TradingModeError as e:
        print(f"\n[BLOCKED] {e}")
        sys.exit(1)
    if mode != "live":
        print("\n[BLOCKED] TRADING_MODE is not 'live' (default is 'paper'). Real orders are disabled.")
        print("Set TRADING_MODE=live explicitly only after every other gate below is satisfied.")
        sys.exit(1)

    if config.USE_TESTNET:
        print("\n[BLOCKED] config.USE_TESTNET is still True. Live engine will not run.")
        print("This is correct behavior — set USE_TESTNET = False only when you mean it.")
        sys.exit(1)

    readiness = live_gate.check_readiness(config.LEDGER_DB_PATH)
    if not readiness["ready"]:
        print("\n[BLOCKED] Live trading readiness checks are not met:")
        for name, check in readiness["checks"].items():
            status = "PASS" if check["passed"] else "FAIL"
            comparator = "<=" if "drawdown" in name else ">="
            print(f"  [{status}] {name}: {check['value']} (need {comparator} {check['required']})")
        print(f"\n{readiness['note']}")
        sys.exit(1)

    if not readiness["live_currently_enabled"]:
        print("\n[BLOCKED] Live gate has not been explicitly enabled yet.")
        print("Enable it first via the dashboard's Live Mode panel, or:")
        print("  python -c \"import live_gate; print(live_gate.attempt_enable_live(")
        print(f"      '{config.LEDGER_DB_PATH}', '{live_gate.REQUIRED_CONFIRMATION_PHRASE}'))\"")
        sys.exit(1)

    if not config.API_KEY and not __import__("os").getenv("QUANTIS_API_KEY"):
        print("\n[BLOCKED] No exchange API key configured (QUANTIS_API_KEY env var or config.API_KEY).")
        sys.exit(1)

    print("\nAll automated readiness checks PASSED. This does not mean the strategy")
    print("will be profitable — only that you've met the minimum track-record bar")
    print("this bot's own history requires before trading real money.")
    print("\nThis process is about to place REAL market orders with REAL funds on")
    print(f"exchange '{config.EXCHANGE_ID}' using the API key currently configured.")
    print(f"\nType exactly: {live_gate.REQUIRED_CONFIRMATION_PHRASE}")
    typed = input("> ").strip()
    if typed != live_gate.REQUIRED_CONFIRMATION_PHRASE:
        print("\n[ABORTED] Confirmation phrase did not match. Nothing was started.")
        sys.exit(1)

    print("\nConfirmed. Starting live engine in 5 seconds — Ctrl+C now to abort...")
    time.sleep(5)


class LiveEngine:
    def __init__(self):
        self.client = ExchangeClient(use_testnet=False)
        self.capital = CapitalManager()
        self.learner = TradeLearner(db_path=self.capital.db_path)
        self.decider = DecisionMaker(db_path=self.capital.db_path)
        self.trades_since_last_train = 0
        self.open_positions = {}
        self.trades_today = []
        self.current_day = date.today()
        self.circuit_breaker = CircuitBreaker(capital_at_day_start=self.capital.trading_capital)
        self._last_scan = []
        self._running = True

    def _maybe_roll_day(self):
        today = date.today()
        if today != self.current_day:
            path = generate_report(
                report_date=self.current_day, trades_today=self.trades_today,
                scanned_symbols=self._last_scan, capital_summary=self.capital.summary(),
                circuit_breaker_tripped=self.circuit_breaker.tripped,
            )
            notify(f"📋 Quantis LIVE daily report ready: {path}")
            self.current_day = today
            self.trades_today = []
            self.circuit_breaker.reset_for_new_day(self.capital.trading_capital)

    def run(self, poll_seconds: int = None):
        poll_seconds = poll_seconds or config.POLL_SECONDS_LIVE
        notify("🔴 Quantis LIVE trading engine started. Real orders will now be placed.")
        print(f"[LiveEngine] Starting capital snapshot: {self.capital.summary()}")

        while self._running:
            try:
                self._maybe_roll_day()
                price_data = self.client.fetch_universe()
                scored = []
                for symbol, df in price_data.items():
                    df = add_indicators(df)
                    result = generate_signal(df)   # regime-adaptive: matches backtester/demo logic
                    result["symbol"] = symbol
                    result["_df"] = df
                    scored.append(result)
                self._last_scan = [{k: v for k, v in r.items() if k != "_df"} for r in scored]
                breadth = market_breadth(__import__("pandas").DataFrame(self._last_scan)) if self._last_scan else 0.0
                scored.sort(key=lambda r: r["score"], reverse=True)

                # --- exits ---
                for symbol in list(self.open_positions.keys()):
                    match = next((r for r in scored if r["symbol"] == symbol), None)
                    if not match:
                        continue
                    last_price = match["close"]
                    pos = self.open_positions[symbol]
                    pos["stop"] = update_trailing_stop(
                        entry_price=pos["entry_price"], initial_stop=pos["initial_stop"],
                        current_price=last_price, current_stop=pos["stop"],
                    )
                    should_exit, reason = False, None
                    if last_price <= pos["stop"]:
                        should_exit, reason = True, ("trailing_stop" if pos["stop"] > pos["initial_stop"] else "stop_loss")
                    elif last_price >= pos["tp"]:
                        should_exit, reason = True, "take_profit"

                    if should_exit:
                        try:
                            fill = self.client.place_market_sell(symbol, pos["size_units"])
                            fill_price = float(fill.get("average") or fill.get("price") or last_price)
                        except Exception as e:
                            notify(f"⚠️ LIVE SELL FAILED for {symbol}: {e}. Position may still be open on the exchange — check manually.")
                            print(f"[LiveEngine] SELL FAILED {symbol}: {e}")
                            continue

                        pnl = (fill_price - pos["entry_price"]) * pos["size_units"]
                        self.decider.record_outcome(pos["score"], pnl / pos["risk_usdt"] if pos.get("risk_usdt") else 0.0)
                        self.capital.apply_trade_result(symbol, pnl, strategy=pos.get("strategy"), regime=pos.get("regime"))
                        self.circuit_breaker.record_trade_result(pnl)
                        if pos.get("feature_row_id") is not None:
                            self.learner.record_exit(pos["feature_row_id"], pnl_usdt=pnl, risk_usdt=pos.get("risk_usdt", 1.0))
                            self.trades_since_last_train += 1
                            if self.trades_since_last_train >= config.ML_RETRAIN_EVERY_N_TRADES:
                                self.learner.train()
                                self.trades_since_last_train = 0

                        self.trades_today.append({
                            "symbol": symbol, "entry_price": pos["entry_price"], "exit_price": fill_price,
                            "position_size_usdt": pos["size_usdt"], "signal_score": pos["score"],
                            "exit_reason": reason, "pnl_usdt": round(pnl, 2),
                        })
                        notify_trade_closed(symbol, reason, pnl)
                        if self.circuit_breaker.tripped:
                            notify_circuit_breaker()
                        del self.open_positions[symbol]

                # --- entries ---
                regime_ok = passes_regime_filter(breadth)
                price_data_snap = {r["symbol"]: r["_df"] for r in scored}
                corr_matrix = compute_correlation_matrix(price_data_snap) if config.USE_CORRELATION_GUARD else None
                if self.circuit_breaker.can_trade() and regime_ok and len(self.open_positions) < config.MAX_CONCURRENT_POSITIONS:
                    for result in scored:
                        if len(self.open_positions) >= config.MAX_CONCURRENT_POSITIONS:
                            break
                        symbol = result["symbol"]
                        if symbol in self.open_positions or result["score"] < config.MIN_SCORE_TO_TRADE:
                            continue

                        df = result["_df"]
                        atr = df.iloc[-1]["atr"]
                        entry_price = result["close"]
                        decision = self.decider.evaluate(symbol, result, entry_price, atr)
                        if not decision.approved:
                            continue

                        ml_features = {
                            "trend_score": result.get("trend"), "momentum_score": result.get("momentum"),
                            "volatility_score": result.get("volatility"), "rsi": result.get("rsi"),
                            "atr_pct": result.get("atr_pct"), "market_breadth": breadth,
                            "signal_score": result["score"],
                        }
                        ml_prob = self.learner.predict_win_probability(ml_features)
                        blended_score = blend_ml_score(result["score"], ml_prob)

                        plan = build_trade_plan(
                            symbol=symbol, entry_price=entry_price, atr=atr,
                            signal_score=blended_score, trading_capital=self.capital.trading_capital,
                            size_multiplier=decision.size_multiplier,
                        )
                        allowed, why = check_pre_trade_gates(
                            plan, len(self.open_positions), 0.0,
                            self.capital.trading_capital, self.circuit_breaker,
                            open_symbols=list(self.open_positions.keys()), corr_matrix=corr_matrix, decision=decision,
                        )
                        if not allowed:
                            continue

                        try:
                            fill = self.client.place_market_buy(symbol, plan.position_size_units)
                            fill_price = float(fill.get("average") or fill.get("price") or entry_price)
                            self.client.place_stop_loss(symbol, plan.position_size_units, plan.stop_loss_price)
                        except Exception as e:
                            notify(f"⚠️ LIVE BUY FAILED for {symbol}: {e}")
                            print(f"[LiveEngine] BUY FAILED {symbol}: {e}")
                            continue

                        feature_row_id = self.learner.record_entry(symbol, ml_features)

                        self.open_positions[symbol] = {
                            "entry_price": fill_price, "stop": plan.stop_loss_price,
                            "initial_stop": plan.stop_loss_price, "tp": plan.take_profit_price,
                            "size_units": plan.position_size_units, "size_usdt": plan.position_size_usdt,
                            "score": result["score"], "risk_usdt": plan.risk_usdt,
                            "feature_row_id": feature_row_id,
                            "strategy": result.get("strategy"), "regime": result.get("regime"),
                        }
                        notify_trade_opened(symbol, blended_score, plan.position_size_usdt)

            except Exception as e:
                # A live loop must never silently die -- alert, then keep running
                # (the exchange-side stop-loss orders remain live even if this
                # process crashes, which is exactly why we always place them
                # as real exchange orders and not just in-memory checks).
                notify(f"⚠️ Quantis LIVE engine hit an error: {e}")
                print(f"[LiveEngine] ERROR: {e}")

            time.sleep(poll_seconds)


if __name__ == "__main__":
    _run_startup_gates()
    engine = LiveEngine()
    engine.run()
