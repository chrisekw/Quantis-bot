"""
TRADING_MODE guard. Default is paper. Anything unrecognised or ambiguous is rejected,
never silently coerced to something else.

  paper -> simulated fills only (default)
  live  -> real orders; additionally requires config.USE_TESTNET=False, the live
           readiness gate, and a typed confirmation (see live_engine.py / live_gate.py)
"""
import os

VALID_MODES = ("paper", "live")


class TradingModeError(Exception):
    pass


def get_trading_mode() -> str:
    raw = os.getenv("TRADING_MODE")
    if raw is None or raw.strip() == "":
        return "paper"
    mode = raw.strip().lower()
    if raw != raw.strip() or mode not in VALID_MODES:
        raise TradingModeError(
            f"Unsupported TRADING_MODE={raw!r}. Allowed values: {', '.join(VALID_MODES)} (default: paper)."
        )
    return mode


def is_live_mode() -> bool:
    return get_trading_mode() == "live"
