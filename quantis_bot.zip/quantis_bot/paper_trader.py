"""
Paper Trading Loop -- Section 08 gate of the plan.

Runs against LIVE real-time market data (via ccxt + your exchange testnet
or a real exchange in read-only fashion) but simulates order fills locally
instead of sending real orders. This is the required 4-8 week step between
backtesting and ever touching real capital -- and it's what feeds the
live-trading readiness gate (live_gate.py): the trade count, win rate, and
drawdown thresholds there are computed from exactly the trades this loop
records.

Run this with: python paper_trader.py
Stop any time with Ctrl+C -- state is persisted to the SQLite ledger, so it
resumes correctly next run.

NOTE: requires real network access to your exchange -- will not run inside
a network-restricted sandbox. Run on your own machine.
"""
import time
import signal as sig
from datetime import datetime, date

import config
from exchange import ExchangeClient
from signals import add_indicators, score_asset, generate_signal, market_breadth
from correlation import compute_correlation_matrix
from edge import DecisionMaker, apply_costs
from data_quality import validate_ohlcv
from trading_mode import get_trading_mode
from risk import build_trade_plan, CircuitBreaker, check_pre_trade_gates, update_trailing_stop, passes_regime_filter, blend_ml_score
from capital import CapitalManager
from learner import TradeLearner
from notifier import notify_trade_opened, notify_trade_closed, notify_circuit_breaker, notify
from analytics import format_daily_message, format_weekly_message
from reporter import generate_report
from live_gate import mark_paper_trading_start_if_needed


class PaperTrader:
    def __init__(self):
        self.client = ExchangeClient(use_testnet=config.USE_TESTNET)
        self.capital = CapitalManager()
        self.learner = TradeLearner(db_path=self.capital.db_path)
        self.decider = DecisionMaker(db_path=self.capital.db_path)
        get_trading_mode()   # raises on an unsupported/ambiguous TRADING_MODE
        self.trades_since_last_train = 0
        self.open_positions = {}   # symbol -> dict
        self.trades_today = []
        self.current_day = date.today()
        self.circuit_breaker = CircuitBreaker(capital_at_day_start=self.capital.trading_capital)
        self._last_scan = []
        self._running = True
        sig.signal(sig.SIGINT, self._handle_stop)
        # Starts (or confirms) the clock the live-trading gate measures against.
        mark_paper_trading_start_if_needed()

    def _handle_stop(self, signum, frame):
        print("\n[Quantis] Stop signal received. Shutting down cleanly...")
        self._running = False

    def _maybe_roll_day(self):
        today = date.today()
        if today != self.current_day:
            self._write_daily_report()
            self.current_day = today
            self.trades_today = []
            self.circuit_breaker.reset_for_new_day(self.capital.trading_capital)

    def _write_daily_report(self):
        path = generate_report(
            report_date=self.current_day,
            trades_today=self.trades_today,
            scanned_symbols=self._last_scan or [],
            capital_summary=self.capital.summary(),
            circuit_breaker_tripped=self.circuit_breaker.tripped,
        )
        print(f"[Quantis] Daily report written: {path}")
        if config.ANALYTICS_SEND_DAILY:
            notify(format_daily_message(self.capital.db_path, self.current_day))
        if config.ANALYTICS_SEND_WEEKLY and self.current_day.weekday() == 0:
            notify(format_weekly_message(self.capital.db_path))

    def run(self, poll_seconds: int = None):
        poll_seconds = poll_seconds or config.POLL_SECONDS_LIVE
        print("[Quantis] Starting PAPER TRADING mode (no real orders will be sent).")
        print(f"[Quantis] Starting capital: {self.capital.summary()}")

        while self._running:
            self._maybe_roll_day()

            price_data = self.client.fetch_universe()
            scored = []
            for symbol, df in price_data.items():
                rep = validate_ohlcv(df, check_stale=True)   # live feed: also reject stale candles
                if not rep.ok:
                    print(f"[Quantis] DATA QUALITY: skipping {symbol}: {rep.fatal}")
                    continue
                df = add_indicators(rep.cleaned)
                result = generate_signal(df)   # regime-adaptive: matches backtester/demo logic
                result["symbol"] = symbol
                result["_df"] = df
                scored.append(result)
            self._last_scan = [{k: v for k, v in r.items() if k != "_df"} for r in scored]
            breadth = market_breadth(__import__("pandas").DataFrame(self._last_scan)) if self._last_scan else 0.0
            scored.sort(key=lambda r: r["score"], reverse=True)

            # --- exits (with trailing stop) ---
            for symbol in list(self.open_positions.keys()):
                match = next((r for r in scored if r["symbol"] == symbol), None)
                if not match:
                    continue
                last_price = match["close"]
                pos = self.open_positions[symbol]
                pos["stop"] = update_trailing_stop(
                    entry_price=pos["entry_price"], initial_stop=pos["initial_stop"],
                    current_price=last_price, current_stop=pos["stop"],
                )
                exit_price, reason = None, None
                if last_price <= pos["stop"]:
                    exit_price, reason = pos["stop"], ("trailing_stop" if pos["stop"] > pos["initial_stop"] else "stop_loss")
                elif last_price >= pos["tp"]:
                    exit_price, reason = pos["tp"], "take_profit"

                if exit_price:
                    exit_price = apply_costs(exit_price, "sell")   # simulated fill pays fee + slippage + half-spread
                    pnl = (exit_price - pos["entry_price"]) * pos["size_units"]
                    self.decider.record_outcome(pos["score"], pnl / pos["risk_usdt"] if pos.get("risk_usdt") else 0.0)
                    self.capital.apply_trade_result(symbol, pnl, strategy=pos.get("strategy"), regime=pos.get("regime"))
                    self.circuit_breaker.record_trade_result(pnl)

                    if pos.get("feature_row_id") is not None:
                        self.learner.record_exit(pos["feature_row_id"], pnl_usdt=pnl, risk_usdt=pos.get("risk_usdt", 1.0))
                        self.trades_since_last_train += 1
                        if self.trades_since_last_train >= config.ML_RETRAIN_EVERY_N_TRADES:
                            metrics = self.learner.train()
                            print(f"[Quantis] Learner retrained: {metrics}")
                            self.trades_since_last_train = 0

                    self.trades_today.append({
                        "symbol": symbol, "entry_price": pos["entry_price"], "exit_price": exit_price,
                        "position_size_usdt": pos["size_usdt"], "signal_score": pos["score"],
                        "exit_reason": reason, "pnl_usdt": round(pnl, 2),
                    })
                    print(f"[Quantis] PAPER CLOSE {symbol} {reason} pnl={pnl:+.2f}")
                    notify_trade_closed(symbol, reason, pnl)
                    if self.circuit_breaker.tripped:
                        notify_circuit_breaker()
                    del self.open_positions[symbol]

            # --- entries (regime-filtered, ML-blended) ---
            regime_ok = passes_regime_filter(breadth)
            price_data_snap = {r["symbol"]: r["_df"] for r in scored}
            corr_matrix = compute_correlation_matrix(price_data_snap) if config.USE_CORRELATION_GUARD else None
            if self.circuit_breaker.can_trade() and regime_ok and len(self.open_positions) < config.MAX_CONCURRENT_POSITIONS:
                for result in scored:
                    if len(self.open_positions) >= config.MAX_CONCURRENT_POSITIONS:
                        break
                    symbol = result["symbol"]
                    if symbol in self.open_positions or result["score"] < config.MIN_SCORE_TO_TRADE:
                        continue

                    df = result["_df"]
                    atr = df.iloc[-1]["atr"]
                    raw_price = result["close"]
                    decision = self.decider.evaluate(symbol, result, raw_price, atr)
                    if not decision.approved:
                        continue
                    entry_price = apply_costs(raw_price, "buy")

                    ml_features = {
                        "trend_score": result.get("trend"), "momentum_score": result.get("momentum"),
                        "volatility_score": result.get("volatility"), "rsi": result.get("rsi"),
                        "atr_pct": result.get("atr_pct"), "market_breadth": breadth,
                        "signal_score": result["score"],
                    }
                    ml_prob = self.learner.predict_win_probability(ml_features)
                    blended_score = blend_ml_score(result["score"], ml_prob)

                    plan = build_trade_plan(
                        symbol=symbol, entry_price=entry_price, atr=atr,
                        signal_score=blended_score, trading_capital=self.capital.trading_capital,
                        size_multiplier=decision.size_multiplier,
                    )
                    allowed, why = check_pre_trade_gates(
                        plan, len(self.open_positions), 0.0,
                        self.capital.trading_capital, self.circuit_breaker,
                        open_symbols=list(self.open_positions.keys()), corr_matrix=corr_matrix, decision=decision,
                    )
                    if not allowed:
                        continue

                    feature_row_id = self.learner.record_entry(symbol, ml_features)

                    self.open_positions[symbol] = {
                        "entry_price": plan.entry_price, "stop": plan.stop_loss_price,
                        "initial_stop": plan.stop_loss_price,
                        "tp": plan.take_profit_price, "size_units": plan.position_size_units,
                        "size_usdt": plan.position_size_usdt, "score": result["score"],
                        "risk_usdt": plan.risk_usdt, "feature_row_id": feature_row_id,
                        "strategy": result.get("strategy"), "regime": result.get("regime"),
                    }
                    print(f"[Quantis] PAPER OPEN {symbol} score={result['score']} (blended={blended_score}) size=${plan.position_size_usdt:.2f}")
                    notify_trade_opened(symbol, blended_score, plan.position_size_usdt)

            print(f"[Quantis] {datetime.now().isoformat(timespec='seconds')} | "
                  f"open={len(self.open_positions)} | equity={self.capital.total_equity():.2f} | "
                  f"sleeping {poll_seconds}s")
            for _ in range(poll_seconds):
                if not self._running:
                    break
                time.sleep(1)

        self._write_daily_report()
        self.learner.close()
        self.capital.close()
        print("[Quantis] Stopped.")


if __name__ == "__main__":
    trader = PaperTrader()
    trader.run()
