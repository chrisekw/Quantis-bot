import asyncio
"""
Exchange connectivity via ccxt. Wraps Binance (or any ccxt exchange) with
testnet/sandbox support so you can run against fake funds before ever
touching real capital.

NOTE: this module makes real network calls to the exchange. It will NOT
work inside a network-restricted sandbox — run it on your own machine
after installing requirements.txt and setting your testnet API keys in
config.py or environment variables.
"""
import os
import time
import pandas as pd
import ccxt

import config


class ExchangeClient:
    def __init__(self, exchange_id: str = None, use_testnet: bool = None):
        exchange_id = exchange_id or config.EXCHANGE_ID
        use_testnet = config.USE_TESTNET if use_testnet is None else use_testnet

        api_key = os.getenv("QUANTIS_API_KEY", config.API_KEY)
        api_secret = os.getenv("QUANTIS_API_SECRET", config.API_SECRET)

        exchange_class = getattr(ccxt, exchange_id)
        self.exchange = exchange_class({
            "apiKey": api_key,
            "secret": api_secret,
            "enableRateLimit": True,
            "options": {"defaultType": "spot"},
        })

        if use_testnet:
            if hasattr(self.exchange, "set_sandbox_mode"):
                self.exchange.set_sandbox_mode(True)
            else:
                raise RuntimeError(
                    f"{exchange_id} ccxt integration does not support set_sandbox_mode(); "
                    "check ccxt docs for the correct testnet base URL override."
                )

        self.use_testnet = use_testnet

    def fetch_ohlcv_df(self, symbol: str, timeframe: str = None, limit: int = None) -> pd.DataFrame:
        timeframe = timeframe or config.TIMEFRAME
        limit = limit or config.LOOKBACK_BARS
        raw = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        df = pd.DataFrame(raw, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        return df

    def fetch_universe(self, symbols=None, timeframe=None, limit=None) -> dict:
        symbols = symbols or config.SYMBOLS
        out = {}
        for sym in symbols:
            try:
                out[sym] = self.fetch_ohlcv_df(sym, timeframe, limit)
            except Exception as e:
                print(f"[WARN] failed to fetch {sym}: {e}")
            time.sleep(self.exchange.rateLimit / 1000)
        return out

    def get_balance_usdt(self) -> float:
        bal = self.exchange.fetch_balance()
        return float(bal.get("USDT", {}).get("free", 0.0))

    def place_market_buy(self, symbol: str, amount_units: float) -> dict:
        """Places a real (or testnet) market buy order. amount_units is in base
        currency units (e.g., how much BTC, not how much USDT)."""
        return self.exchange.create_market_buy_order(symbol, amount_units)

    def place_market_sell(self, symbol: str, amount_units: float) -> dict:
        return self.exchange.create_market_sell_order(symbol, amount_units)

    def place_stop_loss(self, symbol: str, amount_units: float, stop_price: float) -> dict:
        """
        Places an exchange-native stop order so protection holds even if the
        bot process goes offline (Section 13 risk register: exchange downtime
        mitigation). Not all exchanges/symbols support all stop order types —
        check your exchange's ccxt capabilities before relying on this in
        production.
        """
        params = {"stopPrice": stop_price}
        return self.exchange.create_order(symbol, "stop_market", "sell", amount_units, None, params)


async def fetch_universe_async(symbols=None, timeframe=None, limit=None, use_testnet=None, exchange_id=None):
    """
    Speed optimization: fetch all symbols CONCURRENTLY instead of sequentially.
    A sequential scan of 10 symbols at ~300ms/request takes ~3s; concurrent
    fetch takes roughly the time of the single slowest request (~300-500ms).
    This matters because signal freshness decays -- the faster the full
    universe scan completes, the closer every symbol's signal is to "now."
    """
    import ccxt.async_support as ccxt_async
    import pandas as pd

    exchange_id = exchange_id or config.EXCHANGE_ID
    use_testnet = config.USE_TESTNET if use_testnet is None else use_testnet
    symbols = symbols or config.SYMBOLS
    timeframe = timeframe or config.TIMEFRAME
    limit = limit or config.LOOKBACK_BARS

    api_key = os.getenv("QUANTIS_API_KEY", config.API_KEY)
    api_secret = os.getenv("QUANTIS_API_SECRET", config.API_SECRET)

    exchange_class = getattr(ccxt_async, exchange_id)
    exchange = exchange_class({
        "apiKey": api_key, "secret": api_secret,
        "enableRateLimit": True, "options": {"defaultType": "spot"},
    })
    if use_testnet and hasattr(exchange, "set_sandbox_mode"):
        exchange.set_sandbox_mode(True)

    async def fetch_one(sym):
        try:
            raw = await exchange.fetch_ohlcv(sym, timeframe=timeframe, limit=limit)
            df = pd.DataFrame(raw, columns=["timestamp", "open", "high", "low", "close", "volume"])
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            df.set_index("timestamp", inplace=True)
            return sym, df
        except Exception as e:
            print(f"[WARN] async fetch failed for {sym}: {e}")
            return sym, None

    try:
        results = await asyncio.gather(*(fetch_one(s) for s in symbols))
    finally:
        await exchange.close()

    return {sym: df for sym, df in results if df is not None}
